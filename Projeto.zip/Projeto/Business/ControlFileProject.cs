﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Remoting;
namespace Business
{
     public class ControlFileProject
    {


        #region Systema para os Arquivos Importantes.

        public string[] VerificarProjetos()
        {
            string[] vasio = null;

            if(Directory.Exists(DadosUsuario.Diretory + @"Drawer Project"))
            {
                if(Directory.Exists(DadosUsuario.Diretory +@"Drawer Project\Projetos"))
                {
                    
                    string[] files = Directory.GetDirectories(DadosUsuario.Diretory + @"Drawer Project\Projetos");

                    
                    return files;

                }
                else
                {
                    CriarPastasImportantes();

                }
            }
            else
            {
                CriarPastasImportantes();
            }

            return vasio;
        }

        public void CriarPastasImportantes()
        {

            if (Directory.Exists(DadosUsuario.Diretory + @"Drawer Project"))
            {
                if (Directory.Exists(DadosUsuario.Diretory + @"Drawer Project\Projetos"))
                {

                }
                else
                {
                    DirectoryInfo diretorio = new DirectoryInfo(DadosUsuario.Diretory + @"Drawer Project\");
                    diretorio.CreateSubdirectory("Projetos");


                }
            }
            else
            {
                DirectoryInfo diretorio = new DirectoryInfo(DadosUsuario.Diretory);
                diretorio.CreateSubdirectory(@"Drawer Project\Projetos");
            }
        }

        #endregion

        public string[] VerificarArquivos(string diretory)
        {
            string[] files = Directory.GetFiles(diretory);

            return files;
        }
        public bool VerificarPasta(string DiretoryPasta ,string DiretoryInfo, string nomeArquivo)
        {
            if (Directory.Exists(DiretoryPasta))
            {


                return true;
            }
            else
            {

                criarPasta(DiretoryInfo , nomeArquivo);

                return false;
   
            
            }
        }

       


        #region Méduto para criar qualquer pasta

        public static void criarPasta(string diretorio , string nomePasta)
        {
            DirectoryInfo diretorioInfo = new DirectoryInfo(diretorio);
            diretorioInfo.CreateSubdirectory(nomePasta);
        }

        #endregion

        
        // System para o nome do arquivo dentro do diretório.
        // ex: C:/imagems/teste.jpg = teste.jpg
        public static string getNameFile(string diretory)
        {
            return Path.GetDirectoryName(diretory);
        }
        //
        #region System de Calculo de bytes

        //Fonte https://www.youtube.com/watch?v=bWtbDkfQkss

        public static string GetSizeFile(double byteCout)
        {
            string Size = "0 Bytes";

            if(byteCout >= 1073741824.0)
            {
                Size = string.Format("{0:##.##}", byteCout / 1073741824.0) + "GB";
            }

            else if(byteCout >= 1048576.0)
            {
                Size = string.Format("{0:##.##}", byteCout / 1048576.0) + "MB";
            }
            else if (byteCout >= 1024.0)
            {
                Size = string.Format("{0:##.##}", byteCout / 1024.0) + "KB";
            }
            else if (byteCout >0 && byteCout < 1024.0)
            {
                Size =byteCout.ToString() + "Bytes";
            }


            return Size;
        }

        #endregion

        //
        public static void SalvarDiretorioSetting(string diretory)
        {

            Properties.Settings.Default.Diretory = diretory;

            Properties.Settings.Default.Save();

        }

        public void InfoFolder(string folder)
        {
            DirectoryInfo directory = new DirectoryInfo(@"c:\Drawer Project\Projetos\" + folder);
            
           
        }

        public string[] GetNameFiles (string diretory)
        {
            return Directory.GetFiles(diretory);
        }

        public string GetNameFile(string diretory)
        {
            return Path.GetFileNameWithoutExtension(diretory);
        }
        
        public void MoverFile(string Antigo , string Novo)
        {
            Directory.Move(Antigo, Novo);


        }

        public void CopiarFile(string Antigo, string Novo)
        {
            File.Copy(Antigo, Novo);


        }

    }
}
