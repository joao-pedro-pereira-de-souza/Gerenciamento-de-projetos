﻿using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Windows.Forms.DataVisualization.Charting;
using System.Drawing;
using System.Data;
namespace Business
{
    public  class SystemSelectGraf
    {
        Series graf = new Series("DadosGraf");

        public ChartArea configAria = new ChartArea();

      //  public string[] valoresDesign = new string[12];
        

        public SystemSelectGraf(string GrafSelect)
        {

            ConfigLiners();

            // Opções de Gráficos.

            switch (GrafSelect)
            {
                case "Columns":

                    // graf.Series.Add("DadosGraf");
                    graf.ChartType = SeriesChartType.Column;
                    graf.IsVisibleInLegend = false;

                    break;


                case "Bar":

                    graf.ChartType = SeriesChartType.Bar;
                    graf.IsVisibleInLegend = false;



                    break;

                case "Pie":


                    graf.ChartType = SeriesChartType.Pie;
                    graf.IsVisibleInLegend = false;


                    break;

                case "Line":

                    graf.ChartType = SeriesChartType.Spline;
                    graf.IsVisibleInLegend = false;

                    graf.BorderWidth = 4;                

                    break;

                case "Area":

                    graf.ChartType = SeriesChartType.Area;
                    graf.IsVisibleInLegend = false;

                   

                    break;

                case "Line Point":

                    graf.ChartType = SeriesChartType.FastLine;
                    graf.IsVisibleInLegend = false;



                    break;


            }

            //

            // Adicionar os valores do Datagrid no gráfico.

            for(int i =0; i < TableDadosGraf.tabela.Rows.Count;i++)
            {
                
                graf.Points.AddXY(TableDadosGraf.tabela.Rows[i][1] , TableDadosGraf.tabela.Rows[i][0]);
            }

            //
          
        }

        public void ConfigLiners()
        {
           


            graf.Color = ColorTranslator.FromHtml("#2ecc71");

            configAria.BackColor = Color.Transparent;

            configAria.AxisY.LineColor = ColorTranslator.FromHtml("#ecf0f1");

            configAria.AxisX.LineColor = ColorTranslator.FromHtml("#ecf0f1");

            configAria.AxisY.MajorGrid.LineColor = ColorTranslator.FromHtml("#ecf0f1");

            configAria.AxisX.MajorGrid.LineColor = Color.Transparent;

            configAria.AxisY.MajorTickMark.LineColor = Color.Transparent;

            configAria.AxisX.MajorTickMark.LineColor = Color.Transparent;

            configAria.AxisX.LabelStyle.ForeColor = ColorTranslator.FromHtml("#ecf0f1");
            configAria.AxisY.LabelStyle.ForeColor = ColorTranslator.FromHtml("#ecf0f1");




            #region Sistema para verificar se no campo das cores são determinadas trasparentes ou cor Html.


            // Adicionando os valores em uma Array

            //Cor de fundo do Gráfico.

            /*
            valoresDesign[0] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][1].ToString();
            //
            //
            valoresDesign[1] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][2].ToString();


            valoresDesign[2] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][3].ToString();
            valoresDesign[3] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][4].ToString();
            valoresDesign[4] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][5].ToString();
            valoresDesign[5] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][6].ToString();
            valoresDesign[6] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][7].ToString();
            valoresDesign[7] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][8].ToString();
            valoresDesign[8] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][9].ToString();
            valoresDesign[9] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][10].ToString();

            valoresDesign[10] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][11].ToString();

            valoresDesign[11] = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows[0][0].ToString();
            //

            // Cor do Gráfico.(interno)
            if (valoresDesign[10] == "Transparent")
            {
                graf.Color = Color.Transparent;
            }
            else
            {
                graf.Color = ColorTranslator.FromHtml(valoresDesign[10]);
            }

            //Background Gráfi.
            if (valoresDesign[0] == "Transparent")
            {
                configAria.BackColor = Color.Transparent;
            }
            else
            {
                configAria.BackColor = ColorTranslator.FromHtml(valoresDesign[0]);// cor de fundo gráfico.
                
            }

            //

            // LinerColor Y
            if (valoresDesign[1] == "Transparent")
            {
                configAria.AxisY.LineColor = Color.Transparent;
            }
            else
            {
                configAria.AxisY.LineColor = ColorTranslator.FromHtml(valoresDesign[1]);// cor de fundo gráfico.
                
            }

            // LinerColor X o
            if (valoresDesign[2] == "Transparent")
            {
                configAria.AxisX.LineColor = Color.Transparent;
            }
            else
            {
                configAria.AxisX.LineColor = ColorTranslator.FromHtml(valoresDesign[2]);

            }

            // endLinerColor Y
            if (valoresDesign[4] == "Transparent")
            {
                configAria.AxisY.MajorGrid.LineColor = Color.Transparent;
            }
            else
            {
                configAria.AxisY.MajorGrid.LineColor = ColorTranslator.FromHtml(valoresDesign[4]);
            }
            //

            // endLinerColor X
            if (valoresDesign[5] == "Transparent")
            {
                configAria.AxisX.MajorGrid.LineColor = Color.Transparent;
            }
            else
            {
                configAria.AxisX.MajorGrid.LineColor = ColorTranslator.FromHtml(valoresDesign[5]);
            }
            //

            // MajorTickMark Y
            if (valoresDesign[6] == "Transparent")
            {
                configAria.AxisY.MajorTickMark.LineColor = Color.Transparent;
            }
            else
            {
                configAria.AxisY.MajorTickMark.LineColor = ColorTranslator.FromHtml(valoresDesign[6]);
            }
            //

            // MajorTickMark X
            if (valoresDesign[7] == "Transparent")
            {
                configAria.AxisX.MajorTickMark.LineColor = Color.Transparent;
            }
            else
            {
                configAria.AxisX.MajorTickMark.LineColor = ColorTranslator.FromHtml(valoresDesign[7]);
            }
            //

            // LabelColor Y

            if (valoresDesign[8] == "Transparent")
            {
                configAria.AxisY.LabelStyle.ForeColor = Color.Transparent;
            }
            else
            {
                configAria.AxisY.LabelStyle.ForeColor = ColorTranslator.FromHtml(valoresDesign[8]);
            }
            //

            //LabelColor X

            if (valoresDesign[9] == "Transparent")
            {
                configAria.AxisX.LabelStyle.ForeColor = Color.Transparent;
            }
            else
            {
                configAria.AxisX.LabelStyle.ForeColor = ColorTranslator.FromHtml(valoresDesign[9]);
            }

          
            //
            */
            #endregion

        }

        public Series ShowGraf()
        {

            return graf;
        }
    }
}
