﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class ConjuntoDadosGraf
    {
        public static string nomeCard;

        public static Dictionary<int, TableDadosGraf> dadosGraf = new Dictionary<int, TableDadosGraf>();

        public static Dictionary<int, DadosCard> dadosCard = new Dictionary<int, DadosCard>();

      

      
    }
}
