﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Business
{
   public  class DadosCard
   {
        public static int numericCard;

   }
}