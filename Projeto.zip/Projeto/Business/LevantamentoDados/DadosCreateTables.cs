﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace Business
{
    public class DadosCreateTables
    {
        public static string NameArquivo;

        public static DataSet TablesSet;

    }
}
