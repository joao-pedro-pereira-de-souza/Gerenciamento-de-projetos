﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class useEditBody
    {
        public static bool edit = false;

        // Variáveis 
        public static string tema = "Bem Vindo";
        public static string titulo = "num sei";
        public static string texto ="o Project drawer tem seu objetivo em ajudar no dia a dia quando vc precisa organizar seus dados.";
        public static string botao = "";
        public static string subtext = "";
        public static string subsubject = "";
        //  

    }
}
