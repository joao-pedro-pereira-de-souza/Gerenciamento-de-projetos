﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class DadosUsuario
    {

        //Dados que seram carregados no Login ... Para não precisar fazer a consulta no banco mais de uma vez.
        public static string NameUser;
        public static string emailUser;
        public static string senhaUser;

        //

        // Diretório Padrão.
        public static string Diretory = Properties.Settings.Default.Diretory;

        public static string DiretoryProject;

    }
}
