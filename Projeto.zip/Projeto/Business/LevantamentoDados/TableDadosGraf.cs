﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Business
{
    public class TableDadosGraf
    {
        // essa class irá receber os dados de uma tabela em tempo curto ... Só para fazer uma passagem entre forms.

       public static DataTable tabela = new DataTable();

      
    }
}
