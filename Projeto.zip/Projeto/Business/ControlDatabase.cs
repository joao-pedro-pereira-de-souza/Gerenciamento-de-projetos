﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using DataAcess;
using System.Data;

namespace Business
{
    public class ControlDatabase
    {
        #region VerificarLogin

        public string VerifLogin(string cmd , string ConfiSenha)
        {
            try
            {

                Database bd = new Database();

                string senha = bd.consultaExpecifica(cmd,3);

                /*

                #region Transformar texto em MD5.

                // Fonte :https://pt.stackoverflow.com/questions/17181/como-criptografar-e-descriptografar-dados-em-md5-utilizando-c
                MD5 md5Hash = MD5.Create();

                byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(ConfiSenha));
                // byte ne = reader.GetByte(3);

                // Cria-se um StringBuilder para recompôr a string.
                StringBuilder sBuilder = new StringBuilder();

                // Loop para formatar cada byte como uma String em hexadecimal

                //

                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }


                #endregion

    */

                // Verificar a senha criptografada == texto criptografada.

                if (ConfiSenha == senha)
                {
                    return "Cadastro confirmado";
                }
                else
                {
                    return senha;
                }
                //
            }
            catch (Exception ex)
            {
                return "Erro :"+ex.Message;
            }
          

        }

        #endregion


        #region AdicionarRegistro

        public bool AdicionarRegistro(string cmd)
        {
            try
            {
                Database bd = new Database();

               string registro = bd.ExeculteReader(cmd);

               if(registro == "Registro Criado com sucesso")
               {
                    return true;
               }
               else
               {
                    return false;
               }

            }
            catch (Exception ex)
            {
                return false;
            }


        }

        #endregion


        public string EnviarCodigo(List<string>Senders)
        {

            Random cod = new Random();// Fonte : https://www.youtube.com/watch?v=p4DS4SROf0E.


            string codigo = cod.Next(1, 601).ToString();

            // Configurando a mensagem

            ControlConfigEnviarEmail eviar = new ControlConfigEnviarEmail(

                tema: "Recuperar Tema",
                titulo: "Como funciona ?",
                texto: "O sistema de recuperar senha é feito através do código de recuperação:" + codigo,
                subtxt: "com a confirmação do código será enviado os dados do usuários no email",
                subbject: "Recuperar a senha",
                Sender: Senders

                );

            return codigo;
            //
        }

        #region VerificarEmail-Recuperar

       
        public List<string> VerifEmailRecuperar(string cmd)
        {
            try
            {
                Database bd = new Database();

                 string retornEmail =  bd.consultaExpecifica(cmd ,2);


                if(retornEmail != "Vazio")
                {


                    return new List<string> {"Realizado com sucesso",EnviarCodigo(new List<string> { retornEmail })};
                }
                else
                {
                    return new List<string> { "Erro:"};
                }

            }
            catch (Exception ex)
            {
                return new List<string> { ex.Message };
            }


        }

        #endregion

        public DataTable ShowDataTable(string cmd)
        {
            Database bd = new Database();

            return bd.SelectTable(cmd);

        }


        #region VerificarRecuperarSenha

        public bool VerifRecuperar(string cmd)
        {
            Database bd = new Database();

            string retornEmail = bd.consultaExpecifica(cmd, 0);


            if (retornEmail != "Vazio")
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        #endregion


        public string ConsultaExpe(string comando , int Coluna)
        {

            Database bd = new Database();

            string retorno = bd.consultaExpecifica(comando, Coluna);

            return retorno;

        }
        

        // verificando formato string email: https://www.youtube.com/watch?v=bAOeFSQlj_0
       

    }
}
