﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class SystemSupportMail:ControlMailServer
    {

        public  SystemSupportMail()
        {
            senderMail = "project.drawer20@gmail.com";
            password = "jtrr2020";
            host = "smtp.gmail.com";
            port = 587;
            sll = true;

            inicializarSmtpClient();
        }
    }
}
