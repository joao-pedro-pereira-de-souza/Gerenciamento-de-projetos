﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;

namespace Business.SystemSalvar
{
    public class SystemCreateArquivo
    {
        DirectoryInfo diretorio = new DirectoryInfo(DadosUsuario.DiretoryProject +"scriptDados.txt");


        // Fontes:
        //Aulas 1 ) https://www.youtube.com/watch?v=6Md9mkSo0Cs.
        //Aula 2)https://www.youtube.com/watch?v=RLM0dlZKbN4.

        public SystemCreateArquivo()
        {

            if (diretorio.Exists)
            {

               // MessageBox.Show("já existe!");

                return;
            }
            else
            {
                diretorio.Create();
                StreamWriter arquivoTxt = new StreamWriter(diretorio.FullName, true);

                arquivoTxt.Close();
            }



        }
        /*
        public void salvarDados()
        {
            // acessar ao Script de dados 

            StreamWriter arquivoTxt = new StreamWriter("C:\\Drawer Project\\Projetos\\teste\\scriptDados.txt");

            for (int i = 0; i < listDados.dictionaryList.Count; i++)
            {
                arquivoTxt.WriteLine(listDados.dictionaryList[i].topCard + ";"
                    + listDados.dictionaryList[i].leftCard + ";"
                    + listDados.dictionaryList[i].nameGrafi + ";");
            }

            arquivoTxt.Close();

        }

    */
    }
}
