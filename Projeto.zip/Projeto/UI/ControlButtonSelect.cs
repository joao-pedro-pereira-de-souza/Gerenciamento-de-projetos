﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace UI
{
    public partial class ControlButtonSelect : UserControl
    {

        string OpButton;

        public ControlButtonSelect()
        {
            InitializeComponent();

        }

        public ControlButtonSelect(string funcaoButton, string titulo, Image img)
        {
            InitializeComponent();

            lblTitulo.Text = titulo;

            pbxImg.Image = img;

            OpButton = funcaoButton;
        }

        public void SelectFunction(string opButton)
        {
            switch(opButton)
            {
                case "NovoProject":

                    UIConfigs.FrmNovoProject conf = new UIConfigs.FrmNovoProject();

                    conf.ShowDialog();

                    break;

               
                case "NovoGráfico":

                    UIConfigs.FrmNovoProject confGraf = new UIConfigs.FrmNovoProject();

                    confGraf.label1.Text = "Novo Gráfico";

                    confGraf.ptbTema.Image = Properties.Resources.iconIluChartPie;

                    confGraf.txbNomeProject.Text = "";

                    confGraf.txbNomeProject.MarcaText = "Novo Gráfico";

                    

                    confGraf.ShowDialog();

                    break;

                case "NovoBanco":

                   UIConfigs.FrmConfigDados dados = new  UIConfigs.FrmConfigDados("Create");

                    dados.CriarForaP = true;

                    dados.btnConfDadosTables.Enabled = false;

                    dados.ShowDialog();

                    break;

                case "EntrarProject":
                    

                    FrmEditor editor = new FrmEditor();

                    editor.lblNomeProject.Text = lblTitulo.Text;


                    Business.DadosUsuario.DiretoryProject = Business.DadosUsuario.Diretory + @"Drawer Project\Projetos\" + lblTitulo.Text;

                    editor.ShowDialog();


                    break;
            }

        }

        #region Evento MouserHover
        private void ControlButtonSelect_MouseHover(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(46, 204, 113);
        }

        private void pnlFundo_MouseHover(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(46, 204, 113);
        }

        private void pnlPrincipal_MouseHover(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(46, 204, 113);
        }

        private void pbxImg_MouseHover(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(46, 204, 113);
        }
        
        private void lblTitulo_MouseHover(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(46, 204, 113);

            ToolTip Informat = new ToolTip();

            Informat.IsBalloon = true;

            Informat.SetToolTip(this.lblTitulo ,lblTitulo.Text);
        }



        #endregion


        #region Evento MouserLeave

        private void ControlButtonSelect_MouseLeave(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(61, 59, 59);
        }
        
        private void pnlFundo_MouseLeave(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(61, 59, 59);
        }

        private void pnlPrincipal_MouseLeave(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(61, 59, 59);
        }

        private void pbxImg_MouseLeave(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(61, 59, 59);
        }

        private void lblTitulo_MouseLeave(object sender, EventArgs e)
        {
            pnlFundo.BackColor = Color.FromArgb(61, 59, 59);
        }

        #endregion

        #region Evento Click

        private void ControlButtonSelect_Click(object sender, EventArgs e)
        {
            SelectFunction(OpButton);
        }

        private void pnlFundo_Click(object sender, EventArgs e)
        {
            SelectFunction(OpButton);
        }

        private void pnlPrincipal_Click(object sender, EventArgs e)
        {
            SelectFunction(OpButton);
        }

        private void pbxImg_Click(object sender, EventArgs e)
        {
            SelectFunction(OpButton);

        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {
            SelectFunction(OpButton);
        }

        #endregion

    }
}
