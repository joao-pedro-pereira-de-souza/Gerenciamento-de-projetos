﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace UI
{
    public partial class FrmProjeto : Form
    {
        
        public FrmProjeto()
        {
            InitializeComponent();

            ControlCards cards = new ControlCards();// Class (Sistema de adicionar os usercontrol no panel).

            cards.confgControl(pnlContainer); // Método na Class .
           
        }

        private void FrmProjeto_Load(object sender, EventArgs e)
        {
            if(Business.DadosUsuario.Diretory == "")
            {
                UIConfigs.FrmConfigDiretorySystem EditDitory = new UIConfigs.FrmConfigDiretorySystem();

                EditDitory.ShowDialog();

            }
        }
    }
}
