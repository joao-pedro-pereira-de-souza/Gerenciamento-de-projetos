﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using Business;

namespace UI
{
    public partial class FrmEntrar : Form
    {

        //1) instância da classe com a função de verificar as pastas
        ControlFileProject pastasProjetos = new ControlFileProject();
        //

        //2) variaveis de posição.
        // Se precisar alterar o padrão de localização ... precisara alterar umas desssas variáveis .
        int leftcard = 20;
        int topcard = 0;
        //

        // 3) Contador
        //contador (quantidade limite de número de card em cada linha) .
        int responsiveObjects = 0;
        //

        public FrmEntrar()
        {
            InitializeComponent();

            try
            {
                if (Business.DadosUsuario.Diretory == "")
                {
                    UIConfigs.FrmConfigDiretorySystem EditDitory = new UIConfigs.FrmConfigDiretorySystem();

                    EditDitory.ShowDialog();

                }


                var verificarArray = pastasProjetos.VerificarProjetos();

                //verificando a quantidade de resultados... se for 0
                if (verificarArray == null)
                {
                    pnlAvisoVazio.Visible = true;// Mensagem FrontEnd.
                }
                else
                {
                    if (verificarArray.Length == 0)
                    {
                        pnlAvisoVazio.Visible = true;// Mensagem FrontEnd.
                    }

                    else
                    {
                        pnlAvisoVazio.Visible = false;

                        foreach (var nomePastas in pastasProjetos.VerificarProjetos()) // sistema de repetição através da quantidade de objetos dentro da pasta
                        {
                            responsiveObjects += 1;

                            // 1) instância do userControl do button.
                            ControlButtonSelect cardsPastas = new ControlButtonSelect("EntrarProject", nomePastas.Replace(DadosUsuario.Diretory + @"Drawer Project\Projetos\", ""), Properties.Resources.iconefolder);
                            // usercontrol(Button) = new usercontrol(Button).trocar a string do array(@"c:\Drawer Project\Projetos\", por vasio("") , imagem do resource);

                            //
                            // 2) retirar a bordar do userControl.
                            cardsPastas.BorderStyle = BorderStyle.None;
                            //

                            // 3) adicionar nos controles do panel o userControl.
                            pnlContainer.Controls.Add(cardsPastas);
                            //

                            // 4) configura somente a configuração left do objeto.
                            cardsPastas.Left = leftcard;
                            //

                            // 5) configura somente a configuração left do objeto.
                            cardsPastas.Top = topcard;
                            //

                            // 5) variável que ira amarzenar a distância do próximo card.
                            leftcard += (cardsPastas.Height + 10);
                            //

                            // 6) adicionar as informações do card no Painel.
                            pnlContainer.Tag = cardsPastas;
                            //

                            // 7) mostrar adição.

                            cardsPastas.Show();

                            if (responsiveObjects == 6)
                            {
                                responsiveObjects = 0;

                                leftcard = 20;

                                topcard += (cardsPastas.Width + 10);
                            }


                        }
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
            
            

        }

        private void FrmEntrar_Load(object sender, EventArgs e)
        {
            
        }
    }
}
