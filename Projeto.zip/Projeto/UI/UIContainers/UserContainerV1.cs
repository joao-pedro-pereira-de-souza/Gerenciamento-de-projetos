﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class UserContainerV1 : UserControl
    {
       

        public UserContainerV1()
        {
            InitializeComponent();
        }

        public void abrirGrafico()
        {

            pnlContainer.Controls.Clear();
            //  FoldeGraficos.UserGraficoRetangulo grafico = new FoldeGraficos.UserGraficoRetangulo();
            UserGraficos.GraficosPadrao grafico = new UserGraficos.GraficosPadrao();

           

            grafico.BorderStyle = BorderStyle.None;

            grafico.Dock = DockStyle.Fill;

            pnlContainer.Controls.Add(grafico);

            pnlContainer.Tag = grafico;

            grafico.Show();

        }


        private void btnConfigEditar_Click(object sender, EventArgs e)
        {
            UIConfigs.FrmConfigGraf DadosGraf = new UIConfigs.FrmConfigGraf();

            UIConfigs.ControlFrmsStatOpen.ContainerGraf = this;
           // DadosGraf.user = this;

            DadosGraf.ShowDialog();
        }
    }
}
