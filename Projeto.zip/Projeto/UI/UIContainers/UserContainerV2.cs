﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;

namespace UI
{
    public partial class UserContainerV2 : UserControl
    {
        
        public DataTable TabelaShow = new DataTable();

        public UserContainerV2()
        {
            InitializeComponent();
        }

        public void AlterarCores(Color header , Color selectRows , Color lblRows ,Color lblRowsSelect , Color lblHeader)
        {
            //Cofigurar colors Header.
            dgvDados.ColumnHeadersDefaultCellStyle.BackColor = header;
            dgvDados.ColumnHeadersDefaultCellStyle.ForeColor = lblHeader;

            dgvDados.ColumnHeadersDefaultCellStyle.SelectionBackColor = header;
            dgvDados.ColumnHeadersDefaultCellStyle.SelectionForeColor = lblHeader;
            //

            //Configurar colors Rows .
            dgvDados.RowsDefaultCellStyle.SelectionBackColor = selectRows;
            dgvDados.RowsDefaultCellStyle.SelectionForeColor = lblRowsSelect;
            dgvDados.RowsDefaultCellStyle.ForeColor = lblRows;
            //
        }

        private void UserContainerV2_Load(object sender, EventArgs e)
        {
           
        }

        private void btnConfigEditar_Click(object sender, EventArgs e)
        {
            UIConfigs.FrmConfigTable confiTable = new UIConfigs.FrmConfigTable();

            confiTable.containerTable = this;
            

            confiTable.ShowDialog();
        }

        private void btnPesquisa_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvDados.DataSource != null)
                {
                    if (txtPesquisa.Text != txtPesquisa.MarcaText)
                    {

                        if(lblHeader.Text != "")
                        {

                            #region Formas encontradas para ter o mesmo resultado
                            // 
                            #region Forma de Sistema 1
                            /*

                            //Fonte : https://www.youtube.com/watch?v=348ZQf5V4i4.

                            BindingSource bs = new BindingSource();
                            bs.DataSource = dgvDados.DataSource;

                            bs.Filter = string.Format("{0} like '%{1}%'", lblHeader.Text, txtPesquisa.Text.ToString());

                            dgvDados.DataSource = bs;

                        */
                            #endregion

                            // Forma2  ((DataTable)dgvDados.DataSource).DefaultView.RowFilter = string.Format("{0} like '%{1}%'",lblHeader.Text, txtPesquisa.Text.Trim().Replace("'", "''"));



                            #endregion

                            //Sistela de pesquisa no Datagrid.

                            
                            //Fonte : https://pt.stackoverflow.com/questions/109601/filtrorowfilter-do-datagridview-est%C3%A1-dando-erro.
                            ((DataTable)dgvDados.DataSource).DefaultView.RowFilter = string.Format("Convert({0},'System.String') like '%{1}%'", lblHeader.Text, txtPesquisa.Text.Trim().Replace("'", "''"));

                            //

                            // Fonte completa sobre Filter no Datagrid : https://10tec.com/articles/datagridview-filter.aspx.
                        }
                        else
                        {
                            MessageBox.Show("Selecione uma coluna");
                        }
                       
                       
                    }
                    else
                    {
                        ((DataTable)dgvDados.DataSource).DefaultView.RowFilter = string.Format("Convert({0},'System.String') like '%{1}%'",
                            lblHeader.Text,"");
                    }

                }
                else
                {
                    MessageBox.Show("Adicione uma tabela ");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro : \n" + ex.Message);
            }
           
        }

        private void dgvDados_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            lblHeader.Text = dgvDados.Columns[e.ColumnIndex].HeaderText;
           
           
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            FrmMensagem mensagemInfo = new FrmMensagem();

            mensagemInfo.lblTitulo.Text = "Como funciona o gerenciamento de tabela ?";

            mensagemInfo.ptbMensagem.Image = Properties.Resources.iconeSelectTable;

            mensagemInfo.lblConteudo.Text = "O modo pesquisa procura as linhas referente a coluna selecionada na tabela ...\n " +
                "selecione a coluna que vc deseja fazer a fonte de pesquisa.";

            mensagemInfo.ShowDialog();
        }

      
    }
}
