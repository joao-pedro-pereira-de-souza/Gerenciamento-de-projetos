﻿namespace UI
{
    partial class UserContainerV1
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.btnConfigEditar = new FerramentasMod.ButtonElipse();
            this.SuspendLayout();
            // 
            // pnlContainer
            // 
            this.pnlContainer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlContainer.Location = new System.Drawing.Point(0, 57);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(756, 309);
            this.pnlContainer.TabIndex = 0;
            // 
            // btnConfigEditar
            // 
            this.btnConfigEditar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConfigEditar.AnguloColor = 45F;
            this.btnConfigEditar.borderRadius = 35;
            this.btnConfigEditar.ColorButton = System.Drawing.Color.Tomato;
            this.btnConfigEditar.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(83)))), ((int)(((byte)(54)))));
            this.btnConfigEditar.ColorLeaver = System.Drawing.Color.Tomato;
            this.btnConfigEditar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfigEditar.EfeitoTexto = true;
            this.btnConfigEditar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfigEditar.ForeColor = System.Drawing.Color.White;
            this.btnConfigEditar.Location = new System.Drawing.Point(637, 17);
            this.btnConfigEditar.Name = "btnConfigEditar";
            this.btnConfigEditar.Size = new System.Drawing.Size(107, 34);
            this.btnConfigEditar.TabIndex = 2;
            this.btnConfigEditar.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfigEditar.Texto = "Editar";
            this.btnConfigEditar.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfigEditar.Click += new System.EventHandler(this.btnConfigEditar_Click);
            // 
            // UserContainerV1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.Controls.Add(this.btnConfigEditar);
            this.Controls.Add(this.pnlContainer);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Gainsboro;
            this.Name = "UserContainerV1";
            this.Size = new System.Drawing.Size(756, 366);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlContainer;
        private FerramentasMod.ButtonElipse btnConfigEditar;
    }
}
