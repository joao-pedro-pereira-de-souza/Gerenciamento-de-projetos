﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace UI.UIContainers
{
    public partial class UserContainerV3 : UserControl
    {
        public UserContainerV3()
        {
            InitializeComponent();
            /*
            worker.WorkerReportsProgress = true;
            worker.WorkerSupportsCancellation = true;

            worker.ProgressChanged += Worker_ProgressChanged;
            worker.DoWork += Worker_DoWork;

            */
        }



        private string SelectOp = "Copy";
        public void SelectOpFile()
        {
            if (SelectOp == "Copy")
            {
                btnCopy.BackColor = Color.FromArgb(88, 88, 88);
                btnMove.BackColor = Color.FromArgb(51, 51, 51);

            }

            else if (SelectOp == "Move")
            {
                btnCopy.BackColor = Color.FromArgb(51, 51, 51);
                btnMove.BackColor = Color.FromArgb(88, 88, 88);
            }
        }
        /*
         private void Worker_DoWork(object sender, DoWorkEventArgs e)
         {
            ptbDrop.fu
         }

         private void Worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
         {
             progArquivos.Value = e.ProgressPercentage;
         }
         */
        //Fonte : https://www.youtube.com/watch?v=EZEOPW_v2a8.

        //  BackgroundWorker worker = new BackgroundWorker(); 



        private void ptbDrop_DragDrop(object sender, DragEventArgs e)
        {
            
            try
            {
                var DroppedFile = e.Data.GetData(DataFormats.FileDrop);

                if (DroppedFile != null)
                {
                    var filename = DroppedFile as string[];

                    if (filename.Length > 0)
                    {

                        circularProgressBar.Visible = true;

                        
                        Business.ControlFileProject pasta = new Business.ControlFileProject();
                        pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos", Business.DadosUsuario.DiretoryProject + @"\", "Arquivos");

                        foreach (string arquivo in filename)
                        {
                            VerificarFile(arquivo);

                        }

                        
                        circularProgressBar.Visible = false;

                        MessageBox.Show("Arquivos organizados");
                    }
                }
            }
            catch(Exception ex)
            {
                circularProgressBar.Visible = false;
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           
            
        }


        private void ptbDrop_DragEnter(object sender, DragEventArgs e)
        {

            e.Effect = DragDropEffects.Copy;

        }

        #region Filtro de Arquivos.
        //
        public void VerificarFile(string TipoFile)
        {
            Business.ControlFileProject pasta = new Business.ControlFileProject();
            string Tipo = Path.GetExtension(TipoFile);

            switch (Tipo)
            {

                //Arquivos do Tipo Imagens.

                case ".png":

                    
                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Imagens");

                    //Copiar ou Mover ?.
                    if(SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    //
                   

                    break;

                case ".jpg":

                    
                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Imagens");


                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    //
                   

                    break;

                case ".jpeg":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Imagens");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;


                case ".ico":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Imagens");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Imagens\" + Path.GetFileName(TipoFile));
                    }
                    //


                    break;

                //

                // Tipo video 

                case ".mp4":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Videos");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;


                case ".avi":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Videos");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

                case ".wmv":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Videos");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Videos\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;
                //

                //Tipo Audio

                case ".mp3":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Áudios", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Áudios");


                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Áudios\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Áudios\" + Path.GetFileName(TipoFile));
                    }
                    //
                   

                    break;


                case ".wav":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Áudios", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Áudios");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Áudios\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Áudios\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;


                //

                //Tipo CD

                case ".iso":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\CD", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "CD");


                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\CD\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\CD\" + Path.GetFileName(TipoFile));
                    }
                    //
                  

                    break;

                //


                //Documentos===================================================================================================================================//

                //Word
                case ".docx":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Word");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

               //Word 2003
                case ".doc":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Word");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

                case ".dotx":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Word");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Word\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;
                // 
                //Pdf


                case ".pdf":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Pdf", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Pdf");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Pdf\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Pdf\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

                //

                //Web
                case ".html":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Web", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Web");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Web\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Web\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

                case ".svg":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Web", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Web");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Web\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Web\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

                //

                case ".xml":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Xml", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Xml");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Xml\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Xml\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;


                //Texto

                case ".txt":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Texto", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Texto");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Texto\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Texto\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;


                //

                //Excel
                case ".xlsx":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Excel", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Excel");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Excel\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Excel\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

                case ".xls":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Excel", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Excel");


                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Excel\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Excel\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;


                //

                case ".pptx":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\PowerPoint", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "PowerPoint");


                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\PowerPoint\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\PowerPoint\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

                case ".zip":


                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Zip", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Zip");


                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Zip\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Zip\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;




                default:

                    pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Arquivos\Outros", Business.DadosUsuario.DiretoryProject + @"\Arquivos\", "Outros");

                    //Copiar ou Mover ?.
                    if (SelectOp == "Copy")
                    {
                        pasta.CopiarFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Outros\" + Path.GetFileName(TipoFile));
                    }
                    else
                    {
                        pasta.MoverFile(TipoFile, Business.DadosUsuario.DiretoryProject + @"\Arquivos\Outros\" + Path.GetFileName(TipoFile));
                    }
                    //

                    break;

            }

        }

        #endregion


        private void UserContainerV3_Load(object sender, EventArgs e)
        {
            ptbDrop.AllowDrop = true;
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            SelectOp = "Copy";

            SelectOpFile();
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            SelectOp = "Move";

            SelectOpFile();
        }
    }
}
