﻿namespace UI.UIsFrmConfiguracao
{
    partial class FrmSubNotification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSubNotification));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSalvar = new FerramentasMod.ButtonElipse();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnDesativado = new System.Windows.Forms.Button();
            this.btnAtivado = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label1.Location = new System.Drawing.Point(22, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(251, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Configurações de Notificações :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UI.Properties.Resources.iconeNotification;
            this.pictureBox1.Location = new System.Drawing.Point(6, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(651, 189);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btnSalvar
            // 
            this.btnSalvar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSalvar.AnguloColor = 45F;
            this.btnSalvar.borderRadius = 10;
            this.btnSalvar.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnSalvar.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnSalvar.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnSalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalvar.EfeitoTexto = true;
            this.btnSalvar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.ForeColor = System.Drawing.Color.White;
            this.btnSalvar.Location = new System.Drawing.Point(635, 430);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(164, 38);
            this.btnSalvar.TabIndex = 7;
            this.btnSalvar.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.Texto = "Salvar Alterações";
            this.btnSalvar.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.btnDesativado);
            this.panel11.Controls.Add(this.btnAtivado);
            this.panel11.Location = new System.Drawing.Point(36, 78);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(179, 33);
            this.panel11.TabIndex = 8;
            // 
            // btnDesativado
            // 
            this.btnDesativado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDesativado.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnDesativado.FlatAppearance.BorderSize = 0;
            this.btnDesativado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesativado.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesativado.ForeColor = System.Drawing.SystemColors.Control;
            this.btnDesativado.Location = new System.Drawing.Point(89, 0);
            this.btnDesativado.Name = "btnDesativado";
            this.btnDesativado.Size = new System.Drawing.Size(89, 31);
            this.btnDesativado.TabIndex = 1;
            this.btnDesativado.Text = "Desativado";
            this.btnDesativado.UseVisualStyleBackColor = true;
            this.btnDesativado.Click += new System.EventHandler(this.btnDesativado_Click);
            // 
            // btnAtivado
            // 
            this.btnAtivado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.btnAtivado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAtivado.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnAtivado.FlatAppearance.BorderSize = 0;
            this.btnAtivado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtivado.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtivado.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAtivado.Location = new System.Drawing.Point(0, 0);
            this.btnAtivado.Name = "btnAtivado";
            this.btnAtivado.Size = new System.Drawing.Size(89, 31);
            this.btnAtivado.TabIndex = 0;
            this.btnAtivado.Text = "Ativado";
            this.btnAtivado.UseVisualStyleBackColor = false;
            this.btnAtivado.Click += new System.EventHandler(this.btnAtivado_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(12, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(635, 69);
            this.label2.TabIndex = 9;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(74, 138);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(662, 272);
            this.panel1.TabIndex = 10;
            // 
            // FrmSubNotification
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(811, 480);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSubNotification";
            this.Text = "FrmSubPrivacidade";
            this.Load += new System.EventHandler(this.FrmSubNotification_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private FerramentasMod.ButtonElipse btnSalvar;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btnDesativado;
        private System.Windows.Forms.Button btnAtivado;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
    }
}