﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIsFrmConfiguracao
{
    public partial class FrmSubPerfil : Form
    {
        public FrmSubPerfil()
        {
            InitializeComponent();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEmail.Text != txtEmail.MarcaText) 
                {

                    if (VerificandoEmail(txtEmail.Text) == true)
                    {
                        string comand = string.Format("Update usuarios set email='{0}' where email='{1}';",
                        txtEmail.Text, txtEmail.MarcaText);

                        Business.ControlDatabase controlBD = new Business.ControlDatabase();



                        if (controlBD.AdicionarRegistro(comand) == true)
                        {
                            txtEmail.MarcaText = txtEmail.Text;

                            txtEmail.Text = "";
                            MessageBox.Show("Alteração realizada com sucesso!");
                        }
                       

                    }
                    else
                    {
                        MessageBox.Show("Email novo invalido");
                    }
                  
                    

                }
               

                if (txtUsuario.Text != txtUsuario.MarcaText)
                {
                    string comand = string.Format("Update usuarios set nome='{0}' where email='{1}';",
                   txtUsuario.Text, txtEmail.Text);

                    Business.ControlDatabase controlBD = new Business.ControlDatabase();



                    if (controlBD.AdicionarRegistro(comand) == true)
                    {
                        txtUsuario.MarcaText = txtUsuario.Text;

                        txtUsuario.Text = "";

                        MessageBox.Show("Alteração realizada com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("campo usuário já existente");
                    }
                }
                else
                {

                }
                if (txtSenha.Text != txtSenha.MarcaText)
                {
                    string comand = string.Format("Update usuarios set senha='{0}' where email='{1}';",
                   txtSenha.Text, txtEmail.Text);

                    Business.ControlDatabase controlBD = new Business.ControlDatabase();



                    if (controlBD.AdicionarRegistro(comand) == true)
                    {
                        txtSenha.MarcaText = txtSenha.Text;
                        txtSenha.Text = "";
                        MessageBox.Show("Alteração realizada com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("campo Senha já existente");
                    }
                }
                else
                {

                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("erro no processo");
            }
            
        }

        #region Verificar Email
        public bool VerificandoEmail(string userEmail)
        {
            // fonte :https://www.youtube.com/watch?v=8zwuUyWvySg
            try
            {
                MailAddress mail = new MailAddress(userEmail);
                return mail.Address == userEmail;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        #endregion

        private void FrmSubPerfil_Load(object sender, EventArgs e)
        {
            txtUsuario.Text = "";
            txtEmail.Text = "";
            txtSenha.Text = "";

            txtUsuario.MarcaText = Business.DadosUsuario.NameUser;
            txtEmail.MarcaText = Business.DadosUsuario.emailUser;
            txtSenha.MarcaText = Business.DadosUsuario.senhaUser;
        }
    }
}
