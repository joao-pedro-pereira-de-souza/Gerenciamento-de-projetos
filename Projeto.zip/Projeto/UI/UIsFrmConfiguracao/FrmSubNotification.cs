﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIsFrmConfiguracao
{
    public partial class FrmSubNotification : Form
    {
        public FrmSubNotification()
        {
            InitializeComponent();
        }

        string SelectNotif = "Ativado";

        #region Menu de opões de cores(Gráfico)


        #region Sistema Select Opções de cores(FrontEnd)

        public void SelectOpNoti()
        {
            if (SelectNotif == "Ativado")
            {
                btnAtivado.BackColor = Color.FromArgb(88, 88, 88);
                btnDesativado.BackColor = Color.FromArgb(51, 51, 51);

            }

            else if (SelectNotif == "Desativado")
            {
                btnAtivado.BackColor = Color.FromArgb(51, 51, 51);
                btnDesativado.BackColor = Color.FromArgb(88, 88, 88);
            }
        }


        #endregion

        #endregion

        private void btnAtivado_Click(object sender, EventArgs e)
        {
            SelectNotif = "Ativado";

            SelectOpNoti();
        }

        private void btnDesativado_Click(object sender, EventArgs e)
        {
            SelectNotif = "Desativado";

            SelectOpNoti();
        }

       

        private void btnSalvar_Click(object sender, EventArgs e)
        {

            try
            {
                string cmd;

                if (SelectNotif == "Ativado")
                {
                    cmd = string.Format("Update usuarios Set notif=true where email='{0}'", Business.DadosUsuario.emailUser);
                }
                else
                {
                    cmd = string.Format("Update usuarios Set notif=false where email='{0}'", Business.DadosUsuario.emailUser);
                }

                Business.ControlDatabase controlBD = new Business.ControlDatabase();

                if (controlBD.AdicionarRegistro(cmd) == true)
                {
                    MessageBox.Show("Suas notificações foram alteradas");
                }
                else
                {
                    MessageBox.Show("Ocorre alguma falha no sistema !! Porfavor relate o erro no site.");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("erro :\n" + ex.Message);
            }
            
        }

        private void FrmSubNotification_Load(object sender, EventArgs e)
        {
            string cmd = string.Format("Select notif From usuarios  where email='{0}'", Business.DadosUsuario.emailUser);

            Business.ControlDatabase controlBD = new Business.ControlDatabase();

            if (controlBD.AdicionarRegistro(cmd) == true)
            {
                
            }
            else
            {
                MessageBox.Show("Ocorre alguma falha no sistema !! Porfavor relate o erro no site.");
            }
        }
    }
}
