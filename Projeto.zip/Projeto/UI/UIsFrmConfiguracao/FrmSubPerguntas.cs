﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIsFrmConfiguracao
{
    public partial class FrmSubPerguntas : Form
    {
        public FrmSubPerguntas()
        {
            InitializeComponent();
        }

       
      

        private void FrmSubPerguntas_Load(object sender, EventArgs e)
        {
            ptbFundo.Controls.Add(pnlTextos);

            pnlTextos.BackColor = Color.Transparent;

            pnlTextos.Location = new Point(0, 0);

            pnlTextos.BringToFront();
        }

        //fonte para opacidade da imagem : https://pt.stackoverflow.com/questions/384089/opacidade-de-imagens-c.
    }

}
