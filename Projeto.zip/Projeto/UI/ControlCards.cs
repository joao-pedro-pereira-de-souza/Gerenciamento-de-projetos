﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Drawing;
using System.Diagnostics;

namespace UI
{
     public class ControlCards
     {



        #region Variáveis CardsNovo
        // Todos os titulos dos Cards

        private List<string> OpçõesNovo = new List<string> { "Projeto", "Gráfico", "Database" };

        //

        // Variável para armazenar a imagem.

        private Image imgSelect;

        //

        // Variável para defenir a distância dos Cards.

        int poss = 5;

        //

        // Variável do tipo ClassControle

        ControlButtonSelect design;

        //

        #endregion

        #region Método Cards Novo

        public void confgControl(Panel aria) //Método que recebe como parámetro uma variável do tipo Panel(configurações do Campo aonde vai receber os cards).
        {
            foreach (var titulos in OpçõesNovo) // Foreach sistema de repetição ideal para ser usada em variáveis do tipo array/list.
            {
                switch (titulos)
                {
                    case "Projeto":

                        imgSelect = Properties.Resources.iconeProject;// adicionando uma imagem do diretorio do sistema de imagens.

                        design = new ControlButtonSelect("NovoProject",titulos, imgSelect); // adicionado no construtor do card a configuração.

                        aria.Controls.Add(design); // adicionado no Panel do Form FrmProjeto.

                        design.Left = poss; // distância.

                        poss = (design.Height + 10); // adicionado a distância do próximo card.


                        break;

                    case "Gráfico":


                        imgSelect = Properties.Resources.iconeGraf;

                        design = new ControlButtonSelect("NovoGráfico", titulos, imgSelect);

                        aria.Controls.Add(design);

                        design.Left = poss;

                        poss = (design.Left + design.Height + 10);

                        break;

                    case "Database":

                        imgSelect = Properties.Resources.iconeDatabase;

                        // CodConfigDesign                           //

                        design = new ControlButtonSelect("NovoBanco",titulos, imgSelect);

                        aria.Controls.Add(design);

                        design.Left = poss;

                        poss = (design.Left + design.Height + 10);


                        break;
                }


            }


        }

        #endregion
     }
}
