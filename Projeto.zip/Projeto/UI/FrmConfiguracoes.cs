﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class FrmConfiguracoes : Form
    {
        public FrmConfiguracoes()
        {
            InitializeComponent();
        }

        private void FrmConfiguracoes_Load(object sender, EventArgs e)
        {
            UIsFrmConfiguracao.FrmSubNotification notification = new UIsFrmConfiguracao.FrmSubNotification();

            notification.TopLevel = false;

            pnlContainer.Controls.Add(notification);

            notification.Dock = DockStyle.Fill;

            notification.Show();

        }

        private void btnPrivacidade_Click(object sender, EventArgs e)
        {
            pnlContainer.Controls.Clear();

            UIsFrmConfiguracao.FrmSubPerguntas Privacidade = new UIsFrmConfiguracao.FrmSubPerguntas();

            Privacidade.TopLevel = false;

            pnlContainer.Controls.Add(Privacidade);

            Privacidade.Dock = DockStyle.Top;

            Privacidade.Show();

        }

        private void btnPerfil_Click(object sender, EventArgs e)
        {
            pnlContainer.Controls.Clear();

            UIsFrmConfiguracao.FrmSubPerfil perfil = new UIsFrmConfiguracao.FrmSubPerfil();

            perfil.TopLevel = false;

            pnlContainer.Controls.Add(perfil);

            perfil.Dock = DockStyle.Fill;

            perfil.Show();
        }

        private void btnNotificacao_Click(object sender, EventArgs e)
        {
            pnlContainer.Controls.Clear();

            UIsFrmConfiguracao.FrmSubNotification notification = new UIsFrmConfiguracao.FrmSubNotification();

            notification.TopLevel = false;

            pnlContainer.Controls.Add(notification);

            notification.Dock = DockStyle.Fill;

            notification.Show();
        }
    }
}
