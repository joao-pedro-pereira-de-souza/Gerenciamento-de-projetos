﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Threading;

namespace UI
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        bool animatLogin = false;

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion
        #region Sistema de Arrastar formulário


        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #endregion

       
        private void btnCloser_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        string mensagem;

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                

                if (txtEmail.Text == txtEmail.MarcaText || txtSenha.Text == txtSenha.MarcaText)
                {
                    MensagemLabel("Preencha todos os campos");
                }
                else
                {
                    
                    string getResout = string.Format("Select * from usuarios where email='{0}'", txtEmail.Text);

                    Business.ControlDatabase controlBD = new Business.ControlDatabase();

                    mensagem = controlBD.VerifLogin(getResout, txtSenha.Text);

                    MensagemLabel(mensagem);



                    this.Enabled = true;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           
           

        }

        /*
        private void formRun()
        {
            try
            {
                Application.Run(new FrmProgress());

                this.Enabled = false;
            }
            catch (Exception)
            {

            }
            
        }

    */

        #region Animações + verificar User 

        public void MensagemLabel(string texto)
        {

            try
            {
                if (texto == "Cadastro confirmado")
                {

                    string comand = string.Format("Select * from usuarios where email = '{0}'", txtEmail.Text);

                    Business.ControlDatabase controlBD = new Business.ControlDatabase();

                    DataTable table = controlBD.ShowDataTable(comand);
                    //Verificar se o usuário é um Admin
                    if (table.Rows[0][4].ToString() == "False")
                    {
                        //Adicionar dados do usuário
                        Business.DadosUsuario.NameUser = table.Rows[0][1].ToString();
                        Business.DadosUsuario.emailUser = table.Rows[0][2].ToString();
                        Business.DadosUsuario.senhaUser = table.Rows[0][3].ToString();
                        //
                        FrmIndex index = new FrmIndex(this);
                        index.lblEmail.Text = txtEmail.Text;
                        index.Show();
                    }
                    else
                    {
                        FrmAdmin admin = new FrmAdmin();

                        admin.lblEmailAdmin.Text = table.Rows[0][2].ToString();

                        admin.Show();
                    }
                    //

                }
                else
                {
                    lblInfo.Visible = true;
                    lblInfo.BackColor = Color.FromArgb(231, 76, 60);

                    lblInfo.Text = texto;

                    AnimatNot.Start();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           
        }

        private void AnimatNot_Tick(object sender, EventArgs e)
        {
            lblInfo.Visible = false;
            AnimatNot.Stop();
        }


        private void Animat_Tick(object sender, EventArgs e)
        {
            if (animatLogin == false)
            {
                btnCadastro.Enabled = false;
                btnCadastrar.Enabled = false;

                pnlLogin.Left -= 10;
                pnlCadastro.Left -= 10;

                if (pnlCadastro.Left == 360)
                {
                    animatLogin = true;

                    btnCadastro.Enabled = true;
                    btnCadastrar.Enabled = true;
                    Animat.Stop();
                }
            }
            else
            {
                btnCadastro.Enabled = false;
                btnCadastrar.Enabled = false;

                pnlLogin.Left += 10;
                pnlCadastro.Left += 10;

                if (pnlCadastro.Left == 720)
                {
                    animatLogin = false;
                    btnCadastro.Enabled = true;
                    btnCadastrar.Enabled = true;
                    Animat.Stop();
                }
            }
        }


        #endregion


        private void btnCadastro_Click(object sender, EventArgs e)
        {
            Animat.Start();
           
            
        }

        #region Verificar Email
        public bool VerificandoEmail(string userEmail)
        {
            // fonte :https://www.youtube.com/watch?v=8zwuUyWvySg
            try
            {
                MailAddress mail = new MailAddress(userEmail);
                return mail.Address == userEmail;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        #endregion

        #region Cadastro

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

            try
            {
                if (txtCadUsuário.Text != txtCadUsuário.MarcaText && txtCadEmail.Text !=
                txtCadEmail.MarcaText && txtCadSenha.Text != txtCadSenha.MarcaText && txtCadConfSenha.Text != txtCadConfSenha.MarcaText)
                {
                    if (txtCadSenha.Text == txtCadConfSenha.Text)
                    {
                        if (VerificandoEmail(txtCadEmail.Text) == true)
                        {
                            string cod = string.Format("Insert into usuarios(nome , email , senha , userAdmin , notif) " +
                             "values('{0}','{1}','{2}',false,true)", txtCadUsuário.Text, txtCadEmail.Text, txtCadSenha.Text);

                            Business.ControlDatabase bd = new Business.ControlDatabase();


                            if (bd.AdicionarRegistro(cod) == true)
                            {                              
                                Animat.Start();
                            }
                            else
                            {
                                MessageBox.Show("Erro ao cadastrar");
                            }


                        }
                        else
                        {
                            MessageBox.Show("Digite um email valido...");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Conformar senha está diferente da senha: \n digite o conformar a senha corretamente.");
                    }
                }

                else
                {
                    MessageBox.Show("Preencha todos os campos");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :" + ex.Message);
            }
           

          


        }

        #endregion

        #region Função Recuperar Senha

        private void lblRecuperarSenha_Click(object sender, EventArgs e)
        {

            try
            {
                if (txtEmail.Text == txtEmail.MarcaText)
                {
                    MensagemLabel("Adicione o email da conta para recuperar");
                }
                else
                {
                    string getResout = string.Format("Select * from usuarios where email='{0}'", txtEmail.Text);

                    Business.ControlDatabase controlBD = new Business.ControlDatabase();

                    List<string> validacao = controlBD.VerifEmailRecuperar(getResout);

                    if (validacao[0] == "Realizado com sucesso")
                    {
                        //Adicionar Código no banco
                        string addCod = string.Format("Update usuarios set recuperarSenha='{0}' where email='{1}'", validacao[1], txtEmail.Text);


                        if (controlBD.AdicionarRegistro(addCod) == true)
                        {
                            //
                            UIConfigs.FrmConfigRecuperarSenha frmConfigRecuperar = new UIConfigs.FrmConfigRecuperarSenha();

                            frmConfigRecuperar.Email = txtEmail.Text;
                            frmConfigRecuperar.ShowDialog();
                        }
                        else
                        {
                            MessageBox.Show("erro na hora de adicionar o codigo no banco");
                        }


                    }
                    else
                    {
                        MensagemLabel("Digite um Email valido");
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
          
        }

        #endregion

        #region Design LblLink(lblRecuperarSenha);

        private void lblRecuperarSenha_MouseHover(object sender, EventArgs e)
        {
            lblRecuperarSenha.ForeColor = Color.FromArgb(46, 204, 113);
        }

        private void lblRecuperarSenha_MouseLeave(object sender, EventArgs e)
        {
            lblRecuperarSenha.ForeColor = Color.Gray;
        }


        #endregion

        #region Redes Sociais

        private void btnFacebook_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/Project-Drawer-108852847549663/");
        }

        private void btnInstagram_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/projectdrawer/");
        }

        private void btnTwitter_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/DrawerProject");
        }

        #endregion

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void lklVoltar_Click(object sender, EventArgs e)
        {
            Animat.Start();
        }
    }
}
