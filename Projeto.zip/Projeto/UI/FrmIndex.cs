﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class FrmIndex : Form
    {
        FrmLogin login;

        #region Variáveis do Menu

        // Variável(Panel) Da animação/Design de Seleção.
            // designPnl
        private Panel designPnl;

        //

        // Panel do Botão selecionado.
            //designClick
        private Panel designClick = new Panel();

        //

        // variável para saber qual botão está selecionado .
            // localSelect
        // descrição :

        // Os unicos botões que vão fazer a animação de Panel De seleção ,
        private Point localSelect;

        //                                                                  //

        #endregion

        public FrmIndex( FrmLogin Login)
        {
            InitializeComponent();

            login = Login;

            designPnl = new Panel(); // Variável Do Menu.
           
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        #region Sistema Menu


        //
        private void PanelMouserHover(Button btn)
        {
            if(localSelect != btn.Location) 
            {
                pnlMenu.Controls.Add(designPnl);
                designPnl.Size = new Size(btn.Width, 2);

                designPnl.BackColor = Color.Gainsboro;

                designPnl.Location = new Point(btn.Location.X, btn.Location.Y + btn.Height);
                designPnl.Visible = true;
                designPnl.BringToFront();
            }
           
            
        }

        // Sistema Para  Adicionar um novo Panel no Botão Clicado
        private void PanelClick(Button btn)
        {

            pnlMenu.Controls.Add(designClick);// Adicionar o Panel no Panel menu.

            designClick.Size = new Size(btn.Width, 2);// Tamanho do Panel.

            designClick.BackColor = Color.FromArgb(39, 174, 96); // Cor do Panel.

            designClick.Location = new Point(btn.Location.X, btn.Location.Y + btn.Height);// Local do Panel.
            designClick.Visible = true; // deixar o Panel visivel.

            designClick.BringToFront(); // adicionar na frente.

        }

        #region Animação Menu (Eventos Hover , Leave)

        // Quando o Mouser Passar no Botão

        private void btnProjeto_MouseHover(object sender, EventArgs e)
        {
            PanelMouserHover(btnProjeto);
        }

        private void btnEntrar_MouseHover(object sender, EventArgs e)
        {
            PanelMouserHover(btnEntrar);
        }

       

        private void btnConfig_MouseHover(object sender, EventArgs e)
        {
            PanelMouserHover(btnConfig);
        }
        //                                                               //

        // Quando o cursor sair no campo do botão

        private void btnProjeto_MouseLeave(object sender, EventArgs e)
        {
            designPnl.Visible = false;
        }
        private void btnEntrar_MouseLeave(object sender, EventArgs e)
        {
            designPnl.Visible = false;
        }

        private void btnChat_MouseLeave(object sender, EventArgs e)
        {
            designPnl.Visible = false;
        }

        private void btnConfig_MouseLeave(object sender, EventArgs e)
        {
            designPnl.Visible = false;
        }
        //                                                                  //
        #endregion




        #region Evento Click

        private void btnEntrar_Click(object sender, EventArgs e)
        {

            localSelect = new Point(btnEntrar.Location.X, btnEntrar.Location.Y);

            PanelClick(btnEntrar);

            AbrirFrm(new FrmEntrar());

        }
        private void btnProjeto_Click(object sender, EventArgs e)
        {

            localSelect = new Point(btnProjeto.Location.X, btnProjeto.Location.Y); // Sistema para indentificar qual btn foi selecionado.

            PanelClick(btnProjeto);

            AbrirFrm(new FrmProjeto());
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            localSelect = new Point(btnConfig.Location.X, btnConfig.Location.Y);// Sistema para indentificar qual btn foi selecionado.

            PanelClick(btnConfig);

            AbrirFrm(new FrmConfiguracoes());
        }


        #endregion

        #endregion

        #region Config Botões Padrão
        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion

        #region Método Para Abrir um Form dentro do outro
        private Form ActiveFrm = null;

        private void AbrirFrm(Form SelectFrm)
        {
            if(ActiveFrm != null)
            {
                ActiveFrm.Close();
            }

            ActiveFrm = SelectFrm;

            SelectFrm.TopLevel = false;

            SelectFrm.FormBorderStyle = FormBorderStyle.None;

            SelectFrm.Dock = DockStyle.Fill;

            pnlContainer.Controls.Add(SelectFrm);

            pnlContainer.Tag = SelectFrm;

            SelectFrm.BringToFront();

            SelectFrm.Show();
        }

        #endregion

        private void FrmIndex_Load(object sender, EventArgs e)
        {
            login.Hide();
        }


        #region Arrastar Form

        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #endregion

    }
}
