﻿namespace UI.UIConfigs
{
    partial class FrmEditTabela
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.pnlTextBox2 = new System.Windows.Forms.Panel();
            this.txtColumn = new FerramentasMod.TextBoxMod();
            this.panelMod3 = new FerramentasMod.PanelMod();
            this.btnConcluir = new FerramentasMod.ButtonElipse();
            this.btnExcluir = new FerramentasMod.ButtonElipse();
            this.panel1.SuspendLayout();
            this.pnlTextBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnCloser);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(411, 38);
            this.panel1.TabIndex = 0;
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(375, 3);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 12;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // pnlTextBox2
            // 
            this.pnlTextBox2.Controls.Add(this.txtColumn);
            this.pnlTextBox2.Controls.Add(this.panelMod3);
            this.pnlTextBox2.Location = new System.Drawing.Point(27, 64);
            this.pnlTextBox2.Name = "pnlTextBox2";
            this.pnlTextBox2.Size = new System.Drawing.Size(357, 38);
            this.pnlTextBox2.TabIndex = 18;
            // 
            // txtColumn
            // 
            this.txtColumn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.txtColumn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtColumn.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtColumn.ColorMarca = System.Drawing.Color.Silver;
            this.txtColumn.ForeColor = System.Drawing.Color.Silver;
            this.txtColumn.Location = new System.Drawing.Point(14, 10);
            this.txtColumn.MarcaText = "Nome da Coluna";
            this.txtColumn.Name = "txtColumn";
            this.txtColumn.Size = new System.Drawing.Size(340, 22);
            this.txtColumn.TabIndex = 1;
            this.txtColumn.Text = "Nome da Coluna";
            // 
            // panelMod3
            // 
            this.panelMod3.AnguloColor = 45F;
            this.panelMod3.borderRadius = 10;
            this.panelMod3.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.panelMod3.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.panelMod3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod3.ForeColor = System.Drawing.Color.White;
            this.panelMod3.Location = new System.Drawing.Point(0, 0);
            this.panelMod3.Name = "panelMod3";
            this.panelMod3.Size = new System.Drawing.Size(357, 38);
            this.panelMod3.TabIndex = 2;
            this.panelMod3.Texto = "";
            // 
            // btnConcluir
            // 
            this.btnConcluir.AnguloColor = 45F;
            this.btnConcluir.borderRadius = 10;
            this.btnConcluir.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnConcluir.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnConcluir.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnConcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConcluir.EfeitoTexto = true;
            this.btnConcluir.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConcluir.ForeColor = System.Drawing.Color.White;
            this.btnConcluir.Location = new System.Drawing.Point(272, 108);
            this.btnConcluir.Name = "btnConcluir";
            this.btnConcluir.Size = new System.Drawing.Size(112, 29);
            this.btnConcluir.TabIndex = 19;
            this.btnConcluir.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConcluir.Texto = "Novo";
            this.btnConcluir.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConcluir.Click += new System.EventHandler(this.btnConcluir_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.AnguloColor = 45F;
            this.btnExcluir.borderRadius = 10;
            this.btnExcluir.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnExcluir.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(57)))), ((int)(((byte)(43)))));
            this.btnExcluir.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.EfeitoTexto = true;
            this.btnExcluir.Enabled = false;
            this.btnExcluir.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.ForeColor = System.Drawing.Color.White;
            this.btnExcluir.Location = new System.Drawing.Point(27, 108);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(112, 29);
            this.btnExcluir.TabIndex = 20;
            this.btnExcluir.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.Texto = "Excluir";
            this.btnExcluir.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // FrmEditTabela
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.ClientSize = new System.Drawing.Size(411, 168);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnConcluir);
            this.Controls.Add(this.pnlTextBox2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmEditTabela";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmEditTabela";
            this.panel1.ResumeLayout(false);
            this.pnlTextBox2.ResumeLayout(false);
            this.pnlTextBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlTextBox2;
        private FerramentasMod.PanelMod panelMod3;
        public FerramentasMod.ButtonElipse btnConcluir;
        public FerramentasMod.ButtonElipse btnExcluir;
        private FerramentasMod.ButtonIconMod btnCloser;
        public FerramentasMod.TextBoxMod txtColumn;
    }
}