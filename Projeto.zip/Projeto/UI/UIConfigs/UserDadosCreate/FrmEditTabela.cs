﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class FrmEditTabela : Form
    {
        public string select;

        public FrmCreateDadosExcelPG3 frm = new FrmCreateDadosExcelPG3();

        public int quantColuna;

        public int NumericCuluna;

        public FrmEditTabela()
        {
            InitializeComponent();
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        private void btnCloser_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("deseja excluir a coluna :" + NumericCuluna + "?",
               "Todos os dados da coluna seram apagados!!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                frm.dgvDados.Columns.RemoveAt(NumericCuluna);

                frm.quant -= 1;

                this.Close();
            }
        }

        private void btnConcluir_Click(object sender, EventArgs e)
        {
            if (select == "Novo")
            {
                int verificarHeaders =0;

                
                for(int i = 0; i < frm.dgvDados.Columns.Count; i++)
                {
                    if(frm.dgvDados.Columns[i].HeaderText == txtColumn.Text)
                    {

                        verificarHeaders ++;

                    }
                }

                if(verificarHeaders == 0)
                {
                    frm.dgvDados.FirstDisplayedScrollingColumnIndex = frm.dgvDados.ColumnCount - 1;

                    frm.dgvDados.Columns[quantColuna - 1].HeaderText = txtColumn.Text;

                    txtColumn.Text = null;

                    this.Close();
                }
                else
                {
                    MessageBox.Show("Já existe uma coluna com o mesmo nome ...");
                }
               
            }
            else
            {

                frm.dgvDados.Columns[NumericCuluna].HeaderText = txtColumn.Text;
                this.Close();

            }

        }
    }
}
