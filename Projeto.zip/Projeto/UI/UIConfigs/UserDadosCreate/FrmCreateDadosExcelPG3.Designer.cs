﻿namespace UI.UIConfigs
{
    partial class FrmCreateDadosExcelPG3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnMini = new FerramentasMod.ButtonIconMod();
            this.btnWindMax = new FerramentasMod.ButtonIconMod();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.btnWindMini = new FerramentasMod.ButtonIconMod();
            this.label2 = new System.Windows.Forms.Label();
            this.ptbTema = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvDados = new System.Windows.Forms.DataGridView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pnlContainerTable = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAdicionarTabela = new FerramentasMod.ButtonElipse();
            this.btnCriarExcel = new FerramentasMod.ButtonElipse();
            this.btnAdicionarColuna = new FerramentasMod.ButtonElipse();
            this.pnlTextBox2 = new System.Windows.Forms.Panel();
            this.txtNameTable = new FerramentasMod.TextBoxMod();
            this.panelMod3 = new FerramentasMod.PanelMod();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbTema)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).BeginInit();
            this.panel4.SuspendLayout();
            this.pnlTextBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Configuração Padrão";
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.btnMini);
            this.pnlTop.Controls.Add(this.btnWindMax);
            this.pnlTop.Controls.Add(this.btnCloser);
            this.pnlTop.Controls.Add(this.btnWindMini);
            this.pnlTop.Controls.Add(this.label2);
            this.pnlTop.Controls.Add(this.ptbTema);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(806, 53);
            this.pnlTop.TabIndex = 7;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            // 
            // btnMini
            // 
            this.btnMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMini.FlatAppearance.BorderSize = 0;
            this.btnMini.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnMini.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnMini.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMini.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnMini.IconChar = FontAwesome.Sharp.IconChar.Minus;
            this.btnMini.IconColor = System.Drawing.Color.White;
            this.btnMini.IconHover = System.Drawing.Color.DarkGray;
            this.btnMini.IconLeave = System.Drawing.Color.White;
            this.btnMini.IconSize = 18;
            this.btnMini.Location = new System.Drawing.Point(675, 12);
            this.btnMini.Name = "btnMini";
            this.btnMini.Rotation = 0D;
            this.btnMini.Size = new System.Drawing.Size(33, 31);
            this.btnMini.TabIndex = 12;
            this.btnMini.UseVisualStyleBackColor = true;
            this.btnMini.Click += new System.EventHandler(this.btnMini_Click);
            // 
            // btnWindMax
            // 
            this.btnWindMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWindMax.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWindMax.FlatAppearance.BorderSize = 0;
            this.btnWindMax.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnWindMax.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnWindMax.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWindMax.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnWindMax.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            this.btnWindMax.IconColor = System.Drawing.Color.White;
            this.btnWindMax.IconHover = System.Drawing.Color.DarkGray;
            this.btnWindMax.IconLeave = System.Drawing.Color.White;
            this.btnWindMax.IconSize = 18;
            this.btnWindMax.Location = new System.Drawing.Point(719, 12);
            this.btnWindMax.Name = "btnWindMax";
            this.btnWindMax.Rotation = 0D;
            this.btnWindMax.Size = new System.Drawing.Size(33, 31);
            this.btnWindMax.TabIndex = 11;
            this.btnWindMax.UseVisualStyleBackColor = true;
            this.btnWindMax.Click += new System.EventHandler(this.btnWindMax_Click);
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(763, 12);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 10;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // btnWindMini
            // 
            this.btnWindMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWindMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWindMini.FlatAppearance.BorderSize = 0;
            this.btnWindMini.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnWindMini.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnWindMini.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWindMini.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnWindMini.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            this.btnWindMini.IconColor = System.Drawing.Color.White;
            this.btnWindMini.IconHover = System.Drawing.Color.DarkGray;
            this.btnWindMini.IconLeave = System.Drawing.Color.White;
            this.btnWindMini.IconSize = 18;
            this.btnWindMini.Location = new System.Drawing.Point(719, 12);
            this.btnWindMini.Name = "btnWindMini";
            this.btnWindMini.Rotation = 0D;
            this.btnWindMini.Size = new System.Drawing.Size(33, 31);
            this.btnWindMini.TabIndex = 13;
            this.btnWindMini.UseVisualStyleBackColor = true;
            this.btnWindMini.Click += new System.EventHandler(this.btnWindMini_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Gainsboro;
            this.label2.Location = new System.Drawing.Point(74, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Criar tabelas no Excel";
            // 
            // ptbTema
            // 
            this.ptbTema.Dock = System.Windows.Forms.DockStyle.Left;
            this.ptbTema.Image = global::UI.Properties.Resources.iconeExcel;
            this.ptbTema.Location = new System.Drawing.Point(0, 0);
            this.ptbTema.Name = "ptbTema";
            this.ptbTema.Size = new System.Drawing.Size(68, 53);
            this.ptbTema.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbTema.TabIndex = 0;
            this.ptbTema.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 53);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(806, 2);
            this.panel3.TabIndex = 8;
            // 
            // dgvDados
            // 
            this.dgvDados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDados.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvDados.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.dgvDados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDados.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDados.ColumnHeadersHeight = 35;
            this.dgvDados.EnableHeadersVisualStyles = false;
            this.dgvDados.Location = new System.Drawing.Point(31, 141);
            this.dgvDados.Name = "dgvDados";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDados.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDados.RowHeadersVisible = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            this.dgvDados.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDados.Size = new System.Drawing.Size(748, 299);
            this.dgvDados.TabIndex = 2;
            this.dgvDados.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvDados_ColumnHeaderMouseClick);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.pnlContainerTable);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(12, 446);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(767, 96);
            this.panel4.TabIndex = 12;
            // 
            // pnlContainerTable
            // 
            this.pnlContainerTable.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlContainerTable.AutoScroll = true;
            this.pnlContainerTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.pnlContainerTable.Location = new System.Drawing.Point(14, 25);
            this.pnlContainerTable.Name = "pnlContainerTable";
            this.pnlContainerTable.Size = new System.Drawing.Size(745, 65);
            this.pnlContainerTable.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tabelas";
            // 
            // btnAdicionarTabela
            // 
            this.btnAdicionarTabela.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdicionarTabela.AnguloColor = 45F;
            this.btnAdicionarTabela.borderRadius = 10;
            this.btnAdicionarTabela.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAdicionarTabela.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnAdicionarTabela.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAdicionarTabela.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionarTabela.EfeitoTexto = true;
            this.btnAdicionarTabela.ForeColor = System.Drawing.Color.White;
            this.btnAdicionarTabela.Location = new System.Drawing.Point(31, 545);
            this.btnAdicionarTabela.Name = "btnAdicionarTabela";
            this.btnAdicionarTabela.Size = new System.Drawing.Size(162, 31);
            this.btnAdicionarTabela.TabIndex = 14;
            this.btnAdicionarTabela.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarTabela.Texto = "Adicionar Tabela";
            this.btnAdicionarTabela.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarTabela.Click += new System.EventHandler(this.btnAdicionarTabela_Click);
            // 
            // btnCriarExcel
            // 
            this.btnCriarExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCriarExcel.AnguloColor = 45F;
            this.btnCriarExcel.borderRadius = 35;
            this.btnCriarExcel.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnCriarExcel.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(106)))), ((int)(((byte)(45)))));
            this.btnCriarExcel.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnCriarExcel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCriarExcel.EfeitoTexto = true;
            this.btnCriarExcel.ForeColor = System.Drawing.Color.White;
            this.btnCriarExcel.Location = new System.Drawing.Point(663, 545);
            this.btnCriarExcel.Name = "btnCriarExcel";
            this.btnCriarExcel.Size = new System.Drawing.Size(113, 36);
            this.btnCriarExcel.TabIndex = 15;
            this.btnCriarExcel.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarExcel.Texto = "Criar";
            this.btnCriarExcel.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarExcel.Click += new System.EventHandler(this.btnCriarExcel_Click);
            // 
            // btnAdicionarColuna
            // 
            this.btnAdicionarColuna.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdicionarColuna.AnguloColor = 45F;
            this.btnAdicionarColuna.borderRadius = 10;
            this.btnAdicionarColuna.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnAdicionarColuna.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(106)))), ((int)(((byte)(45)))));
            this.btnAdicionarColuna.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnAdicionarColuna.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionarColuna.EfeitoTexto = true;
            this.btnAdicionarColuna.ForeColor = System.Drawing.Color.White;
            this.btnAdicionarColuna.Location = new System.Drawing.Point(614, 97);
            this.btnAdicionarColuna.Name = "btnAdicionarColuna";
            this.btnAdicionarColuna.Size = new System.Drawing.Size(162, 31);
            this.btnAdicionarColuna.TabIndex = 16;
            this.btnAdicionarColuna.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarColuna.Texto = "Adicionar Coluna";
            this.btnAdicionarColuna.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarColuna.Click += new System.EventHandler(this.btnAdicionarColuna_Click);
            // 
            // pnlTextBox2
            // 
            this.pnlTextBox2.Controls.Add(this.txtNameTable);
            this.pnlTextBox2.Controls.Add(this.panelMod3);
            this.pnlTextBox2.Location = new System.Drawing.Point(31, 97);
            this.pnlTextBox2.Name = "pnlTextBox2";
            this.pnlTextBox2.Size = new System.Drawing.Size(244, 38);
            this.pnlTextBox2.TabIndex = 17;
            // 
            // txtNameTable
            // 
            this.txtNameTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.txtNameTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNameTable.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtNameTable.ColorMarca = System.Drawing.Color.Silver;
            this.txtNameTable.ForeColor = System.Drawing.Color.Silver;
            this.txtNameTable.Location = new System.Drawing.Point(14, 10);
            this.txtNameTable.MarcaText = "Nome Tabela";
            this.txtNameTable.Name = "txtNameTable";
            this.txtNameTable.Size = new System.Drawing.Size(230, 18);
            this.txtNameTable.TabIndex = 1;
            this.txtNameTable.Text = "Nome Tabela";
            // 
            // panelMod3
            // 
            this.panelMod3.AnguloColor = 45F;
            this.panelMod3.borderRadius = 10;
            this.panelMod3.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.panelMod3.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.panelMod3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod3.ForeColor = System.Drawing.Color.White;
            this.panelMod3.Location = new System.Drawing.Point(0, 0);
            this.panelMod3.Name = "panelMod3";
            this.panelMod3.Size = new System.Drawing.Size(244, 38);
            this.panelMod3.TabIndex = 2;
            this.panelMod3.Texto = "";
            // 
            // FrmCreateDadosExcelPG3
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.ClientSize = new System.Drawing.Size(806, 589);
            this.Controls.Add(this.pnlTextBox2);
            this.Controls.Add(this.btnAdicionarColuna);
            this.Controls.Add(this.btnCriarExcel);
            this.Controls.Add(this.btnAdicionarTabela);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.dgvDados);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmCreateDadosExcelPG3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmConfigCriarExcel";
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbTema)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pnlTextBox2.ResumeLayout(false);
            this.pnlTextBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private FerramentasMod.ButtonIconMod btnMini;
        private FerramentasMod.ButtonIconMod btnWindMax;
        private FerramentasMod.ButtonIconMod btnCloser;
        private FerramentasMod.ButtonIconMod btnWindMini;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel pnlContainerTable;
        private System.Windows.Forms.Label label3;
        private FerramentasMod.ButtonElipse btnAdicionarTabela;
        private FerramentasMod.ButtonElipse btnCriarExcel;
        private FerramentasMod.ButtonElipse btnAdicionarColuna;
        private System.Windows.Forms.Panel pnlTextBox2;
        private FerramentasMod.TextBoxMod txtNameTable;
        private FerramentasMod.PanelMod panelMod3;
        public System.Windows.Forms.DataGridView dgvDados;
        public System.Windows.Forms.PictureBox ptbTema;
    }
}