﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace UI.UIConfigs.UserDadosCreate
{
    public partial class FrmCreateDadosPG1 : Form
    {

        public FrmConfigDados frmDados;

        public bool CriarForaP = false;

        private string Diretory;

        public FrmCreateDadosPG1()
        {
            InitializeComponent();

            
        }

        private void btnProximoPG2_Click(object sender, EventArgs e)
        {
            if(txbNomeArquivo.Text != txbNomeArquivo.MarcaText)
            {
                if (cmbTipoArquivoDados.SelectedItem.ToString() == "Excel")
                {
                    if(CriarForaP == false)
                    {
                        FrmCreateDadosExcelPG3 excel1 = new FrmCreateDadosExcelPG3();

                        excel1.ptbTema.Image = Properties.Resources.iconeExcel;

                        excel1.NameFile = txbNomeArquivo.Text;
                        excel1.diretoryFile = "None";

                        excel1.ShowDialog();
                    }
                    else
                    {
                        if(Diretory != txtDiretory.MarcaText)
                        {
                            FrmCreateDadosExcelPG3 excel1 = new FrmCreateDadosExcelPG3();

                            excel1.ptbTema.Image = Properties.Resources.iconeExcel;

                            excel1.NameFile = txbNomeArquivo.Text;

                            excel1.diretoryFile = Diretory;

                            excel1.ShowDialog();
                        }
                    }

                }

                else if (cmbTipoArquivoDados.SelectedItem.ToString() == "Bloco de notas")
                {
                    if (CriarForaP == false)
                    {
                        FrmCreateDadosExcelPG3 excel1 = new FrmCreateDadosExcelPG3();

                        excel1.ptbTema.Image = Properties.Resources.iconBlocoDeNotas;

                        excel1.NameFile = txbNomeArquivo.Text;
                        excel1.diretoryFile = "None";

                        excel1.ShowDialog();
                    }
                    else
                    {
                        if (Diretory != txtDiretory.MarcaText)
                        {
                            FrmCreateDadosExcelPG3 excel1 = new FrmCreateDadosExcelPG3();

                            excel1.ptbTema.Image = Properties.Resources.iconBlocoDeNotas;

                            excel1.NameFile = txbNomeArquivo.Text;
                            excel1.diretoryFile = Diretory;

                            excel1.ShowDialog();
                        }
                    }

                }
            }
            else
            {
                MessageBox.Show("Digite um nome para o arquivo");
            }

           


        }

        private void cmbTipoArquivoDados_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void FrmCreateDadosPG1_Load(object sender, EventArgs e)
        {
            cmbTipoArquivoDados.SelectedIndex = 0;

            if (CriarForaP == true)
            {
                pnlCriarTabelaSemP.Enabled = true;
            }
        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog diretory = new FolderBrowserDialog();

            if (diretory.ShowDialog() == DialogResult.OK)
            {
                Diretory = diretory.SelectedPath;

                txtDiretory.Text = diretory.SelectedPath;
            }
        }

        private void txtDiretory_MouseHover(object sender, EventArgs e)
        {
            ToolTip descricao = new ToolTip();

            ; ;  descricao.BackColor = Color.FromArgb(88, 88, 88);
            if (descricao.Active != true)
            {
                descricao.SetToolTip(this.txtDiretory, Diretory);
            }

        }
    }
}
