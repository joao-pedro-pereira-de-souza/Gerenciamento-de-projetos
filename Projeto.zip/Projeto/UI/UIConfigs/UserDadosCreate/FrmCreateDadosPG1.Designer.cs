﻿namespace UI.UIConfigs.UserDadosCreate
{
    partial class FrmCreateDadosPG1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnProximoPG2 = new FerramentasMod.ButtonElipse();
            this.cmbTipoArquivoDados = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txbNomeArquivo = new FerramentasMod.TextBoxMod();
            this.panelMod1 = new FerramentasMod.PanelMod();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtDiretory = new FerramentasMod.TextBoxMod();
            this.panelMod2 = new FerramentasMod.PanelMod();
            this.btnBrowser = new FerramentasMod.ButtonElipse();
            this.pnlCriarTabelaSemP = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.pnlCriarTabelaSemP.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Gainsboro;
            this.label3.Location = new System.Drawing.Point(129, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(523, 50);
            this.label3.TabIndex = 14;
            this.label3.Text = "Crie um conjunto de dados para usar em projetos no app.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 21);
            this.label2.TabIndex = 13;
            this.label2.Text = "Informação :";
            // 
            // btnProximoPG2
            // 
            this.btnProximoPG2.AnguloColor = 45F;
            this.btnProximoPG2.borderRadius = 10;
            this.btnProximoPG2.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnProximoPG2.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnProximoPG2.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnProximoPG2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProximoPG2.EfeitoTexto = true;
            this.btnProximoPG2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProximoPG2.ForeColor = System.Drawing.Color.White;
            this.btnProximoPG2.Location = new System.Drawing.Point(607, 343);
            this.btnProximoPG2.Name = "btnProximoPG2";
            this.btnProximoPG2.Size = new System.Drawing.Size(112, 36);
            this.btnProximoPG2.TabIndex = 12;
            this.btnProximoPG2.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProximoPG2.Texto = "Próximo";
            this.btnProximoPG2.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProximoPG2.Click += new System.EventHandler(this.btnProximoPG2_Click);
            // 
            // cmbTipoArquivoDados
            // 
            this.cmbTipoArquivoDados.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipoArquivoDados.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cmbTipoArquivoDados.FormattingEnabled = true;
            this.cmbTipoArquivoDados.Items.AddRange(new object[] {
            "Excel",
            "Banco",
            "Bloco de notas"});
            this.cmbTipoArquivoDados.Location = new System.Drawing.Point(30, 128);
            this.cmbTipoArquivoDados.Name = "cmbTipoArquivoDados";
            this.cmbTipoArquivoDados.Size = new System.Drawing.Size(316, 29);
            this.cmbTipoArquivoDados.TabIndex = 11;
            this.cmbTipoArquivoDados.Tag = "";
            this.cmbTipoArquivoDados.SelectedIndexChanged += new System.EventHandler(this.cmbTipoArquivoDados_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panel1.Controls.Add(this.txbNomeArquivo);
            this.panel1.Controls.Add(this.panelMod1);
            this.panel1.Location = new System.Drawing.Point(30, 185);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(316, 38);
            this.panel1.TabIndex = 10;
            // 
            // txbNomeArquivo
            // 
            this.txbNomeArquivo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.txbNomeArquivo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbNomeArquivo.ColorDig = System.Drawing.Color.Gainsboro;
            this.txbNomeArquivo.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txbNomeArquivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txbNomeArquivo.Location = new System.Drawing.Point(14, 8);
            this.txbNomeArquivo.MarcaText = "Nome do arquivo";
            this.txbNomeArquivo.Name = "txbNomeArquivo";
            this.txbNomeArquivo.Size = new System.Drawing.Size(299, 22);
            this.txbNomeArquivo.TabIndex = 1;
            this.txbNomeArquivo.Text = "Nome do arquivo";
            // 
            // panelMod1
            // 
            this.panelMod1.AnguloColor = 45F;
            this.panelMod1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.panelMod1.borderRadius = 10;
            this.panelMod1.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod1.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod1.ForeColor = System.Drawing.Color.White;
            this.panelMod1.Location = new System.Drawing.Point(0, 0);
            this.panelMod1.Name = "panelMod1";
            this.panelMod1.Size = new System.Drawing.Size(316, 38);
            this.panelMod1.TabIndex = 2;
            this.panelMod1.Texto = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 21);
            this.label1.TabIndex = 9;
            this.label1.Text = "Arquivo de Dados :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::UI.Properties.Resources.iconGeratTables;
            this.pictureBox1.Location = new System.Drawing.Point(440, 59);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(279, 184);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(440, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(292, 52);
            this.label4.TabIndex = 16;
            this.label4.Text = "Na plataforma você poderá criar no excel e bloco de notas";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panel2.Controls.Add(this.txtDiretory);
            this.panel2.Controls.Add(this.panelMod2);
            this.panel2.Location = new System.Drawing.Point(17, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(254, 38);
            this.panel2.TabIndex = 17;
            // 
            // txtDiretory
            // 
            this.txtDiretory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.txtDiretory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiretory.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtDiretory.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtDiretory.Enabled = false;
            this.txtDiretory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtDiretory.Location = new System.Drawing.Point(14, 8);
            this.txtDiretory.MarcaText = "Diretório ";
            this.txtDiretory.Name = "txtDiretory";
            this.txtDiretory.Size = new System.Drawing.Size(237, 22);
            this.txtDiretory.TabIndex = 1;
            this.txtDiretory.Text = "Diretório ";
            this.txtDiretory.MouseHover += new System.EventHandler(this.txtDiretory_MouseHover);
            // 
            // panelMod2
            // 
            this.panelMod2.AnguloColor = 45F;
            this.panelMod2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.panelMod2.borderRadius = 10;
            this.panelMod2.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod2.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod2.ForeColor = System.Drawing.Color.White;
            this.panelMod2.Location = new System.Drawing.Point(0, 0);
            this.panelMod2.Name = "panelMod2";
            this.panelMod2.Size = new System.Drawing.Size(254, 38);
            this.panelMod2.TabIndex = 2;
            this.panelMod2.Texto = "";
            // 
            // btnBrowser
            // 
            this.btnBrowser.AnguloColor = 45F;
            this.btnBrowser.borderRadius = 10;
            this.btnBrowser.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnBrowser.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnBrowser.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnBrowser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowser.EfeitoTexto = true;
            this.btnBrowser.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowser.ForeColor = System.Drawing.Color.White;
            this.btnBrowser.Location = new System.Drawing.Point(277, 17);
            this.btnBrowser.Name = "btnBrowser";
            this.btnBrowser.Size = new System.Drawing.Size(56, 36);
            this.btnBrowser.TabIndex = 18;
            this.btnBrowser.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowser.Texto = "...";
            this.btnBrowser.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowser.Click += new System.EventHandler(this.btnBrowser_Click);
            // 
            // pnlCriarTabelaSemP
            // 
            this.pnlCriarTabelaSemP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCriarTabelaSemP.Controls.Add(this.panel2);
            this.pnlCriarTabelaSemP.Controls.Add(this.btnBrowser);
            this.pnlCriarTabelaSemP.Enabled = false;
            this.pnlCriarTabelaSemP.Location = new System.Drawing.Point(12, 249);
            this.pnlCriarTabelaSemP.Name = "pnlCriarTabelaSemP";
            this.pnlCriarTabelaSemP.Size = new System.Drawing.Size(362, 71);
            this.pnlCriarTabelaSemP.TabIndex = 19;
            // 
            // FrmCreateDadosPG1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.ClientSize = new System.Drawing.Size(744, 399);
            this.Controls.Add(this.pnlCriarTabelaSemP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnProximoPG2);
            this.Controls.Add(this.cmbTipoArquivoDados);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmCreateDadosPG1";
            this.Text = "FrmCreateDadosPG1";
            this.Load += new System.EventHandler(this.FrmCreateDadosPG1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlCriarTabelaSemP.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private FerramentasMod.ButtonElipse btnProximoPG2;
        private System.Windows.Forms.ComboBox cmbTipoArquivoDados;
        private System.Windows.Forms.Panel panel1;
        private FerramentasMod.TextBoxMod txbNomeArquivo;
        private FerramentasMod.PanelMod panelMod1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private FerramentasMod.TextBoxMod txtDiretory;
        private FerramentasMod.PanelMod panelMod2;
        private FerramentasMod.ButtonElipse btnBrowser;
        private System.Windows.Forms.Panel pnlCriarTabelaSemP;
    }
}