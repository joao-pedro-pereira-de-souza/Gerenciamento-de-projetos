﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SystemExcel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace UI.UIConfigs
{
    public partial class FrmCreateDadosExcelPG3 : Form
    {
        public string diretoryFile;

        public string NameFile;

        //Quantidade de colunas na tabela.
        public int quant;
        //

        // Tabelas.
        DataSet SetTables = new DataSet();
        //

        //Front-End.
        int contadorTable = 0;
        int topControl = 10;
        int leftControl = 10;
        //
        public FrmCreateDadosExcelPG3()
        {
            InitializeComponent();
       
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        #region Sistema de Arrastar formulário


        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion

       

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #endregion


        private void btnCloser_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void abrirTabela(int SelectTable)
        {

            dgvDados.Columns.Clear();

            dgvDados.DataSource = SetTables.Tables[SelectTable];
        }


        #region Criar Excel



        private void btnCriarExcel_Click(object sender, EventArgs e)
        {
            // Tela Splash Screen
            Thread thre = new Thread(new ThreadStart(formRun));
            //

            try
            {
              if(SetTables.Tables.Count > 0)
              {
                    if (txtNameTable.Text != txtNameTable.MarcaText)
                    {
                        if (SetTables.Tables.Count >= 0 && SetTables != null)
                        {
                            thre.Start();

                            Thread.Sleep(5000);

                            // classe que cria o excel com os dados no processo.
                            // dados (diretótio , tabelas , planilha).

                            Business.ControlFileProject pasta = new Business.ControlFileProject();

                            pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Dados", Business.DadosUsuario.DiretoryProject + @"\", "Dados");

                            SystemCreateExcel criarEx = new SystemCreateExcel();


                            if (diretoryFile == "None")
                            {
                                criarEx.CreateTables(Business.DadosUsuario.DiretoryProject + @"\Dados\", SetTables, NameFile);
                            }
                            else
                            {
                                criarEx.CreateTables(diretoryFile + @"\", SetTables, NameFile);
                            }

                            SetTables.Clear();

                            pnlContainerTable.Controls.Clear();


                          
                            thre.Abort();

                          
                            this.Close();



                        }
                        else
                        {


                            MessageBox.Show("Erro : " + "\n\n" + "Você precisa criar pelo menos uma tabela para criar um arquivo excel");

                        }
                    }
                    else
                    {
                        MessageBox.Show("Digite o nome da Tabela");
                    }
              }
              else
              {
                    MessageBox.Show("Adicione no minimo uma tabela ");
              }
                

            }
            catch (Exception ex)
            {
                thre.Abort();
               // SplashScreen.lblStatus.Text = "Erro :" + ex.Message;
               // SplashScreen.Hide();
                MessageBox.Show("Erro : " + "\n\n" + "Ocorreu um erro na criação do arquivo:" + ex.Message + " \n Verifique se o arquivo está nas normas");
            }
        }

        // Rodar a Tela Splash Screen.
        private void formRun()
        {

            try
            {
                Application.Run(new FrmProgress());
            }
            catch (Exception)
            {

            }
        }


        #endregion



        private void btnAdicionarTabela_Click(object sender, EventArgs e)
        {
            #region CriarTabela


            try
            {
                if (dgvDados.Rows.Count > 0)
                {
                    DataTable Table = new DataTable();

                    Table.TableName = txtNameTable.Text;

                    #region Criar um DataTable = DataGrid


                    for (int h = 0; h < dgvDados.Columns.Count; h++) // Sistema para criar os cabeçalhos do datatable.
                    {
                        ///MessageBox.Show(h.ToString());
                        Table.Columns.Add(dgvDados.Columns[h].HeaderText);


                    }

                    // Fonte : https://www.codeproject.com/Questions/1155155/Exporting-datagridview-selectedrows-to-a-datatable.

                    for (int i = 0; i < dgvDados.Rows.Count - 1; i++)
                    {
                        for (int o = 0; o < dgvDados.Columns.Count; o++)
                        {

                            if (dgvDados.Rows[i].Cells[0] != null)
                            {
                                Table.Rows.Add();
                                Table.Rows[i][o] = dgvDados.Rows[i].Cells[o].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("preencha pelo menos uma celula da linha : " + i);
                            }


                        }
                    }

                    #endregion


                    SetTables.Tables.Add(Table);

                    #region Adicionar Um Card (Um objeto no Form)

                    // Adiconar um controle para amarzenar a tabela criada , assim o usuário poderá resgatar-
                    // essa tabela para editar , antes de concluír a criação do arquivo.

                    //Front-end.
                    // 
                    UserTabela userTable = new UserTabela();
                    //Adicionado as variáveis do card
                    userTable.numericTable = contadorTable;
                    userTable.ControleTable = this;
                  
                    userTable.tabela = Table;


                    pnlContainerTable.Controls.Add(userTable);

                    userTable.Top = topControl;

                    userTable.Left = leftControl;

                    leftControl += (userTable.Width + 20);

                    pnlContainerTable.Tag = userTable;

                    //Limpando Campos para o próxima tabela.
                    txtNameTable.Text = null;

                    dgvDados.Columns.Clear();

                    quant = 0;

                    //

                    contadorTable++;//Adicionado o valor do próximo card.

                    userTable.Show();//mostrar na tela.
                    //

                    #endregion

                }
                else
                {

                    MessageBox.Show("erro :" + " Tabela Vazia!! \n\n" + "Preencha a tabela para poder adicionar uma no excel");



                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
               
            #endregion
        }


        // Deletar a tabela selecionada nas opções de tabela ou visualizar tabela.
        public void DeletarTabela(int numeric)
        {
           
            SetTables.Tables.RemoveAt(numeric);
            quant = 0;
            contadorTable--;

        }

        #region Sistema de Edição na tabela

        private void dgvDados_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            UIConfigs.FrmEditTabela edit = new UIConfigs.FrmEditTabela();

            edit.frm = this;

            edit.NumericCuluna = e.ColumnIndex;
            edit.txtColumn.Text = dgvDados.Columns[e.ColumnIndex].HeaderText;

            edit.btnConcluir.Text = "Editar";

            edit.select = "editor";
            edit.btnExcluir.Enabled = true;
            edit.ShowDialog();
        }

        private void btnAdicionarColuna_Click(object sender, EventArgs e)
        {
            quant++;

            dgvDados.ColumnCount = quant;

            UIConfigs.FrmEditTabela edit = new UIConfigs.FrmEditTabela();
            dgvDados.Columns[quant -1].HeaderText = "Coluna";
            edit.frm = this;
        
            edit.quantColuna = quant;
            edit.select = "Novo";
            edit.btnConcluir.Text = "Novo";


            edit.ShowDialog();


        }

        #endregion

        #region Botões padrão

        private void btnMini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnWindMax_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;

            btnWindMax.Enabled = false;
            btnWindMini.Enabled = true;
        }

        private void btnWindMini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;

            btnWindMax.Enabled = true;
            btnWindMini.Enabled = false;
        }

        #endregion
    }
}
