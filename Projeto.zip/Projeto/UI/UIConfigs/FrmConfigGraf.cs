﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;

namespace UI.UIConfigs
{
    public partial class FrmConfigGraf : Form
    {


        public bool CreateForaP = false;


        public Color CorGraf = Color.FromArgb(46, 204, 113);

        #region Variáveis Design/Select
        // Animação Menus
        bool selectPnlTable = true;
        bool selectPnlDesign = true;
        //
        //variável gráfico selecionado.
       public  string SelectChart = "Columns";
        //
        //variável cores do gráfico
        string SelectColor = "Padrao";
        //

        #endregion

        // Variável Splash Screen.
 

        public  FrmConfigGraf()
        {
            InitializeComponent();

            ControlFrmsStatOpen.controlGraf = this;

        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        #region Menu de opões de cores(Gráfico)


        #region Sistema Select Opções de cores(FrontEnd)
        /*
        public void SelectOpColor()
        {
            if (SelectColor == "Padrao")
            {
                btnCorPardao.BackColor = Color.FromArgb(88, 88, 88);
                btnCorEditar.BackColor = Color.FromArgb(51, 51, 51);

            }

            else if (SelectColor == "Editado")
            {
                btnCorPardao.BackColor = Color.FromArgb(51, 51, 51);
                btnCorEditar.BackColor = Color.FromArgb(88, 88, 88);
            }
        }
        */
        #endregion
        /*
        private void btnCorPardao_Click(object sender, EventArgs e)
        {
            SelectColor = "Padrao";

            SelectOpColor();
        }

        private void btnCorEditar_Click(object sender, EventArgs e)
        {
            SelectColor = "Editado";

            SelectOpColor();
        }

        */

        #endregion

        #region Menu de opções Gráfico

        #region Sistema de seleção nas opções de gráficos(FrontEnd)

        public void SystemOpSelect()
        {
            if (SelectChart == "Columns")
            {
                btnChartColuns.BackColor = Color.FromArgb(88, 88, 88);

                btnChartBar.BackColor = Color.FromArgb(51, 51, 51);
                btnChartPie.BackColor = Color.FromArgb(51, 51, 51);
                btnChartLine.BackColor = Color.FromArgb(51, 51, 51);
                btnLinePoint.BackColor = Color.FromArgb(51, 51, 51);
                btnArea.BackColor = Color.FromArgb(51, 51, 51);
                
            }

            else if (SelectChart == "Line")
            {
                btnChartLine.BackColor = Color.FromArgb(88, 88, 88);

                btnChartColuns.BackColor = Color.FromArgb(51, 51, 51);
                btnChartBar.BackColor = Color.FromArgb(51, 51, 51);
                btnChartPie.BackColor = Color.FromArgb(51, 51, 51);
                btnLinePoint.BackColor = Color.FromArgb(51, 51, 51);
                btnArea.BackColor = Color.FromArgb(51, 51, 51);
               

            }

            else if (SelectChart == "Bar")
            {
                btnChartBar.BackColor = Color.FromArgb(88, 88, 88);

                btnChartLine.BackColor = Color.FromArgb(51, 51, 51);
                btnChartColuns.BackColor = Color.FromArgb(51, 51, 51);
                btnChartPie.BackColor = Color.FromArgb(51, 51, 51);
                btnLinePoint.BackColor = Color.FromArgb(51, 51, 51);
                btnArea.BackColor = Color.FromArgb(51, 51, 51);
               

            }

            else if (SelectChart == "Pie")
            {

                btnChartPie.BackColor = Color.FromArgb(88, 88, 88);

                btnChartLine.BackColor = Color.FromArgb(51, 51, 51);
                btnChartColuns.BackColor = Color.FromArgb(51, 51, 51);
                btnChartBar.BackColor = Color.FromArgb(51, 51, 51);
                btnLinePoint.BackColor = Color.FromArgb(51, 51, 51);
                btnArea.BackColor = Color.FromArgb(51, 51, 51);
               


            }


            else if (SelectChart == "LinePoint")
            {

                btnChartPie.BackColor = Color.FromArgb(51, 51, 51);

                btnChartLine.BackColor = Color.FromArgb(51, 51, 51);
                btnChartColuns.BackColor = Color.FromArgb(51, 51, 51);
                btnChartBar.BackColor = Color.FromArgb(51, 51, 51);
                btnLinePoint.BackColor = Color.FromArgb(88, 88, 88);
                btnArea.BackColor = Color.FromArgb(51, 51, 51);
               


            }

            else if (SelectChart == "Area")
            {

                btnChartPie.BackColor = Color.FromArgb(51, 51, 51);

                btnChartLine.BackColor = Color.FromArgb(51, 51, 51);
                btnChartColuns.BackColor = Color.FromArgb(51, 51, 51);
                btnChartBar.BackColor = Color.FromArgb(51, 51, 51);
                btnLinePoint.BackColor = Color.FromArgb(51, 51, 51);
                btnArea.BackColor = Color.FromArgb(88, 88, 88);
                


            }

            else if (SelectChart == "Bancario")
            {

                btnChartPie.BackColor = Color.FromArgb(51, 51, 51);

                btnChartLine.BackColor = Color.FromArgb(51, 51, 51);
                btnChartColuns.BackColor = Color.FromArgb(51, 51, 51);
                btnChartBar.BackColor = Color.FromArgb(51, 51, 51);
                btnLinePoint.BackColor = Color.FromArgb(51, 51, 51);
                btnArea.BackColor = Color.FromArgb(51, 51, 51);
               


            }

        }

        #endregion

        private void btnChartColuns_Click(object sender, EventArgs e)
        {
            // Opção de gráfico selecionado.
            SelectChart = "Columns";
            // Parte Visual do usuário(frontEnd).
            SystemOpSelect();
        }

        private void btnChartBar_Click(object sender, EventArgs e)
        {
            SelectChart = "Bar";

            SystemOpSelect();
        }

        private void btnChartPie_Click(object sender, EventArgs e)
        {
            SelectChart = "Pie";

            SystemOpSelect();
        }

        private void btnChartLine_Click(object sender, EventArgs e)
        {
            SelectChart = "Line";

            SystemOpSelect();
        }


        private void btnLinePoint_Click(object sender, EventArgs e)
        {
            SelectChart = "LinePoint";

            SystemOpSelect();
        }

        private void btnArea_Click(object sender, EventArgs e)
        {
            SelectChart = "Area";

            SystemOpSelect();
        }

       

        #endregion

        #region Parte MenusTop

        private void btnMenuChart_Click(object sender, EventArgs e)
        {
            AnimatMenuDesing.Start();
        }

        private void btnMenuTable_Click(object sender, EventArgs e)
        {
            animatMenuTable.Start();
        }

        #region Animações
        private void animatMenuTable_Tick(object sender, EventArgs e)
        {
            if (selectPnlTable == true)
            {
                btnMenuTable.Enabled = false;

                pnlMenuTable.Width -= 8;

                if (pnlMenuTable.Width == 2)
                {
                    pnlMenuTable.Width = 0;
                    btnMenuTable.Enabled = true;

                    btnMenuTable.IconColor = Color.Gainsboro;
                    selectPnlTable = false;

                    animatMenuTable.Stop();


                }


            }
            else
            {
                btnMenuTable.Enabled = false;

                pnlMenuTable.Width += 8;

                if (pnlMenuTable.Width == 192)
                {
                    pnlMenuTable.Width = 194;
                    btnMenuTable.Enabled = true;

                    btnMenuTable.IconColor = Color.FromArgb(46, 204, 113);
                    selectPnlTable = true;

                    animatMenuTable.Stop();


                }
            }
        }

        private void AnimatMenuDesing_Tick(object sender, EventArgs e)
        {
            if (selectPnlDesign == true)
            {
                btnMenuChart.Enabled = false;

                pnlMenuDesing.Width -= 8;

                if (pnlMenuDesing.Width == 2)
                {
                    pnlMenuDesing.Width = 0;
                    btnMenuChart.Enabled = true;

                    btnMenuChart.IconColor = Color.Gainsboro;
                    selectPnlDesign = false;

                    AnimatMenuDesing.Stop();


                }


            }
            else
            {
                btnMenuChart.Enabled = false;

                pnlMenuDesing.Width += 8;

                if (pnlMenuDesing.Width == 192)
                {
                    pnlMenuDesing.Width = 194;
                    btnMenuChart.Enabled = true;

                    btnMenuChart.IconColor = Color.FromArgb(46, 204, 113);
                    selectPnlDesign = true;

                    AnimatMenuDesing.Stop();


                }
            }
        }
        #endregion


        #endregion

        private void btnvoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
        private void btnAddPnlVazio_Click(object sender, EventArgs e)
        {
                
            FrmConfigDados dados = new FrmConfigDados("Connect");

            dados.ShowDialog();

        }

        private void btnCriarTable_Click(object sender, EventArgs e)
        {

            if(CreateForaP == false)
            {
                FrmConfigDados dados = new FrmConfigDados("Create");
                dados.CriarForaP = false;

                dados.ShowDialog();
            }
            else
            {
                FrmConfigDados dados = new FrmConfigDados("Create");
                dados.CriarForaP = true;

                dados.ShowDialog();
            }
        }

        #region Arrastar Form

        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion
        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #endregion

        #region Verificar os arquivos de dados dentro do projeto.

        
        int TopTables;
        public void VerificarTabela()
        {

            try
            {

                #region verificação de arquivos

                ControlFileProject fileProject = new ControlFileProject();

                if (Directory.Exists(DadosUsuario.DiretoryProject + @"\Dados"))
                {
                    string[] ArquivosTable = fileProject.VerificarArquivos(Business.DadosUsuario.DiretoryProject + @"\Dados\");

                    if (ArquivosTable != null)//Verificar o resoltado das quantidades de arquivo na pasta "Dados".
                    {

                        if (ArquivosTable.Length > 0)
                        {

                            if (pnlContainerTables.Controls.Count == 1)
                            {
                                TopTables = 0;
                                foreach (var nomeArquino in ArquivosTable)
                                {

                                    pnlVazioTables.Visible = false;

                                    //Editar diretório para só mostrar o nome do arquivo.
                                    string nome = nomeArquino.Replace(DadosUsuario.DiretoryProject + @"\Dados\", "");
                                    //

                                    UserNameTable lblname = new UserNameTable();

                                    lblname.lblName.Text = nome;

                                    lblname.Top = TopTables;

                                    TopTables += lblname.Height;

                                    pnlContainerTables.Controls.Add(lblname);

                                    lblname.Show();

                                    SystemExcel.systemOpenExcel opExcel = new SystemExcel.systemOpenExcel();

                                    DadosCreateTables.TablesSet = opExcel.AbrirExcel(nomeArquino);
                                    //Foreach
                                    foreach (DataTable tabela in Business.DadosCreateTables.TablesSet.Tables)
                                    {

                                        UserSelectTable UserTables = new UserSelectTable();

                                        UserTables.Table = tabela;

                                        UserTables.btnTable.Text = tabela.TableName;


                                        pnlContainerTables.Controls.Add(UserTables);

                                        UserTables.Top = TopTables;

                                        TopTables += UserTables.Height;

                                        UserTables.Show();

                                    }

                                    //

                                   
                                }


                            }
                            else
                            {

                                for (int i = 0; i < pnlContainerTables.Controls.Count; i++)
                                {
                                    if (i > 0)
                                    {
                                        pnlContainerTables.Controls.RemoveAt(i);
                                    }


                                }

                                #region verificação de arquivos 
                                foreach (var nomeArquino in ArquivosTable)
                                {

                                    pnlVazioTables.Visible = false;

                                    //Editar diretório para só mostrar o nome do arquivo.
                                    string nome = nomeArquino.Replace(DadosUsuario.DiretoryProject + @"\Dados\", "");
                                    //

                                    UserNameTable lblname = new UserNameTable();

                                    lblname.lblName.Text = nome;

                                    lblname.Top = TopTables;

                                    TopTables += lblname.Height;

                                    pnlContainerTables.Controls.Add(lblname);

                                    pnlContainerTables.Tag = lblname;

                                    lblname.Show();

                                    SystemExcel.systemOpenExcel opExcel = new SystemExcel.systemOpenExcel();

                                    DadosCreateTables.TablesSet = opExcel.AbrirExcel(nomeArquino);
                                    //Foreach
                                    foreach (DataTable tabela in DadosCreateTables.TablesSet.Tables)
                                    {

                                        UserSelectTable UserTables = new UserSelectTable();

                                        UserTables.Table = tabela;

                                        UserTables.btnTable.Text = tabela.TableName;

                                        UserTables.Top = TopTables;

                                        TopTables += UserTables.Height;

                                        UserTables.userTableGraf = true;

                                        pnlContainerTables.Controls.Add(UserTables);

                                        pnlContainerTables.Tag = UserTables;

                                        UserTables.Show();

                                    }

                                    //

                               
                                }

                                #endregion

                            }



                        }
                        else
                        {
                            
                            pnlVazioTables.Visible = true;
                            MessageBox.Show("Nenhum arquivo do tipo Excel foi encontrado.");
                        }

                    }
                    else
                    {
                        
                        pnlVazioTables.Visible = true;
                        MessageBox.Show("Nenhum arquivo encontrado.");
                    }


                }

                else
                {
                   
                    pnlVazioTables.Visible = true;
                    MessageBox.Show("Pasta Dados não encontrado. ");
                }

                #endregion

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :\n"+ex.Message);
            }

        }
        #endregion

        /*
        public void atualizarChart(DataTable table , int y , int x)
        {
            #region Adicionar os dados da Tabela na classe de Conjuto de dados
            //Adicionando colunas na tabela vazia.
            TableDadosGraf.tabela.Clear();
            TableDadosGraf.tabela.Columns.Clear();

            TableDadosGraf.tabela.Columns.Add("eixoY");
            TableDadosGraf.tabela.Columns.Add("eixoX");

            //
            for (int i = 0; i < table.Rows.Count; i++)
            {

                TableDadosGraf.tabela.Rows.Add(table.Rows[i][y].ToString(), table.Rows[i][x].ToString());
            }
            #endregion

           
            ControlFrmsStatOpen.ContainerGraf.abrirGrafico(); // Systema dentro do card , que está ativo no FrmEditor.

        }
        */
        #region Abrir tabelas no arquivo + animação(Splash Screen ).

        private void btnAtualizarPnlTables_Click(object sender, EventArgs e)
        {     
            VerificarTabela();
        }

      

        #endregion

       

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            ControlFrmsStatOpen.ContainerGraf.abrirGrafico();
        }

  
    }
}
