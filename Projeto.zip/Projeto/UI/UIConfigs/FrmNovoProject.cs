﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using System.IO;

namespace UI.UIConfigs
{


    public partial class FrmNovoProject : Form
    {

        string novoDiretory;
      
        public FrmNovoProject()
        {
            InitializeComponent();
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        private void btnCloser_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog diretory = new FolderBrowserDialog();

            diretory.Description = "Selecione o novo diretório";
            if (diretory.ShowDialog() == DialogResult.OK)
            {
                txbDiretory.Text = diretory.SelectedPath;
                novoDiretory = diretory.SelectedPath + @"\";
               
            }

          
        }

        private void btnCriar_Click(object sender, EventArgs e)
        {

            if(txbNomeProject.Text == txbNomeProject.MarcaText.ToString())
            {
                MessageBox.Show("Adicione o nome do projeto");
            }
            else
            {
                try
                {
                    if(txbDiretory.Text == DadosUsuario.Diretory)
                    {
                        FrmEditor editor = new FrmEditor();

                        editor.lblNomeProject.Text = txbNomeProject.Text;

                        DadosUsuario.DiretoryProject = DadosUsuario.Diretory + txbNomeProject.Text;

                        ControlFileProject pastaImpo = new ControlFileProject();

                        pastaImpo.CriarPastasImportantes();

                        ControlFileProject.criarPasta(DadosUsuario.Diretory + @"Drawer Project\Projetos\", txbNomeProject.Text);

                        DadosUsuario.DiretoryProject = DadosUsuario.Diretory + @"Drawer Project\Projetos\" + txbNomeProject.Text;

                        editor.ShowDialog();
                    }
                    else
                    {

                        FrmEditor editor = new FrmEditor();

                        editor.lblNomeProject.Text = txbNomeProject.Text;

                        DadosUsuario.DiretoryProject = novoDiretory + txbNomeProject.Text;

                        ControlFileProject.SalvarDiretorioSetting(novoDiretory);


                        ControlFileProject pastaImpo = new ControlFileProject();

                        pastaImpo.CriarPastasImportantes();

                        ControlFileProject.criarPasta(DadosUsuario.Diretory + @"Drawer Project\Projetos\", txbNomeProject.Text);

                        DadosUsuario.DiretoryProject = DadosUsuario.Diretory + @"Drawer Project\Projetos\" + txbNomeProject.Text;

                        editor.ShowDialog();

                    }
                    

                    this.Close();

                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


               
            }


           
        }

        private void FrmNovoProject_Load(object sender, EventArgs e)
        {
            txbDiretory.Text = DadosUsuario.Diretory;

            if(txbDiretory.Text == "")
            {
                UIConfigs.FrmConfigDiretorySystem EditDiretory = new FrmConfigDiretorySystem();

                EditDiretory.ShowDialog();
            }
        }
    }
}
