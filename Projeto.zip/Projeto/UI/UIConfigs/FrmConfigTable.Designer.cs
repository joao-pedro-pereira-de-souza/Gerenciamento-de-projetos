﻿namespace UI.UIConfigs
{
    partial class FrmConfigTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnColors = new FerramentasMod.ButtonIconMod();
            this.label5 = new System.Windows.Forms.Label();
            this.pnlAdicionarTable = new FerramentasMod.PanelMod();
            this.btnMenuTable = new FontAwesome.Sharp.IconButton();
            this.btnvoltar = new FerramentasMod.ButtonIconMod();
            this.pnlMenuTable = new System.Windows.Forms.Panel();
            this.pnlContainerTables = new System.Windows.Forms.Panel();
            this.pnlVazioTables = new System.Windows.Forms.Panel();
            this.btnAddPnlVazio = new FerramentasMod.ButtonIconMod();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnCriarTable = new FerramentasMod.ButtonElipse();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnAtualizarPnlTables = new FerramentasMod.ButtonIconMod();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlLinerTable = new System.Windows.Forms.Panel();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.pnlAvisoTableSelect = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvDados = new System.Windows.Forms.DataGridView();
            this.animatMenuTable = new System.Windows.Forms.Timer(this.components);
            this.pnlTop.SuspendLayout();
            this.pnlMenuTable.SuspendLayout();
            this.pnlContainerTables.SuspendLayout();
            this.pnlVazioTables.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.pnlAvisoTableSelect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.pnlTop.Controls.Add(this.btnColors);
            this.pnlTop.Controls.Add(this.label5);
            this.pnlTop.Controls.Add(this.pnlAdicionarTable);
            this.pnlTop.Controls.Add(this.btnMenuTable);
            this.pnlTop.Controls.Add(this.btnvoltar);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(968, 61);
            this.pnlTop.TabIndex = 1;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown_1);
            // 
            // btnColors
            // 
            this.btnColors.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColors.FlatAppearance.BorderSize = 0;
            this.btnColors.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnColors.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnColors.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColors.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnColors.IconChar = FontAwesome.Sharp.IconChar.Palette;
            this.btnColors.IconColor = System.Drawing.Color.Gainsboro;
            this.btnColors.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnColors.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnColors.IconSize = 20;
            this.btnColors.Location = new System.Drawing.Point(141, 21);
            this.btnColors.Name = "btnColors";
            this.btnColors.Rotation = 0D;
            this.btnColors.Size = new System.Drawing.Size(30, 24);
            this.btnColors.TabIndex = 7;
            this.btnColors.UseVisualStyleBackColor = true;
            this.btnColors.Click += new System.EventHandler(this.btnColors_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.label5.Location = new System.Drawing.Point(67, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "Tabela :";
            // 
            // pnlAdicionarTable
            // 
            this.pnlAdicionarTable.AnguloColor = 45F;
            this.pnlAdicionarTable.borderRadius = 10;
            this.pnlAdicionarTable.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.pnlAdicionarTable.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.pnlAdicionarTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlAdicionarTable.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlAdicionarTable.ForeColor = System.Drawing.Color.White;
            this.pnlAdicionarTable.Location = new System.Drawing.Point(829, 13);
            this.pnlAdicionarTable.Name = "pnlAdicionarTable";
            this.pnlAdicionarTable.Size = new System.Drawing.Size(113, 34);
            this.pnlAdicionarTable.TabIndex = 4;
            this.pnlAdicionarTable.Texto = "Criar";
            this.pnlAdicionarTable.Click += new System.EventHandler(this.pnlAdicionarTable_Click);
            // 
            // btnMenuTable
            // 
            this.btnMenuTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenuTable.FlatAppearance.BorderSize = 0;
            this.btnMenuTable.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnMenuTable.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnMenuTable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuTable.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnMenuTable.IconChar = FontAwesome.Sharp.IconChar.Table;
            this.btnMenuTable.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnMenuTable.IconSize = 25;
            this.btnMenuTable.Location = new System.Drawing.Point(778, 17);
            this.btnMenuTable.Name = "btnMenuTable";
            this.btnMenuTable.Rotation = 0D;
            this.btnMenuTable.Size = new System.Drawing.Size(30, 30);
            this.btnMenuTable.TabIndex = 3;
            this.btnMenuTable.UseVisualStyleBackColor = true;
            this.btnMenuTable.Click += new System.EventHandler(this.btnMenuTable_Click);
            // 
            // btnvoltar
            // 
            this.btnvoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnvoltar.FlatAppearance.BorderSize = 0;
            this.btnvoltar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnvoltar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnvoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvoltar.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnvoltar.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft;
            this.btnvoltar.IconColor = System.Drawing.Color.Gainsboro;
            this.btnvoltar.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnvoltar.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnvoltar.IconSize = 18;
            this.btnvoltar.Location = new System.Drawing.Point(12, 16);
            this.btnvoltar.Name = "btnvoltar";
            this.btnvoltar.Rotation = 0D;
            this.btnvoltar.Size = new System.Drawing.Size(27, 29);
            this.btnvoltar.TabIndex = 0;
            this.btnvoltar.UseVisualStyleBackColor = true;
            this.btnvoltar.Click += new System.EventHandler(this.btnvoltar_Click);
            // 
            // pnlMenuTable
            // 
            this.pnlMenuTable.Controls.Add(this.pnlContainerTables);
            this.pnlMenuTable.Controls.Add(this.btnCriarTable);
            this.pnlMenuTable.Controls.Add(this.panel5);
            this.pnlMenuTable.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenuTable.Location = new System.Drawing.Point(0, 61);
            this.pnlMenuTable.Name = "pnlMenuTable";
            this.pnlMenuTable.Size = new System.Drawing.Size(194, 487);
            this.pnlMenuTable.TabIndex = 3;
            // 
            // pnlContainerTables
            // 
            this.pnlContainerTables.AutoScroll = true;
            this.pnlContainerTables.Controls.Add(this.pnlVazioTables);
            this.pnlContainerTables.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlContainerTables.Location = new System.Drawing.Point(0, 40);
            this.pnlContainerTables.Name = "pnlContainerTables";
            this.pnlContainerTables.Size = new System.Drawing.Size(194, 379);
            this.pnlContainerTables.TabIndex = 5;
            // 
            // pnlVazioTables
            // 
            this.pnlVazioTables.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlVazioTables.Controls.Add(this.btnAddPnlVazio);
            this.pnlVazioTables.Controls.Add(this.label8);
            this.pnlVazioTables.Controls.Add(this.label7);
            this.pnlVazioTables.Controls.Add(this.pictureBox2);
            this.pnlVazioTables.Location = new System.Drawing.Point(11, 78);
            this.pnlVazioTables.Name = "pnlVazioTables";
            this.pnlVazioTables.Size = new System.Drawing.Size(173, 223);
            this.pnlVazioTables.TabIndex = 2;
            // 
            // btnAddPnlVazio
            // 
            this.btnAddPnlVazio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddPnlVazio.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnAddPnlVazio.FlatAppearance.BorderSize = 0;
            this.btnAddPnlVazio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddPnlVazio.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAddPnlVazio.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btnAddPnlVazio.IconColor = System.Drawing.Color.Gainsboro;
            this.btnAddPnlVazio.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAddPnlVazio.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnAddPnlVazio.IconSize = 16;
            this.btnAddPnlVazio.Location = new System.Drawing.Point(0, 193);
            this.btnAddPnlVazio.Name = "btnAddPnlVazio";
            this.btnAddPnlVazio.Rotation = 0D;
            this.btnAddPnlVazio.Size = new System.Drawing.Size(171, 28);
            this.btnAddPnlVazio.TabIndex = 2;
            this.btnAddPnlVazio.UseVisualStyleBackColor = true;
            this.btnAddPnlVazio.Click += new System.EventHandler(this.btnAddPnlVazio_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(170, 48);
            this.label8.TabIndex = 3;
            this.label8.Text = "Selecione uma Tabela na sua máquina ou crie uma.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(34, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Tabelas vazias";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::UI.Properties.Resources.iconePranheta;
            this.pictureBox2.Location = new System.Drawing.Point(19, 34);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(129, 110);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // btnCriarTable
            // 
            this.btnCriarTable.AnguloColor = 45F;
            this.btnCriarTable.borderRadius = 10;
            this.btnCriarTable.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnCriarTable.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnCriarTable.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnCriarTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCriarTable.EfeitoTexto = true;
            this.btnCriarTable.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarTable.ForeColor = System.Drawing.Color.White;
            this.btnCriarTable.Location = new System.Drawing.Point(15, 441);
            this.btnCriarTable.Name = "btnCriarTable";
            this.btnCriarTable.Size = new System.Drawing.Size(158, 34);
            this.btnCriarTable.TabIndex = 2;
            this.btnCriarTable.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarTable.Texto = "Criar Tabela";
            this.btnCriarTable.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarTable.Click += new System.EventHandler(this.btnCriarTable_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnAtualizarPnlTables);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(194, 40);
            this.panel5.TabIndex = 4;
            // 
            // btnAtualizarPnlTables
            // 
            this.btnAtualizarPnlTables.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAtualizarPnlTables.FlatAppearance.BorderSize = 0;
            this.btnAtualizarPnlTables.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnAtualizarPnlTables.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnAtualizarPnlTables.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizarPnlTables.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAtualizarPnlTables.IconChar = FontAwesome.Sharp.IconChar.Redo;
            this.btnAtualizarPnlTables.IconColor = System.Drawing.Color.DarkGray;
            this.btnAtualizarPnlTables.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAtualizarPnlTables.IconLeave = System.Drawing.Color.DarkGray;
            this.btnAtualizarPnlTables.IconSize = 18;
            this.btnAtualizarPnlTables.Location = new System.Drawing.Point(87, 13);
            this.btnAtualizarPnlTables.Name = "btnAtualizarPnlTables";
            this.btnAtualizarPnlTables.Rotation = 0D;
            this.btnAtualizarPnlTables.Size = new System.Drawing.Size(19, 20);
            this.btnAtualizarPnlTables.TabIndex = 5;
            this.btnAtualizarPnlTables.UseVisualStyleBackColor = true;
            this.btnAtualizarPnlTables.Click += new System.EventHandler(this.btnAtualizarPnlTables_Click);
            this.btnAtualizarPnlTables.MouseHover += new System.EventHandler(this.btnAtualizarPnlTables_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tabelas";
            // 
            // pnlLinerTable
            // 
            this.pnlLinerTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(110)))));
            this.pnlLinerTable.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLinerTable.Location = new System.Drawing.Point(194, 61);
            this.pnlLinerTable.Name = "pnlLinerTable";
            this.pnlLinerTable.Size = new System.Drawing.Size(1, 487);
            this.pnlLinerTable.TabIndex = 5;
            // 
            // pnlContainer
            // 
            this.pnlContainer.AutoScroll = true;
            this.pnlContainer.AutoSize = true;
            this.pnlContainer.Controls.Add(this.pnlAvisoTableSelect);
            this.pnlContainer.Controls.Add(this.dgvDados);
            this.pnlContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContainer.Location = new System.Drawing.Point(195, 61);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(773, 487);
            this.pnlContainer.TabIndex = 6;
            // 
            // pnlAvisoTableSelect
            // 
            this.pnlAvisoTableSelect.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAvisoTableSelect.Controls.Add(this.pictureBox1);
            this.pnlAvisoTableSelect.Controls.Add(this.label3);
            this.pnlAvisoTableSelect.Location = new System.Drawing.Point(159, 68);
            this.pnlAvisoTableSelect.Name = "pnlAvisoTableSelect";
            this.pnlAvisoTableSelect.Size = new System.Drawing.Size(454, 351);
            this.pnlAvisoTableSelect.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::UI.Properties.Resources.iconIlusTable;
            this.pictureBox1.Location = new System.Drawing.Point(24, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(408, 268);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(412, 64);
            this.label3.TabIndex = 1;
            this.label3.Text = "Selecione uma tabela para usar no Card . Qualquer dúvida acesse a tela de informa" +
    "ções/Tutorial";
            // 
            // dgvDados
            // 
            this.dgvDados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvDados.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvDados.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.dgvDados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDados.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvDados.ColumnHeadersHeight = 35;
            this.dgvDados.EnableHeadersVisualStyles = false;
            this.dgvDados.Location = new System.Drawing.Point(8, 5);
            this.dgvDados.Name = "dgvDados";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDados.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvDados.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            this.dgvDados.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvDados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDados.Size = new System.Drawing.Size(756, 477);
            this.dgvDados.TabIndex = 4;
//            this.dgvDados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDados_CellContentClick);
            // 
            // animatMenuTable
            // 
            this.animatMenuTable.Interval = 10;
            this.animatMenuTable.Tick += new System.EventHandler(this.animatMenuTable_Tick);
            // 
            // FrmConfigTable
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(968, 548);
            this.Controls.Add(this.pnlContainer);
            this.Controls.Add(this.pnlLinerTable);
            this.Controls.Add(this.pnlMenuTable);
            this.Controls.Add(this.pnlTop);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmConfigTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FrmConfigTable";
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlMenuTable.ResumeLayout(false);
            this.pnlContainerTables.ResumeLayout(false);
            this.pnlVazioTables.ResumeLayout(false);
            this.pnlVazioTables.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.pnlContainer.ResumeLayout(false);
            this.pnlAvisoTableSelect.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Label label5;
        private FerramentasMod.PanelMod pnlAdicionarTable;
        private FontAwesome.Sharp.IconButton btnMenuTable;
        private FerramentasMod.ButtonIconMod btnvoltar;
        private System.Windows.Forms.Panel pnlMenuTable;
        private FerramentasMod.ButtonElipse btnCriarTable;
        private System.Windows.Forms.Panel pnlVazioTables;
        private FerramentasMod.ButtonIconMod btnAddPnlVazio;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel5;
        private FerramentasMod.ButtonIconMod btnAtualizarPnlTables;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlLinerTable;
        public System.Windows.Forms.Panel pnlContainer;
        public System.Windows.Forms.Panel pnlAvisoTableSelect;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.DataGridView dgvDados;
        private FerramentasMod.ButtonIconMod btnColors;
        private System.Windows.Forms.Panel pnlContainerTables;
        private System.Windows.Forms.Timer animatMenuTable;
    }
}