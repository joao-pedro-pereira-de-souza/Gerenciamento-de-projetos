﻿using Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class FrmConfigTable : Form
    {

       

        public bool CreateForaP = false;

        bool selectPnlTable = true;

        public UserContainerV2 containerTable = new UserContainerV2();

        public FrmConfigTable()
        {
            InitializeComponent();
        }


        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion
        #region Sistema de Arrastar formulário


        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion

        private void pnlTop_MouseDown_1(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #endregion

        public void ShowTable(DataTable tabela)
        {
            pnlAvisoTableSelect.Visible = false;
            dgvDados.DataSource = tabela;



        }

        #region

        int TopTables;

        public void VerificarTabela()
        {
            ControlFileProject fileProject = new ControlFileProject();

            if (Directory.Exists(DadosUsuario.DiretoryProject + @"\Dados"))
            {
                string[] ArquivosTable = fileProject.VerificarArquivos(Business.DadosUsuario.DiretoryProject + @"\Dados\");

                if (ArquivosTable != null)//Verificar o resoltado das quantidades de arquivo na pasta "Dados".
                {

                    if (ArquivosTable.Length > 0)
                    {

                        if (pnlContainerTables.Controls.Count == 1)
                        {
                            TopTables = 0;
                            foreach (var nomeArquino in ArquivosTable)
                            {

                                pnlVazioTables.Visible = false;

                                //Editar diretório para só mostrar o nome do arquivo.
                                string nome = nomeArquino.Replace(DadosUsuario.DiretoryProject + @"\Dados\", "");
                                //

                                UserNameTable lblname = new UserNameTable();

                                lblname.lblName.Text = nome;

                                lblname.Top = TopTables;

                                TopTables += lblname.Height;

                                pnlContainerTables.Controls.Add(lblname);

                                lblname.Show();

                                SystemExcel.systemOpenExcel opExcel = new SystemExcel.systemOpenExcel();

                                DadosCreateTables.TablesSet = opExcel.AbrirExcel(nomeArquino);
                                //Foreach
                                foreach (DataTable tabela in Business.DadosCreateTables.TablesSet.Tables)
                                {

                                    UserSelectTable UserTables = new UserSelectTable();

                                    UserTables.Table = tabela;

                                    UserTables.btnTable.Text = tabela.TableName;

                                    UserTables.userTableGraf = false;

                                    UserTables.frmTable = this;

                                    pnlContainerTables.Controls.Add(UserTables);

                                    UserTables.Top = TopTables;

                                    TopTables += UserTables.Height;

                                    UserTables.Show();

                                }

                                //

                                
                            }


                        }
                        else
                        {
                            TopTables = 0;

                            for (int i = 0; i < pnlContainerTables.Controls.Count; i++)
                            {
                                if (i > 0)
                                {
                                    pnlContainerTables.Controls.RemoveAt(i);
                                }


                            }

                            foreach (var nomeArquino in ArquivosTable)
                            {

                                pnlVazioTables.Visible = false;

                                //Editar diretório para só mostrar o nome do arquivo.
                                string nome = nomeArquino.Replace(DadosUsuario.DiretoryProject + @"\Dados\", "");
                                //

                                UserNameTable lblname = new UserNameTable();

                                lblname.lblName.Text = nome;

                                lblname.Top = TopTables;

                                TopTables += lblname.Height;

                                pnlContainerTables.Controls.Add(lblname);

                                pnlContainerTables.Tag = lblname;

                                lblname.Show();

                                SystemExcel.systemOpenExcel opExcel = new SystemExcel.systemOpenExcel();

                                DadosCreateTables.TablesSet = opExcel.AbrirExcel(nomeArquino);
                                //Foreach
                                foreach (DataTable tabela in DadosCreateTables.TablesSet.Tables)
                                {

                                    UserSelectTable UserTables = new UserSelectTable();

                                    UserTables.Table = tabela;

                                    UserTables.userTableGraf = false;

                                    UserTables.frmTable = this;

                                    UserTables.btnTable.Text = tabela.TableName;

                                    UserTables.Top = TopTables;  

                                    TopTables += UserTables.Height;

                                    pnlContainerTables.Controls.Add(UserTables);

                                    pnlContainerTables.Tag = UserTables;

                                    UserTables.Show();

                                }

                                //

                               
                            }



                        }



                    }
                    else
                    {
                       
                        pnlVazioTables.Visible = true;
                        MessageBox.Show("Nenhum arquivo de banco foi encontrado.");
                    }

                }
                else
                {
                   
                    pnlVazioTables.Visible = true;
                    MessageBox.Show("Nenhum arquivo encontrado.");
                }


            }

            else
            {
               
                pnlVazioTables.Visible = true;
                MessageBox.Show("Pasta Dados não encontrado. ");
            }


        }

#endregion


        
        private void btnAtualizarPnlTables_Click(object sender, EventArgs e)
        {

            try
            {
                VerificarTabela();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           

        }

       

        private void pnlAdicionarTable_Click(object sender, EventArgs e)
        {

            try
            {
                #region Formatar tabela 

                // Formatar a Tabela para os valores ficarem do tipo string.
                //Aviso !!! ... Não consegui achar nenhum comando para converter todos os cells de maneira altomática.

                DataTable table = new DataTable();

                for (int h = 0; h < dgvDados.Columns.Count; h++) // Sistema para criar os cabeçalhos do datatable.
                {
                    ///MessageBox.Show(h.ToString());
                    table.Columns.Add(dgvDados.Columns[h].HeaderText);


                }

                // Fonte : https://www.codeproject.com/Questions/1155155/Exporting-datagridview-selectedrows-to-a-datatable.


                for (int i = 0; i < dgvDados.Rows.Count - 1; i++)
                {
                    table.Rows.Add();
                    for (int o = 0; o < dgvDados.Columns.Count; o++)
                    {
                        if (dgvDados.Rows[i].Cells[0] != null)
                        {

                            table.Rows[i][o] = dgvDados.Rows[i].Cells[o].Value.ToString();
                        }
                        else
                        {

                        }


                    }
                }

                #endregion


                containerTable.dgvDados.DataSource = dgvDados.DataSource;


                containerTable.TabelaShow = table;

                // Passar as Cores de um DataGrid para o outro.
                containerTable.dgvDados.ColumnHeadersDefaultCellStyle.BackColor = dgvDados.ColumnHeadersDefaultCellStyle.BackColor;

                containerTable.dgvDados.ColumnHeadersDefaultCellStyle.ForeColor = dgvDados.ColumnHeadersDefaultCellStyle.ForeColor;

                containerTable.dgvDados.RowsDefaultCellStyle.SelectionBackColor = dgvDados.RowsDefaultCellStyle.SelectionBackColor;

                containerTable.dgvDados.RowsDefaultCellStyle.SelectionForeColor = dgvDados.RowsDefaultCellStyle.SelectionForeColor;

                containerTable.dgvDados.RowsDefaultCellStyle.ForeColor = dgvDados.RowsDefaultCellStyle.ForeColor;

                //
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
    


            this.Close();
        }

        private void btnvoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Modar a Cor da Tabela

        private void btnColors_Click(object sender, EventArgs e)
        {

            try
            {
                FrmConfigColor frmConfigColor = new FrmConfigColor();

                FrmSubConfigColorTable subTela = new FrmSubConfigColorTable();

                subTela.frmTable = this;

                subTela.Pai = frmConfigColor;

                subTela.Dock = DockStyle.Top;

                subTela.TopLevel = false;

                frmConfigColor.pnlContainer.Controls.Add(subTela);

                subTela.Show();

                frmConfigColor.ShowDialog();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           

        }

        #endregion

        private void btnCriarTable_Click(object sender, EventArgs e)
        {
            if (CreateForaP == false)
            {
                FrmConfigDados dados = new FrmConfigDados("Create");
                dados.CriarForaP = false;

                dados.ShowDialog();
            }
            else
            {
                FrmConfigDados dados = new FrmConfigDados("Create");
                dados.CriarForaP = true;

                dados.ShowDialog();
            }
        }

        private void btnAddPnlVazio_Click(object sender, EventArgs e)
        {
            FrmConfigDados dados = new FrmConfigDados("Connect");

            dados.ShowDialog();
        }

        private void btnMenuTable_Click(object sender, EventArgs e)
        {
            animatMenuTable.Start();
        }


        #region Animação

        private void animatMenuTable_Tick(object sender, EventArgs e)
        {
            if (selectPnlTable == true)
            {
                btnMenuTable.Enabled = false;

                pnlMenuTable.Width -= 8;

                if (pnlMenuTable.Width == 2)
                {
                    pnlMenuTable.Width = 0;
                    btnMenuTable.Enabled = true;

                    btnMenuTable.IconColor = Color.Gainsboro;
                    selectPnlTable = false;

                    animatMenuTable.Stop();


                }


            }
            else
            {
                btnMenuTable.Enabled = false;

                pnlMenuTable.Width += 8;

                if (pnlMenuTable.Width == 192)
                {
                    pnlMenuTable.Width = 194;
                    btnMenuTable.Enabled = true;

                    btnMenuTable.IconColor = Color.FromArgb(46, 204, 113);
                    selectPnlTable = true;

                    animatMenuTable.Stop();


                }
            }
        }

        #endregion

        private void btnAtualizarPnlTables_MouseHover(object sender, EventArgs e)
        {
            ToolTip Informat = new ToolTip();

            Informat.IsBalloon = true;

            Informat.SetToolTip(this.btnAtualizarPnlTables, "Atualizar Tabelas");
        }
    }
}
