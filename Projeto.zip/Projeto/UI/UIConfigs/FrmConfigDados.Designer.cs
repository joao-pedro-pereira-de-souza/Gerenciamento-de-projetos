﻿namespace UI.UIConfigs
{
    partial class FrmConfigDados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnInfo = new FerramentasMod.ButtonIconMod();
            this.btnConfCreateTables = new System.Windows.Forms.Button();
            this.btnConfDadosTables = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnClose = new FerramentasMod.ButtonIconMod();
            this.pnlFill = new System.Windows.Forms.Panel();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.pnlInfo = new System.Windows.Forms.Panel();
            this.btnInfoOK = new FerramentasMod.ButtonElipse();
            this.lblInfo = new System.Windows.Forms.Label();
            this.ptbInfo = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlFill.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.pnlInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.panel1.Controls.Add(this.btnInfo);
            this.panel1.Controls.Add(this.btnConfCreateTables);
            this.panel1.Controls.Add(this.btnConfDadosTables);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(779, 54);
            this.panel1.TabIndex = 0;
            // 
            // btnInfo
            // 
            this.btnInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInfo.FlatAppearance.BorderSize = 0;
            this.btnInfo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.btnInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.btnInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInfo.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnInfo.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.btnInfo.IconColor = System.Drawing.Color.Gainsboro;
            this.btnInfo.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnInfo.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnInfo.IconSize = 18;
            this.btnInfo.Location = new System.Drawing.Point(870, 15);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Rotation = 0D;
            this.btnInfo.Size = new System.Drawing.Size(20, 22);
            this.btnInfo.TabIndex = 4;
            this.btnInfo.UseVisualStyleBackColor = true;
            // 
            // btnConfCreateTables
            // 
            this.btnConfCreateTables.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnConfCreateTables.FlatAppearance.BorderSize = 0;
            this.btnConfCreateTables.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfCreateTables.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfCreateTables.Location = new System.Drawing.Point(254, 0);
            this.btnConfCreateTables.Name = "btnConfCreateTables";
            this.btnConfCreateTables.Size = new System.Drawing.Size(181, 54);
            this.btnConfCreateTables.TabIndex = 2;
            this.btnConfCreateTables.Text = "Criar Tabelas";
            this.btnConfCreateTables.UseVisualStyleBackColor = true;
            this.btnConfCreateTables.Click += new System.EventHandler(this.btnConfCreateTables_Click);
            // 
            // btnConfDadosTables
            // 
            this.btnConfDadosTables.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnConfDadosTables.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnConfDadosTables.FlatAppearance.BorderSize = 0;
            this.btnConfDadosTables.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfDadosTables.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfDadosTables.Location = new System.Drawing.Point(65, 0);
            this.btnConfDadosTables.Name = "btnConfDadosTables";
            this.btnConfDadosTables.Size = new System.Drawing.Size(189, 54);
            this.btnConfDadosTables.TabIndex = 1;
            this.btnConfDadosTables.Text = "Conectar Tabelas";
            this.btnConfDadosTables.UseVisualStyleBackColor = false;
            this.btnConfDadosTables.Click += new System.EventHandler(this.btnConfDadosTables_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnClose);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(65, 54);
            this.panel2.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnClose.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft;
            this.btnClose.IconColor = System.Drawing.Color.Gainsboro;
            this.btnClose.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnClose.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnClose.IconSize = 18;
            this.btnClose.Location = new System.Drawing.Point(20, 14);
            this.btnClose.Name = "btnClose";
            this.btnClose.Rotation = 0D;
            this.btnClose.Size = new System.Drawing.Size(25, 26);
            this.btnClose.TabIndex = 3;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlFill
            // 
            this.pnlFill.Controls.Add(this.pnlContainer);
            this.pnlFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFill.Location = new System.Drawing.Point(0, 54);
            this.pnlFill.Name = "pnlFill";
            this.pnlFill.Size = new System.Drawing.Size(779, 430);
            this.pnlFill.TabIndex = 1;
            this.pnlFill.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlFill_Paint);
            // 
            // pnlContainer
            // 
            this.pnlContainer.AutoScroll = true;
            this.pnlContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.pnlContainer.Controls.Add(this.pnlInfo);
            this.pnlContainer.Location = new System.Drawing.Point(17, 16);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(744, 399);
            this.pnlContainer.TabIndex = 0;
            this.pnlContainer.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlContainer_Paint);
            // 
            // pnlInfo
            // 
            this.pnlInfo.Controls.Add(this.btnInfoOK);
            this.pnlInfo.Controls.Add(this.lblInfo);
            this.pnlInfo.Controls.Add(this.ptbInfo);
            this.pnlInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlInfo.Name = "pnlInfo";
            this.pnlInfo.Size = new System.Drawing.Size(744, 399);
            this.pnlInfo.TabIndex = 0;
            // 
            // btnInfoOK
            // 
            this.btnInfoOK.AnguloColor = 45F;
            this.btnInfoOK.borderRadius = 10;
            this.btnInfoOK.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnInfoOK.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnInfoOK.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnInfoOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInfoOK.EfeitoTexto = true;
            this.btnInfoOK.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfoOK.ForeColor = System.Drawing.Color.White;
            this.btnInfoOK.Location = new System.Drawing.Point(312, 325);
            this.btnInfoOK.Name = "btnInfoOK";
            this.btnInfoOK.Size = new System.Drawing.Size(119, 40);
            this.btnInfoOK.TabIndex = 2;
            this.btnInfoOK.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfoOK.Texto = "OK";
            this.btnInfoOK.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInfoOK.Click += new System.EventHandler(this.btnInfoOK_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.Location = new System.Drawing.Point(122, 258);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(500, 64);
            this.lblInfo.TabIndex = 1;
            this.lblInfo.Text = "Connection Table Excel\r\n";
            // 
            // ptbInfo
            // 
            this.ptbInfo.Image = global::UI.Properties.Resources.iconeConnect;
            this.ptbInfo.Location = new System.Drawing.Point(126, 34);
            this.ptbInfo.Name = "ptbInfo";
            this.ptbInfo.Size = new System.Drawing.Size(496, 216);
            this.ptbInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbInfo.TabIndex = 0;
            this.ptbInfo.TabStop = false;
            // 
            // FrmConfigDados
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.ClientSize = new System.Drawing.Size(779, 484);
            this.Controls.Add(this.pnlFill);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Gainsboro;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmConfigDados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FrmConfigDados";
            this.Load += new System.EventHandler(this.FrmConfigDados_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.pnlFill.ResumeLayout(false);
            this.pnlContainer.ResumeLayout(false);
            this.pnlInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptbInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnConfCreateTables;
        private FerramentasMod.ButtonIconMod btnClose;
        private FerramentasMod.ButtonIconMod btnInfo;
        private System.Windows.Forms.Panel pnlFill;
        private System.Windows.Forms.Panel pnlContainer;
        private System.Windows.Forms.Panel pnlInfo;
        private System.Windows.Forms.PictureBox ptbInfo;
        private System.Windows.Forms.Label lblInfo;
        private FerramentasMod.ButtonElipse btnInfoOK;
        public System.Windows.Forms.Button btnConfDadosTables;
    }
}