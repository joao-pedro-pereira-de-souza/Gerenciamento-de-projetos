﻿namespace UI.UIConfigs
{
    partial class FrmConfigGraf
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
    private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmConfigGraf));
            this.pnlTop = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.btnAdicionar = new FerramentasMod.PanelMod();
            this.btnMenuTable = new FontAwesome.Sharp.IconButton();
            this.btnMenuChart = new FontAwesome.Sharp.IconButton();
            this.btnvoltar = new FerramentasMod.ButtonIconMod();
            this.pnlMenuDesing = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnArea = new System.Windows.Forms.Button();
            this.btnLinePoint = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnChartLine = new System.Windows.Forms.Button();
            this.btnChartPie = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnChartBar = new System.Windows.Forms.Button();
            this.btnChartColuns = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlMenuTable = new System.Windows.Forms.Panel();
            this.btnCriarTable = new FerramentasMod.ButtonElipse();
            this.pnlContainerTables = new System.Windows.Forms.Panel();
            this.pnlVazioTables = new System.Windows.Forms.Panel();
            this.btnAddPnlVazio = new FerramentasMod.ButtonIconMod();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnAtualizarPnlTables = new FerramentasMod.ButtonIconMod();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlLinerCharts = new System.Windows.Forms.Panel();
            this.pnlLinerTable = new System.Windows.Forms.Panel();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.pnlAvisoTableSelect = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AnimatMenuDesing = new System.Windows.Forms.Timer(this.components);
            this.animatMenuTable = new System.Windows.Forms.Timer(this.components);
            this.pnlTop.SuspendLayout();
            this.pnlMenuDesing.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlMenuTable.SuspendLayout();
            this.pnlContainerTables.SuspendLayout();
            this.pnlVazioTables.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.pnlAvisoTableSelect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.pnlTop.Controls.Add(this.label5);
            this.pnlTop.Controls.Add(this.btnAdicionar);
            this.pnlTop.Controls.Add(this.btnMenuTable);
            this.pnlTop.Controls.Add(this.btnMenuChart);
            this.pnlTop.Controls.Add(this.btnvoltar);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(968, 61);
            this.pnlTop.TabIndex = 0;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.label5.Location = new System.Drawing.Point(67, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "Gráfico :";
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.AnguloColor = 45F;
            this.btnAdicionar.borderRadius = 10;
            this.btnAdicionar.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnAdicionar.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionar.Enabled = false;
            this.btnAdicionar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.White;
            this.btnAdicionar.Location = new System.Drawing.Point(829, 13);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(113, 34);
            this.btnAdicionar.TabIndex = 4;
            this.btnAdicionar.Texto = "Criar";
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // btnMenuTable
            // 
            this.btnMenuTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenuTable.FlatAppearance.BorderSize = 0;
            this.btnMenuTable.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnMenuTable.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnMenuTable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuTable.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnMenuTable.IconChar = FontAwesome.Sharp.IconChar.Table;
            this.btnMenuTable.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnMenuTable.IconSize = 25;
            this.btnMenuTable.Location = new System.Drawing.Point(744, 17);
            this.btnMenuTable.Name = "btnMenuTable";
            this.btnMenuTable.Rotation = 0D;
            this.btnMenuTable.Size = new System.Drawing.Size(30, 30);
            this.btnMenuTable.TabIndex = 3;
            this.btnMenuTable.UseVisualStyleBackColor = true;
            this.btnMenuTable.Click += new System.EventHandler(this.btnMenuTable_Click);
            // 
            // btnMenuChart
            // 
            this.btnMenuChart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenuChart.FlatAppearance.BorderSize = 0;
            this.btnMenuChart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnMenuChart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnMenuChart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuChart.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnMenuChart.IconChar = FontAwesome.Sharp.IconChar.ChartPie;
            this.btnMenuChart.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnMenuChart.IconSize = 25;
            this.btnMenuChart.Location = new System.Drawing.Point(780, 17);
            this.btnMenuChart.Name = "btnMenuChart";
            this.btnMenuChart.Rotation = 0D;
            this.btnMenuChart.Size = new System.Drawing.Size(30, 30);
            this.btnMenuChart.TabIndex = 2;
            this.btnMenuChart.UseVisualStyleBackColor = true;
            this.btnMenuChart.Click += new System.EventHandler(this.btnMenuChart_Click);
            // 
            // btnvoltar
            // 
            this.btnvoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnvoltar.FlatAppearance.BorderSize = 0;
            this.btnvoltar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnvoltar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnvoltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnvoltar.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnvoltar.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft;
            this.btnvoltar.IconColor = System.Drawing.Color.Gainsboro;
            this.btnvoltar.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnvoltar.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnvoltar.IconSize = 18;
            this.btnvoltar.Location = new System.Drawing.Point(12, 16);
            this.btnvoltar.Name = "btnvoltar";
            this.btnvoltar.Rotation = 0D;
            this.btnvoltar.Size = new System.Drawing.Size(27, 29);
            this.btnvoltar.TabIndex = 0;
            this.btnvoltar.UseVisualStyleBackColor = true;
            this.btnvoltar.Click += new System.EventHandler(this.btnvoltar_Click);
            // 
            // pnlMenuDesing
            // 
            this.pnlMenuDesing.Controls.Add(this.panel2);
            this.pnlMenuDesing.Controls.Add(this.panel7);
            this.pnlMenuDesing.Controls.Add(this.panel6);
            this.pnlMenuDesing.Controls.Add(this.panel3);
            this.pnlMenuDesing.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlMenuDesing.Location = new System.Drawing.Point(774, 61);
            this.pnlMenuDesing.Name = "pnlMenuDesing";
            this.pnlMenuDesing.Size = new System.Drawing.Size(194, 487);
            this.pnlMenuDesing.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnArea);
            this.panel2.Controls.Add(this.btnLinePoint);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 216);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 88);
            this.panel2.TabIndex = 3;
            // 
            // btnArea
            // 
            this.btnArea.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnArea.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnArea.FlatAppearance.BorderSize = 0;
            this.btnArea.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnArea.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArea.Image = global::UI.Properties.Resources.iconLineBackChart;
            this.btnArea.Location = new System.Drawing.Point(96, 0);
            this.btnArea.Name = "btnArea";
            this.btnArea.Size = new System.Drawing.Size(96, 88);
            this.btnArea.TabIndex = 5;
            this.btnArea.Text = "Area";
            this.btnArea.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnArea.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnArea.UseVisualStyleBackColor = true;
            this.btnArea.Click += new System.EventHandler(this.btnArea_Click);
            // 
            // btnLinePoint
            // 
            this.btnLinePoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnLinePoint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLinePoint.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnLinePoint.FlatAppearance.BorderSize = 0;
            this.btnLinePoint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLinePoint.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLinePoint.Image = global::UI.Properties.Resources.iconLinePonitChart;
            this.btnLinePoint.Location = new System.Drawing.Point(0, 0);
            this.btnLinePoint.Name = "btnLinePoint";
            this.btnLinePoint.Size = new System.Drawing.Size(96, 88);
            this.btnLinePoint.TabIndex = 4;
            this.btnLinePoint.Text = "Line Point";
            this.btnLinePoint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLinePoint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnLinePoint.UseVisualStyleBackColor = false;
            this.btnLinePoint.Click += new System.EventHandler(this.btnLinePoint_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnChartLine);
            this.panel7.Controls.Add(this.btnChartPie);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 128);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(194, 88);
            this.panel7.TabIndex = 2;
            // 
            // btnChartLine
            // 
            this.btnChartLine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChartLine.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnChartLine.FlatAppearance.BorderSize = 0;
            this.btnChartLine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChartLine.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChartLine.Image = ((System.Drawing.Image)(resources.GetObject("btnChartLine.Image")));
            this.btnChartLine.Location = new System.Drawing.Point(96, 0);
            this.btnChartLine.Name = "btnChartLine";
            this.btnChartLine.Size = new System.Drawing.Size(96, 88);
            this.btnChartLine.TabIndex = 5;
            this.btnChartLine.Text = "Line";
            this.btnChartLine.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnChartLine.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnChartLine.UseVisualStyleBackColor = true;
            this.btnChartLine.Click += new System.EventHandler(this.btnChartLine_Click);
            // 
            // btnChartPie
            // 
            this.btnChartPie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnChartPie.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChartPie.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnChartPie.FlatAppearance.BorderSize = 0;
            this.btnChartPie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChartPie.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChartPie.Image = global::UI.Properties.Resources.iconPieChart;
            this.btnChartPie.Location = new System.Drawing.Point(0, 0);
            this.btnChartPie.Name = "btnChartPie";
            this.btnChartPie.Size = new System.Drawing.Size(96, 88);
            this.btnChartPie.TabIndex = 4;
            this.btnChartPie.Text = "Pie";
            this.btnChartPie.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnChartPie.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnChartPie.UseVisualStyleBackColor = false;
            this.btnChartPie.Click += new System.EventHandler(this.btnChartPie_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnChartBar);
            this.panel6.Controls.Add(this.btnChartColuns);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 40);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(194, 88);
            this.panel6.TabIndex = 1;
            // 
            // btnChartBar
            // 
            this.btnChartBar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChartBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnChartBar.FlatAppearance.BorderSize = 0;
            this.btnChartBar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChartBar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChartBar.Image = ((System.Drawing.Image)(resources.GetObject("btnChartBar.Image")));
            this.btnChartBar.Location = new System.Drawing.Point(96, 0);
            this.btnChartBar.Name = "btnChartBar";
            this.btnChartBar.Size = new System.Drawing.Size(96, 88);
            this.btnChartBar.TabIndex = 5;
            this.btnChartBar.Text = "Bar";
            this.btnChartBar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnChartBar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnChartBar.UseVisualStyleBackColor = true;
            this.btnChartBar.Click += new System.EventHandler(this.btnChartBar_Click);
            // 
            // btnChartColuns
            // 
            this.btnChartColuns.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.btnChartColuns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChartColuns.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnChartColuns.FlatAppearance.BorderSize = 0;
            this.btnChartColuns.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChartColuns.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChartColuns.Image = global::UI.Properties.Resources.iconBarChart;
            this.btnChartColuns.Location = new System.Drawing.Point(0, 0);
            this.btnChartColuns.Name = "btnChartColuns";
            this.btnChartColuns.Size = new System.Drawing.Size(96, 88);
            this.btnChartColuns.TabIndex = 4;
            this.btnChartColuns.Text = "Columns";
            this.btnChartColuns.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnChartColuns.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnChartColuns.UseVisualStyleBackColor = false;
            this.btnChartColuns.Click += new System.EventHandler(this.btnChartColuns_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(194, 40);
            this.panel3.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.label2.Location = new System.Drawing.Point(3, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 21);
            this.label2.TabIndex = 5;
            this.label2.Text = "Gráficos";
            // 
            // pnlMenuTable
            // 
            this.pnlMenuTable.Controls.Add(this.btnCriarTable);
            this.pnlMenuTable.Controls.Add(this.pnlContainerTables);
            this.pnlMenuTable.Controls.Add(this.panel5);
            this.pnlMenuTable.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenuTable.Location = new System.Drawing.Point(0, 61);
            this.pnlMenuTable.Name = "pnlMenuTable";
            this.pnlMenuTable.Size = new System.Drawing.Size(194, 487);
            this.pnlMenuTable.TabIndex = 2;
            // 
            // btnCriarTable
            // 
            this.btnCriarTable.AnguloColor = 45F;
            this.btnCriarTable.borderRadius = 10;
            this.btnCriarTable.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnCriarTable.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnCriarTable.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnCriarTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCriarTable.EfeitoTexto = true;
            this.btnCriarTable.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarTable.ForeColor = System.Drawing.Color.White;
            this.btnCriarTable.Location = new System.Drawing.Point(15, 441);
            this.btnCriarTable.Name = "btnCriarTable";
            this.btnCriarTable.Size = new System.Drawing.Size(158, 34);
            this.btnCriarTable.TabIndex = 2;
            this.btnCriarTable.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarTable.Texto = "Criar Tabela";
            this.btnCriarTable.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriarTable.Click += new System.EventHandler(this.btnCriarTable_Click);
            // 
            // pnlContainerTables
            // 
            this.pnlContainerTables.AutoScroll = true;
            this.pnlContainerTables.Controls.Add(this.pnlVazioTables);
            this.pnlContainerTables.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlContainerTables.Location = new System.Drawing.Point(0, 40);
            this.pnlContainerTables.Name = "pnlContainerTables";
            this.pnlContainerTables.Size = new System.Drawing.Size(194, 396);
            this.pnlContainerTables.TabIndex = 2;
            // 
            // pnlVazioTables
            // 
            this.pnlVazioTables.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlVazioTables.Controls.Add(this.btnAddPnlVazio);
            this.pnlVazioTables.Controls.Add(this.label8);
            this.pnlVazioTables.Controls.Add(this.label7);
            this.pnlVazioTables.Controls.Add(this.pictureBox2);
            this.pnlVazioTables.Location = new System.Drawing.Point(11, 69);
            this.pnlVazioTables.Name = "pnlVazioTables";
            this.pnlVazioTables.Size = new System.Drawing.Size(173, 223);
            this.pnlVazioTables.TabIndex = 2;
            // 
            // btnAddPnlVazio
            // 
            this.btnAddPnlVazio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddPnlVazio.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnAddPnlVazio.FlatAppearance.BorderSize = 0;
            this.btnAddPnlVazio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddPnlVazio.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAddPnlVazio.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btnAddPnlVazio.IconColor = System.Drawing.Color.Gainsboro;
            this.btnAddPnlVazio.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAddPnlVazio.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnAddPnlVazio.IconSize = 16;
            this.btnAddPnlVazio.Location = new System.Drawing.Point(0, 193);
            this.btnAddPnlVazio.Name = "btnAddPnlVazio";
            this.btnAddPnlVazio.Rotation = 0D;
            this.btnAddPnlVazio.Size = new System.Drawing.Size(171, 28);
            this.btnAddPnlVazio.TabIndex = 2;
            this.btnAddPnlVazio.UseVisualStyleBackColor = true;
            this.btnAddPnlVazio.Click += new System.EventHandler(this.btnAddPnlVazio_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(170, 48);
            this.label8.TabIndex = 3;
            this.label8.Text = "Selecione uma Tabela na sua máquina ou crie uma.";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(34, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Tabelas vazias";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::UI.Properties.Resources.iconePranheta;
            this.pictureBox2.Location = new System.Drawing.Point(19, 34);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(129, 110);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnAtualizarPnlTables);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(194, 40);
            this.panel5.TabIndex = 4;
            // 
            // btnAtualizarPnlTables
            // 
            this.btnAtualizarPnlTables.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAtualizarPnlTables.FlatAppearance.BorderSize = 0;
            this.btnAtualizarPnlTables.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnAtualizarPnlTables.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.btnAtualizarPnlTables.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAtualizarPnlTables.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAtualizarPnlTables.IconChar = FontAwesome.Sharp.IconChar.Redo;
            this.btnAtualizarPnlTables.IconColor = System.Drawing.Color.DarkGray;
            this.btnAtualizarPnlTables.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAtualizarPnlTables.IconLeave = System.Drawing.Color.DarkGray;
            this.btnAtualizarPnlTables.IconSize = 18;
            this.btnAtualizarPnlTables.Location = new System.Drawing.Point(87, 10);
            this.btnAtualizarPnlTables.Name = "btnAtualizarPnlTables";
            this.btnAtualizarPnlTables.Rotation = 0D;
            this.btnAtualizarPnlTables.Size = new System.Drawing.Size(19, 21);
            this.btnAtualizarPnlTables.TabIndex = 5;
            this.btnAtualizarPnlTables.UseVisualStyleBackColor = true;
            this.btnAtualizarPnlTables.Click += new System.EventHandler(this.btnAtualizarPnlTables_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tabelas";
            // 
            // pnlLinerCharts
            // 
            this.pnlLinerCharts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(110)))));
            this.pnlLinerCharts.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlLinerCharts.Location = new System.Drawing.Point(773, 61);
            this.pnlLinerCharts.Name = "pnlLinerCharts";
            this.pnlLinerCharts.Size = new System.Drawing.Size(1, 487);
            this.pnlLinerCharts.TabIndex = 3;
            // 
            // pnlLinerTable
            // 
            this.pnlLinerTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(110)))));
            this.pnlLinerTable.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLinerTable.Location = new System.Drawing.Point(194, 61);
            this.pnlLinerTable.Name = "pnlLinerTable";
            this.pnlLinerTable.Size = new System.Drawing.Size(1, 487);
            this.pnlLinerTable.TabIndex = 4;
            // 
            // pnlContainer
            // 
            this.pnlContainer.AutoScroll = true;
            this.pnlContainer.AutoSize = true;
            this.pnlContainer.Controls.Add(this.pnlAvisoTableSelect);
            this.pnlContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContainer.Location = new System.Drawing.Point(195, 61);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(578, 487);
            this.pnlContainer.TabIndex = 5;
            // 
            // pnlAvisoTableSelect
            // 
            this.pnlAvisoTableSelect.Controls.Add(this.pictureBox1);
            this.pnlAvisoTableSelect.Controls.Add(this.label3);
            this.pnlAvisoTableSelect.Location = new System.Drawing.Point(66, 40);
            this.pnlAvisoTableSelect.Name = "pnlAvisoTableSelect";
            this.pnlAvisoTableSelect.Size = new System.Drawing.Size(454, 352);
            this.pnlAvisoTableSelect.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = global::UI.Properties.Resources.iconIluChartPie;
            this.pictureBox1.Location = new System.Drawing.Point(24, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(410, 268);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(414, 64);
            this.label3.TabIndex = 1;
            this.label3.Text = "Selecione uma tabela para usar no gráfico. Qualquer dúvida acesse a tela de infor" +
    "mações/Tutorial";
            // 
            // AnimatMenuDesing
            // 
            this.AnimatMenuDesing.Interval = 10;
            this.AnimatMenuDesing.Tick += new System.EventHandler(this.AnimatMenuDesing_Tick);
            // 
            // animatMenuTable
            // 
            this.animatMenuTable.Interval = 10;
            this.animatMenuTable.Tick += new System.EventHandler(this.animatMenuTable_Tick);
            // 
            // FrmConfigGraf
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(968, 548);
            this.Controls.Add(this.pnlContainer);
            this.Controls.Add(this.pnlLinerTable);
            this.Controls.Add(this.pnlLinerCharts);
            this.Controls.Add(this.pnlMenuTable);
            this.Controls.Add(this.pnlMenuDesing);
            this.Controls.Add(this.pnlTop);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Gainsboro;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmConfigGraf";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.pnlMenuDesing.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnlMenuTable.ResumeLayout(false);
            this.pnlContainerTables.ResumeLayout(false);
            this.pnlVazioTables.ResumeLayout(false);
            this.pnlVazioTables.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.pnlContainer.ResumeLayout(false);
            this.pnlAvisoTableSelect.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTop;
        private FerramentasMod.ButtonIconMod btnvoltar;
        private FontAwesome.Sharp.IconButton btnMenuChart;
        private FontAwesome.Sharp.IconButton btnMenuTable;
        private System.Windows.Forms.Panel pnlMenuDesing;
        private System.Windows.Forms.Button btnChartBar;
        private System.Windows.Forms.Button btnChartColuns;
        private System.Windows.Forms.Panel pnlMenuTable;
        private System.Windows.Forms.Panel pnlLinerCharts;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnChartLine;
        private System.Windows.Forms.Button btnChartPie;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlLinerTable;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer AnimatMenuDesing;
        private System.Windows.Forms.Timer animatMenuTable;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnArea;
        private System.Windows.Forms.Button btnLinePoint;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnlContainerTables;
        private System.Windows.Forms.Panel pnlVazioTables;
        private System.Windows.Forms.PictureBox pictureBox2;
        private FerramentasMod.ButtonIconMod btnAddPnlVazio;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private FerramentasMod.ButtonElipse btnCriarTable;
        private FerramentasMod.ButtonIconMod btnAtualizarPnlTables;
        public System.Windows.Forms.Panel pnlContainer;
        public System.Windows.Forms.Panel pnlAvisoTableSelect;
        public FerramentasMod.PanelMod btnAdicionar;
    }
}

