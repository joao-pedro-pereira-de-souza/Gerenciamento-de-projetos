﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class UserTabela : UserControl
    {

        public int numericTable;

        public DataTable tabela = new DataTable();

        public FrmCreateDadosExcelPG3 ControleTable = new FrmCreateDadosExcelPG3();


        public UserTabela()
        {
            InitializeComponent();

          
        }

        public DataTable RetornarTable()
        {
            return tabela;
        }


        private void btnTable_Click(object sender, EventArgs e)
        {

           
             
        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            ControleTable.DeletarTabela(numericTable);
            pnlLinerBottom.BackColor = Color.FromArgb(231, 76, 60);
        }

        private void UserTabela_Load(object sender, EventArgs e)
        {

           #region Editar Tamanho da letra do texto;
        
            string nomeTable;

            nomeTable = tabela.TableName;

            int quantLetra = nomeTable.Length;

            if (quantLetra >= 7)
            {
                string abreviar;

                abreviar = nomeTable.Substring(0, 5);

                abreviar += "...";

                btnTable.Text = abreviar;

            }
            else
            {
                btnTable.Text = nomeTable;
            }

            #endregion

          
        }

        private void btnTable_MouseHover(object sender, EventArgs e)
        {
            ToolTip Informat = new ToolTip();

            Informat.IsBalloon = true;

            Informat.SetToolTip(this.btnTable, tabela.TableName);

        }
    }
}
