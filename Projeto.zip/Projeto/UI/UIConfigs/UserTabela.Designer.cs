﻿namespace UI.UIConfigs
{
    partial class UserTabela
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlLinerBottom = new System.Windows.Forms.Panel();
            this.btnTable = new FerramentasMod.ButtonIconMod();
            this.btnDeletar = new FerramentasMod.ButtonIconMod();
            this.TipInformat = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // pnlLinerBottom
            // 
            this.pnlLinerBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.pnlLinerBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlLinerBottom.Location = new System.Drawing.Point(0, 37);
            this.pnlLinerBottom.Name = "pnlLinerBottom";
            this.pnlLinerBottom.Size = new System.Drawing.Size(193, 2);
            this.pnlLinerBottom.TabIndex = 0;
            // 
            // btnTable
            // 
            this.btnTable.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTable.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnTable.FlatAppearance.BorderSize = 0;
            this.btnTable.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTable.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnTable.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTable.IconChar = FontAwesome.Sharp.IconChar.Table;
            this.btnTable.IconColor = System.Drawing.Color.Gainsboro;
            this.btnTable.IconHover = System.Drawing.Color.Gainsboro;
            this.btnTable.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnTable.IconSize = 22;
            this.btnTable.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTable.Location = new System.Drawing.Point(0, 0);
            this.btnTable.Name = "btnTable";
            this.btnTable.Rotation = 0D;
            this.btnTable.Size = new System.Drawing.Size(159, 37);
            this.btnTable.TabIndex = 1;
            this.btnTable.Text = "Tabela";
            this.btnTable.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTable.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTable.UseVisualStyleBackColor = true;
            this.btnTable.Click += new System.EventHandler(this.btnTable_Click);
            this.btnTable.MouseHover += new System.EventHandler(this.btnTable_MouseHover);
            // 
            // btnDeletar
            // 
            this.btnDeletar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeletar.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnDeletar.FlatAppearance.BorderSize = 0;
            this.btnDeletar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeletar.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnDeletar.IconChar = FontAwesome.Sharp.IconChar.TrashAlt;
            this.btnDeletar.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnDeletar.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDeletar.IconLeave = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnDeletar.IconSize = 22;
            this.btnDeletar.Location = new System.Drawing.Point(159, 0);
            this.btnDeletar.Name = "btnDeletar";
            this.btnDeletar.Rotation = 0D;
            this.btnDeletar.Size = new System.Drawing.Size(35, 37);
            this.btnDeletar.TabIndex = 3;
            this.btnDeletar.UseVisualStyleBackColor = true;
            this.btnDeletar.Click += new System.EventHandler(this.btnDeletar_Click);
            // 
            // TipInformat
            // 
            this.TipInformat.IsBalloon = true;
            // 
            // UserTabela
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.Controls.Add(this.btnDeletar);
            this.Controls.Add(this.btnTable);
            this.Controls.Add(this.pnlLinerBottom);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Gainsboro;
            this.Name = "UserTabela";
            this.Size = new System.Drawing.Size(193, 39);
            this.Load += new System.EventHandler(this.UserTabela_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlLinerBottom;
        private FerramentasMod.ButtonIconMod btnDeletar;
        private System.Windows.Forms.ToolTip TipInformat;
        private FerramentasMod.ButtonIconMod btnTable;
    }
}
