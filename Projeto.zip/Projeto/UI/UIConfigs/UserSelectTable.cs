﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class UserSelectTable : UserControl
    {

        public bool userTableGraf = true;

        public DataTable Table = new DataTable();

        public FrmConfigTable frmTable = new FrmConfigTable();

        public UserSelectTable()
        {
            InitializeComponent();
        }

        private void btnTable_Click(object sender, EventArgs e)
        {
            if(userTableGraf == true)
            {
                try
                {
                    FrmSubConfigGraf SubGraf = new FrmSubConfigGraf();
                    ControlFrmsStatOpen.controlGraf.pnlAvisoTableSelect.Visible = false;
                    SubGraf.TopLevel = false;

                    SubGraf.EditTabela = Table;

                    ControlFrmsStatOpen.controlGraf.pnlContainer.Controls.Add(SubGraf);
                    SubGraf.Dock = DockStyle.Top;


                    SubGraf.Show();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Erro :\n" + ex.Message);
                }
              
            }
            else
            {


                frmTable.ShowTable(Table);
            }
           
        }
    }
}
