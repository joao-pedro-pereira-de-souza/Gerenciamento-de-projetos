﻿namespace UI.UIConfigs
{
    partial class FrmNovoProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txbDiretory = new FerramentasMod.TextBoxMod();
            this.panelMod1 = new FerramentasMod.PanelMod();
            this.ptbTema = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txbNomeProject = new FerramentasMod.TextBoxMod();
            this.panelMod2 = new FerramentasMod.PanelMod();
            this.btnEditar = new FerramentasMod.PanelMod();
            this.btnCriar = new FerramentasMod.PanelMod();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbTema)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txbDiretory);
            this.panel1.Controls.Add(this.panelMod1);
            this.panel1.Location = new System.Drawing.Point(369, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(316, 38);
            this.panel1.TabIndex = 4;
            // 
            // txbDiretory
            // 
            this.txbDiretory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txbDiretory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbDiretory.ColorDig = System.Drawing.Color.Gainsboro;
            this.txbDiretory.ColorMarca = System.Drawing.Color.Gray;
            this.txbDiretory.Enabled = false;
            this.txbDiretory.ForeColor = System.Drawing.Color.Gray;
            this.txbDiretory.Location = new System.Drawing.Point(14, 8);
            this.txbDiretory.MarcaText = "c:\\Drawer Project\\Projetos";
            this.txbDiretory.Name = "txbDiretory";
            this.txbDiretory.Size = new System.Drawing.Size(299, 22);
            this.txbDiretory.TabIndex = 2;
            this.txbDiretory.Text = "c:\\Drawer Project\\Projetos\\";
            // 
            // panelMod1
            // 
            this.panelMod1.AnguloColor = 45F;
            this.panelMod1.borderRadius = 10;
            this.panelMod1.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod1.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod1.ForeColor = System.Drawing.Color.White;
            this.panelMod1.Location = new System.Drawing.Point(0, 0);
            this.panelMod1.Name = "panelMod1";
            this.panelMod1.Size = new System.Drawing.Size(316, 38);
            this.panelMod1.TabIndex = 2;
            this.panelMod1.Texto = "";
            // 
            // ptbTema
            // 
            this.ptbTema.Image = global::UI.Properties.Resources.iconeGrafs;
            this.ptbTema.Location = new System.Drawing.Point(40, 75);
            this.ptbTema.Name = "ptbTema";
            this.ptbTema.Size = new System.Drawing.Size(257, 179);
            this.ptbTema.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbTema.TabIndex = 5;
            this.ptbTema.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.ptbTema);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(343, 316);
            this.panel2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 21);
            this.label1.TabIndex = 7;
            this.label1.Text = "Novo Projeto";
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(680, 4);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 10;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txbNomeProject);
            this.panel4.Controls.Add(this.panelMod2);
            this.panel4.Location = new System.Drawing.Point(369, 178);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(316, 38);
            this.panel4.TabIndex = 11;
            // 
            // txbNomeProject
            // 
            this.txbNomeProject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txbNomeProject.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbNomeProject.ColorDig = System.Drawing.Color.Gainsboro;
            this.txbNomeProject.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txbNomeProject.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txbNomeProject.Location = new System.Drawing.Point(14, 8);
            this.txbNomeProject.MarcaText = "Nome Projeto";
            this.txbNomeProject.Name = "txbNomeProject";
            this.txbNomeProject.Size = new System.Drawing.Size(299, 22);
            this.txbNomeProject.TabIndex = 2;
            this.txbNomeProject.Text = "Nome Projeto";
            // 
            // panelMod2
            // 
            this.panelMod2.AnguloColor = 45F;
            this.panelMod2.borderRadius = 10;
            this.panelMod2.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod2.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod2.ForeColor = System.Drawing.Color.White;
            this.panelMod2.Location = new System.Drawing.Point(0, 0);
            this.panelMod2.Name = "panelMod2";
            this.panelMod2.Size = new System.Drawing.Size(316, 38);
            this.panelMod2.TabIndex = 2;
            this.panelMod2.Texto = "";
            // 
            // btnEditar
            // 
            this.btnEditar.AnguloColor = 20F;
            this.btnEditar.borderRadius = 10;
            this.btnEditar.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnEditar.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnEditar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditar.ForeColor = System.Drawing.Color.White;
            this.btnEditar.Location = new System.Drawing.Point(369, 119);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(75, 27);
            this.btnEditar.TabIndex = 12;
            this.btnEditar.Texto = "Editar";
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnCriar
            // 
            this.btnCriar.AnguloColor = 20F;
            this.btnCriar.borderRadius = 40;
            this.btnCriar.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnCriar.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnCriar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCriar.ForeColor = System.Drawing.Color.White;
            this.btnCriar.Location = new System.Drawing.Point(578, 265);
            this.btnCriar.Name = "btnCriar";
            this.btnCriar.Size = new System.Drawing.Size(126, 39);
            this.btnCriar.TabIndex = 13;
            this.btnCriar.Texto = "Criar";
            this.btnCriar.Click += new System.EventHandler(this.btnCriar_Click);
            // 
            // FrmNovoProject
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(716, 316);
            this.Controls.Add(this.btnCriar);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.btnCloser);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmNovoProject";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmNovoProject";
            this.Load += new System.EventHandler(this.FrmNovoProject_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbTema)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private FerramentasMod.TextBoxMod txbDiretory;
        private FerramentasMod.PanelMod panelMod1;
        private System.Windows.Forms.Panel panel2;
        private FerramentasMod.ButtonIconMod btnCloser;
        private System.Windows.Forms.Panel panel4;
        private FerramentasMod.PanelMod panelMod2;
        private FerramentasMod.PanelMod btnEditar;
        private FerramentasMod.PanelMod btnCriar;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.PictureBox ptbTema;
        public FerramentasMod.TextBoxMod txbNomeProject;
    }
}