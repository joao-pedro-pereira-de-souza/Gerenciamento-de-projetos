﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class FrmConfigDiretorySystem : Form
    {
        public FrmConfigDiretorySystem()
        {
            InitializeComponent();
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        string diretory;

        private void btnEditarDiretory_Click(object sender, EventArgs e)
        {

            try
            {

                if (txtDiretory.Text == "")
                {
                    Business.ControlFileProject.SalvarDiretorioSetting(diretory);

                    Business.ControlFileProject pasta = new Business.ControlFileProject();

                    pasta.CriarPastasImportantes();


                    this.Close();
                }
                else
                {
                    MessageBox.Show("Selecione um Diretório");
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
          



        }

        #region Sistema de Arrastar formulário


        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);


        #endregion


        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }


        #endregion

        private void btnCloser_Click(object sender, EventArgs e)
        {

            try
            {
                MessageBox.Show(@"Seus projetos vão ser salvos no C:\");

                Business.ControlFileProject.SalvarDiretorioSetting(@"C:\");

                Business.ControlFileProject pasta = new Business.ControlFileProject();

                pasta.CriarPastasImportantes();

                this.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           
        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog browser = new FolderBrowserDialog();

            

            if (browser.ShowDialog() == DialogResult.OK)
            {
                txtDiretory.Text = browser.SelectedPath;

                diretory = browser.SelectedPath;
            }
        }

        private void btnEditarDiretory_Load(object sender, EventArgs e)
        {

        }
    }
}
