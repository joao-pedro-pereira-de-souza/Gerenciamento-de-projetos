﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace UI.UIConfigs
{
    public partial class FrmDadosConnect : Form
    {
        public FrmDadosConnect()
        {
            InitializeComponent();
        }

        private string diretory;

       

        private void FrmDadosConnect_Load(object sender, EventArgs e)
        {
           
        }
        private string SelectOp = "Copy";
        public void SelectOpFile()
        {
            if (SelectOp == "Copy")
            {
                btnCopy.BackColor = Color.FromArgb(88, 88, 88);
                btnMove.BackColor = Color.FromArgb(51, 51, 51);

            }

            else if (SelectOp == "Move")
            {
                btnCopy.BackColor = Color.FromArgb(51, 51, 51);
                btnMove.BackColor = Color.FromArgb(88, 88, 88);
            }
        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileExcel = new OpenFileDialog();

            fileExcel.Filter = "Excel Workbook|*.xlsx|Excel 97 2003 Workbook|*.xls";

            fileExcel.ValidateNames = true;

            if(fileExcel.ShowDialog() == DialogResult.OK)
            {
                txtDiretory.Text = fileExcel.FileName;

                btnConnect.Enabled = true;

                diretory = fileExcel.FileName;
                
            }


        }

        private void btnConnect_Click(object sender, EventArgs e)
        {

            try
            {
                Business.ControlFileProject pasta = new Business.ControlFileProject();

                pasta.VerificarPasta(Business.DadosUsuario.DiretoryProject + @"\Dados", Business.DadosUsuario.DiretoryProject + @"\", "Dados");

                if (SelectOp == "Copy")
                {
                    pasta.CopiarFile(diretory, Business.DadosUsuario.DiretoryProject + @"\Dados\" + Path.GetFileName(diretory));

                    MessageBox.Show("O arquivo foi copiado para o projeto");
                }
                else
                {
                    pasta.MoverFile(diretory, Business.DadosUsuario.DiretoryProject + @"\Dados\" + Path.GetFileName(diretory));

                    MessageBox.Show("O arquivo foi movido para o projeto");
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro :\n" + ex.Message);

            }
            
      

        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            SelectOp = "Copy";

            SelectOpFile();
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            SelectOp = "Move";

            SelectOpFile();
        }
    }
}
