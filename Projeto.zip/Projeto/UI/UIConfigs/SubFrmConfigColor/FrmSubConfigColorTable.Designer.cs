﻿namespace UI.UIConfigs
{
    partial class FrmSubConfigColorTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.pnlCor1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panelMod1 = new FerramentasMod.PanelMod();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlColor2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelMod2 = new FerramentasMod.PanelMod();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pnlColor3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panelMod3 = new FerramentasMod.PanelMod();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pnlColor5 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panelMod4 = new FerramentasMod.PanelMod();
            this.panel9 = new System.Windows.Forms.Panel();
            this.pnlColor4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panelMod5 = new FerramentasMod.PanelMod();
            this.btnAlterar = new FerramentasMod.ButtonElipse();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label2.Location = new System.Drawing.Point(36, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(262, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "Configurações de cores da tabela";
            // 
            // pnlCor1
            // 
            this.pnlCor1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.pnlCor1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCor1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlCor1.Location = new System.Drawing.Point(215, 4);
            this.pnlCor1.Name = "pnlCor1";
            this.pnlCor1.Size = new System.Drawing.Size(43, 33);
            this.pnlCor1.TabIndex = 4;
            this.pnlCor1.Click += new System.EventHandler(this.pnlCor1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label3.Location = new System.Drawing.Point(14, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "Cor de fundo da Coluna :";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.pnlCor1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.panelMod1);
            this.panel3.Location = new System.Drawing.Point(40, 90);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(491, 41);
            this.panel3.TabIndex = 5;
            // 
            // panelMod1
            // 
            this.panelMod1.AnguloColor = 45F;
            this.panelMod1.borderRadius = 10;
            this.panelMod1.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod1.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod1.ForeColor = System.Drawing.Color.White;
            this.panelMod1.Location = new System.Drawing.Point(0, 0);
            this.panelMod1.Name = "panelMod1";
            this.panelMod1.Size = new System.Drawing.Size(491, 41);
            this.panelMod1.TabIndex = 0;
            this.panelMod1.Texto = "";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pnlColor2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panelMod2);
            this.panel1.Location = new System.Drawing.Point(40, 158);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(491, 41);
            this.panel1.TabIndex = 6;
            // 
            // pnlColor2
            // 
            this.pnlColor2.BackColor = System.Drawing.Color.White;
            this.pnlColor2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlColor2.Location = new System.Drawing.Point(138, 4);
            this.pnlColor2.Name = "pnlColor2";
            this.pnlColor2.Size = new System.Drawing.Size(43, 33);
            this.pnlColor2.TabIndex = 4;
            this.pnlColor2.Click += new System.EventHandler(this.pnlColor2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label1.Location = new System.Drawing.Point(14, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Texto Coluna :";
            // 
            // panelMod2
            // 
            this.panelMod2.AnguloColor = 45F;
            this.panelMod2.borderRadius = 10;
            this.panelMod2.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod2.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod2.ForeColor = System.Drawing.Color.White;
            this.panelMod2.Location = new System.Drawing.Point(0, 0);
            this.panelMod2.Name = "panelMod2";
            this.panelMod2.Size = new System.Drawing.Size(491, 41);
            this.panelMod2.TabIndex = 0;
            this.panelMod2.Texto = "";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pnlColor3);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.panelMod3);
            this.panel5.Location = new System.Drawing.Point(40, 226);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(491, 41);
            this.panel5.TabIndex = 7;
            // 
            // pnlColor3
            // 
            this.pnlColor3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.pnlColor3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlColor3.Location = new System.Drawing.Point(215, 4);
            this.pnlColor3.Name = "pnlColor3";
            this.pnlColor3.Size = new System.Drawing.Size(43, 33);
            this.pnlColor3.TabIndex = 4;
            this.pnlColor3.Click += new System.EventHandler(this.pnlColor3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label4.Location = new System.Drawing.Point(14, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cor de Seleção da linha  :";
            // 
            // panelMod3
            // 
            this.panelMod3.AnguloColor = 45F;
            this.panelMod3.borderRadius = 10;
            this.panelMod3.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod3.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod3.ForeColor = System.Drawing.Color.White;
            this.panelMod3.Location = new System.Drawing.Point(0, 0);
            this.panelMod3.Name = "panelMod3";
            this.panelMod3.Size = new System.Drawing.Size(491, 41);
            this.panelMod3.TabIndex = 0;
            this.panelMod3.Texto = "";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pnlColor5);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.panelMod4);
            this.panel7.Location = new System.Drawing.Point(40, 362);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(491, 41);
            this.panel7.TabIndex = 8;
            // 
            // pnlColor5
            // 
            this.pnlColor5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlColor5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlColor5.Location = new System.Drawing.Point(123, 4);
            this.pnlColor5.Name = "pnlColor5";
            this.pnlColor5.Size = new System.Drawing.Size(43, 33);
            this.pnlColor5.TabIndex = 4;
            this.pnlColor5.Click += new System.EventHandler(this.pnlColor5_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label5.Location = new System.Drawing.Point(14, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 21);
            this.label5.TabIndex = 3;
            this.label5.Text = "Texto linha :";
            // 
            // panelMod4
            // 
            this.panelMod4.AnguloColor = 45F;
            this.panelMod4.borderRadius = 10;
            this.panelMod4.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod4.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod4.ForeColor = System.Drawing.Color.White;
            this.panelMod4.Location = new System.Drawing.Point(0, 0);
            this.panelMod4.Name = "panelMod4";
            this.panelMod4.Size = new System.Drawing.Size(491, 41);
            this.panelMod4.TabIndex = 0;
            this.panelMod4.Texto = "";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.pnlColor4);
            this.panel9.Controls.Add(this.label6);
            this.panel9.Controls.Add(this.panelMod5);
            this.panel9.Location = new System.Drawing.Point(40, 294);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(491, 41);
            this.panel9.TabIndex = 9;
            // 
            // pnlColor4
            // 
            this.pnlColor4.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlColor4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlColor4.Location = new System.Drawing.Point(243, 4);
            this.pnlColor4.Name = "pnlColor4";
            this.pnlColor4.Size = new System.Drawing.Size(43, 33);
            this.pnlColor4.TabIndex = 4;
            this.pnlColor4.Click += new System.EventHandler(this.pnlColor4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label6.Location = new System.Drawing.Point(14, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(223, 21);
            this.label6.TabIndex = 3;
            this.label6.Text = "Cor Texto Seleção da linha  :";
            // 
            // panelMod5
            // 
            this.panelMod5.AnguloColor = 45F;
            this.panelMod5.borderRadius = 10;
            this.panelMod5.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod5.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panelMod5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod5.ForeColor = System.Drawing.Color.White;
            this.panelMod5.Location = new System.Drawing.Point(0, 0);
            this.panelMod5.Name = "panelMod5";
            this.panelMod5.Size = new System.Drawing.Size(491, 41);
            this.panelMod5.TabIndex = 0;
            this.panelMod5.Texto = "";
            // 
            // btnAlterar
            // 
            this.btnAlterar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAlterar.AnguloColor = 45F;
            this.btnAlterar.borderRadius = 10;
            this.btnAlterar.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnAlterar.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnAlterar.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnAlterar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlterar.EfeitoTexto = true;
            this.btnAlterar.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterar.ForeColor = System.Drawing.Color.White;
            this.btnAlterar.Location = new System.Drawing.Point(497, 427);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Size = new System.Drawing.Size(132, 34);
            this.btnAlterar.TabIndex = 10;
            this.btnAlterar.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterar.Texto = "Alterar Cores";
            this.btnAlterar.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterar.Click += new System.EventHandler(this.btnAlterar_Click);
            // 
            // FrmSubConfigColorTable
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(641, 479);
            this.Controls.Add(this.btnAlterar);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label2);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmSubConfigColorTable";
            this.Text = "FrmSubConfigColorTable";
            this.Load += new System.EventHandler(this.FrmSubConfigColorTable_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnlCor1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private FerramentasMod.PanelMod panelMod1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlColor2;
        private System.Windows.Forms.Label label1;
        private FerramentasMod.PanelMod panelMod2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel pnlColor3;
        private System.Windows.Forms.Label label4;
        private FerramentasMod.PanelMod panelMod3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel pnlColor5;
        private System.Windows.Forms.Label label5;
        private FerramentasMod.PanelMod panelMod4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel pnlColor4;
        private System.Windows.Forms.Label label6;
        private FerramentasMod.PanelMod panelMod5;
        private FerramentasMod.ButtonElipse btnAlterar;
    }
}