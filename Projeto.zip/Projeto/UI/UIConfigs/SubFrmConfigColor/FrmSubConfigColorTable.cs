﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class FrmSubConfigColorTable : Form
    {

        public  DataGridView DgvOriginal = new DataGridView();

        public FrmConfigTable frmTable = new FrmConfigTable();

        public FrmConfigColor Pai = new FrmConfigColor();

        public FrmSubConfigColorTable()
        {
            InitializeComponent();
        }

        #region Select Colors (ColorDialog)

        private void pnlCor1_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();

            if(colorDialog.ShowDialog() == DialogResult.OK)
            {
                pnlCor1.BackColor = colorDialog.Color;
            }

        }

        private void pnlColor2_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                pnlColor2.BackColor = colorDialog.Color;
            }
        }

        private void pnlColor3_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                pnlColor3.BackColor = colorDialog.Color;
            }
        }

        private void pnlColor4_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                pnlColor4.BackColor = colorDialog.Color;
            }
        }

        private void pnlColor5_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                pnlColor5.BackColor = colorDialog.Color;
            }
        }

        #endregion

        private void btnAlterar_Click(object sender, EventArgs e)
        {

            frmTable.dgvDados.ColumnHeadersDefaultCellStyle.BackColor = pnlCor1.BackColor;
            frmTable.dgvDados.ColumnHeadersDefaultCellStyle.ForeColor = pnlColor2.BackColor;

            frmTable.dgvDados.ColumnHeadersDefaultCellStyle.SelectionBackColor = pnlCor1.BackColor;
            frmTable.dgvDados.ColumnHeadersDefaultCellStyle.SelectionForeColor = pnlColor2.BackColor;


            frmTable.dgvDados.RowsDefaultCellStyle.SelectionBackColor = pnlColor3.BackColor;
            frmTable.dgvDados.RowsDefaultCellStyle.SelectionForeColor = pnlColor4.BackColor;


            frmTable.dgvDados.RowsDefaultCellStyle.ForeColor = pnlColor5.BackColor;

            MessageBox.Show("Cores Alteradas !");

            Pai.Close();

        }

        private void FrmSubConfigColorTable_Load(object sender, EventArgs e)
        {

            //Atualizar Campos de cores do dgvDados;

            pnlCor1.BackColor =frmTable.dgvDados.ColumnHeadersDefaultCellStyle.BackColor;
            pnlColor2.BackColor = frmTable.dgvDados.ColumnHeadersDefaultCellStyle.ForeColor;
            pnlColor3.BackColor = frmTable.dgvDados.RowsDefaultCellStyle.SelectionBackColor;
            pnlColor4.BackColor = frmTable.dgvDados.RowsDefaultCellStyle.SelectionForeColor;
            pnlColor5.BackColor = frmTable.dgvDados.RowsDefaultCellStyle.ForeColor;

            //

            
        }
    }
}
