﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class FrmConfigDados : Form
    {

       private string selectOpTop;

        public bool CriarForaP = false;

        FrmDadosConnect connect;

        UserDadosCreate.FrmCreateDadosPG1 indexCreate;

        public FrmConfigDados(string select)
        {
            InitializeComponent();

            selectOpTop = select;

            SystemSelectOpTop();
        }


        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        private void SystemSelectOpTop()
        {
            switch (selectOpTop)
            {
                case "Connect":

                    btnConfDadosTables.BackColor = Color.FromArgb(46, 204, 113);
                    btnConfCreateTables.BackColor = Color.FromArgb(88, 88, 88);
                    ptbInfo.Image = Properties.Resources.iconeConnect;

                    lblInfo.Text = "Connection Table:\n Conexão  tabelas Excel.";


                    pnlInfo.BringToFront();

                    break;

                case "Create":

                    btnConfCreateTables.BackColor = Color.FromArgb(46, 204, 113);
                    btnConfDadosTables.BackColor = Color.FromArgb(88, 88, 88);
                    ptbInfo.Image = Properties.Resources.iconCreateDados;
                    lblInfo.Text = "Criar uma Tabela:\n essa versão a criação de tabelas é transformada em arquivo Excel.";

                    break;

                default:

                    MessageBox.Show("ocorreu um erro ao selecionar a opção \n" + "Tente novamente.");

                    break;

                    
            }
        }

        private void btnConfDadosTables_Click(object sender, EventArgs e)
        {
            selectOpTop = "Connect";

            SystemSelectOpTop();



            BringToFront();
        }

        private void btnConfCreateTables_Click(object sender, EventArgs e)
        {
            selectOpTop = "Create";

            SystemSelectOpTop();


            //  

            pnlInfo.BringToFront();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnInfoOK_Click(object sender, EventArgs e)
        {
            switch (selectOpTop)
            {
                case "Connect":

                    connect.BringToFront();

                    break;

                case "Create":

                    indexCreate.BringToFront();

                    break;
                    //Caso nenhuma das opções for selecionado
                default:



                    break;
            }
        }

        private void pnlContainer_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlFill_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FrmConfigDados_Load(object sender, EventArgs e)
        {
            connect = new FrmDadosConnect();

            connect.TopLevel = false;
            /// pnlInfo.Visible = false;
            pnlContainer.Controls.Add(connect);
            connect.Dock = DockStyle.Fill;

            pnlContainer.Tag = connect;
            connect.Show();

            if (CriarForaP == true)
            {

                indexCreate = new UserDadosCreate.FrmCreateDadosPG1();

               

                indexCreate.frmDados = this;

                indexCreate.CriarForaP = true;

                indexCreate.TopLevel = false;

                indexCreate.Dock = DockStyle.Fill;

                indexCreate.FormBorderStyle = FormBorderStyle.None;

                pnlContainer.Controls.Add(indexCreate);

                pnlContainer.Tag = indexCreate;

                indexCreate.Show();

            }

            else
            {

                indexCreate = new UserDadosCreate.FrmCreateDadosPG1();
             
                indexCreate.frmDados = this;

                indexCreate.CriarForaP = false;

                indexCreate.TopLevel = false;

                indexCreate.Dock = DockStyle.Fill;

                pnlContainer.Controls.Add(indexCreate);
  
                pnlContainer.Tag = indexCreate;

                indexCreate.Show();
            }

            pnlInfo.BringToFront();
        }
    }
}
