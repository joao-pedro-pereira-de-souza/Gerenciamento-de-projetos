﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class FrmConfigRecuperarSenha : Form
    {

        public string Email;

        private DataTable DadosUser = new DataTable();

        public FrmConfigRecuperarSenha()
        {
            InitializeComponent();
            lblEmailRecuperacao.Text = Email;
        }


        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion
        #region Sistema de Arrastar formulário


        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }


        #endregion
        private void btnCloser_Click(object sender, EventArgs e)
        {

            DadosUser.Clear();
            this.Close();
        }

       
        private void btnProximo_Click(object sender, EventArgs e)
        {

            try
            {
                string verificacao = string.Format("Select recuperarSenha from usuarios where recuperarSenha={0}", txtSenha.Text);

                Business.ControlDatabase BD = new Business.ControlDatabase();

                if (BD.VerifRecuperar(verificacao) == true)
                {



                    // Deixar Nulo o campo recuperar senha.
                    string cmd = string.Format("Update usuarios Set recuperarSenha=null where email='{0}'", Email);

                    BD.AdicionarRegistro(cmd);

                    DataTable tb = BD.ShowDataTable(string.Format("Select * from usuarios where email='{0}'", Email));

                    // Configurando a mensagem

                  

                    Business.ControlConfigEnviarEmail eviar = new Business.ControlConfigEnviarEmail(

                         tema: "Dados da conta",
                         titulo: tb.Rows[0][1].ToString(),
                         texto: tb.Rows[0][2].ToString(),
                         subtxt: "Senha: " + tb.Rows[0][3].ToString(),
                         subbject: "Recuperar a senha",
                         Sender: new List<string> { Email }

                         );
                    //

                    MessageBox.Show("Dados enviado");

                }
                else
                {
                    MessageBox.Show(" Não encontrado");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
            
          
        }

       
        private void btnInfo_Click(object sender, EventArgs e)
        {
            FrmMensagem mensagem = new FrmMensagem();

            mensagem.lblTitulo.Text = "Como funciona o recuperar senha ?";
            mensagem.lblConteudo.Text = "1) É enviado um código de confirmação no email do usuário.\n" +
                "2) Com a confirmação do código é enviado outra mensagem, com os dados do usuário  ";

            mensagem.ptbMensagem.Image = Properties.Resources.iconSendBox;

            mensagem.ShowDialog();
        }
    }
}
