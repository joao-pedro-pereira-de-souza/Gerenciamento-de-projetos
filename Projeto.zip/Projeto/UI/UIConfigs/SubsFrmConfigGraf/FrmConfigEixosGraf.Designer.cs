﻿namespace UI.UIConfigs
{
    partial class FrmConfigEixosGraf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.btnAdicionarEixo = new FerramentasMod.ButtonElipse();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNomeColuna = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnEixoX = new System.Windows.Forms.Button();
            this.btnEixoY = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnCloser);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(430, 38);
            this.panel1.TabIndex = 1;
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(394, 3);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 12;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // btnAdicionarEixo
            // 
            this.btnAdicionarEixo.AnguloColor = 45F;
            this.btnAdicionarEixo.borderRadius = 10;
            this.btnAdicionarEixo.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAdicionarEixo.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnAdicionarEixo.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnAdicionarEixo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdicionarEixo.EfeitoTexto = true;
            this.btnAdicionarEixo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarEixo.ForeColor = System.Drawing.Color.White;
            this.btnAdicionarEixo.Location = new System.Drawing.Point(256, 140);
            this.btnAdicionarEixo.Name = "btnAdicionarEixo";
            this.btnAdicionarEixo.Size = new System.Drawing.Size(145, 29);
            this.btnAdicionarEixo.TabIndex = 20;
            this.btnAdicionarEixo.TextLeaver = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarEixo.Texto = "Adicionar Eixo";
            this.btnAdicionarEixo.TextShow = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionarEixo.Click += new System.EventHandler(this.btnAdicionarEixo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 21);
            this.label1.TabIndex = 21;
            this.label1.Text = "Coluna :";
            // 
            // lblNomeColuna
            // 
            this.lblNomeColuna.AutoSize = true;
            this.lblNomeColuna.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeColuna.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.lblNomeColuna.Location = new System.Drawing.Point(105, 57);
            this.lblNomeColuna.Name = "lblNomeColuna";
            this.lblNomeColuna.Size = new System.Drawing.Size(0, 17);
            this.lblNomeColuna.TabIndex = 22;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.btnEixoX);
            this.panel11.Controls.Add(this.btnEixoY);
            this.panel11.Location = new System.Drawing.Point(31, 136);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(182, 33);
            this.panel11.TabIndex = 23;
            // 
            // btnEixoX
            // 
            this.btnEixoX.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEixoX.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEixoX.FlatAppearance.BorderSize = 0;
            this.btnEixoX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEixoX.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEixoX.Location = new System.Drawing.Point(89, 0);
            this.btnEixoX.Name = "btnEixoX";
            this.btnEixoX.Size = new System.Drawing.Size(89, 31);
            this.btnEixoX.TabIndex = 1;
            this.btnEixoX.Text = "X";
            this.btnEixoX.UseVisualStyleBackColor = true;
            this.btnEixoX.Click += new System.EventHandler(this.btnEixoX_Click);
            // 
            // btnEixoY
            // 
            this.btnEixoY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(88)))), ((int)(((byte)(88)))));
            this.btnEixoY.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEixoY.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnEixoY.FlatAppearance.BorderSize = 0;
            this.btnEixoY.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEixoY.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEixoY.Location = new System.Drawing.Point(0, 0);
            this.btnEixoY.Name = "btnEixoY";
            this.btnEixoY.Size = new System.Drawing.Size(89, 31);
            this.btnEixoY.TabIndex = 0;
            this.btnEixoY.Text = "Y";
            this.btnEixoY.UseVisualStyleBackColor = false;
            this.btnEixoY.Click += new System.EventHandler(this.btnEixoY_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 21);
            this.label2.TabIndex = 24;
            this.label2.Text = "Eixo :";
            // 
            // FrmConfigEixosGraf
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.ClientSize = new System.Drawing.Size(430, 203);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.lblNomeColuna);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAdicionarEixo);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmConfigEixosGraf";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FrmConfigEixosGraf";
            this.Load += new System.EventHandler(this.FrmConfigEixosGraf_Load);
            this.panel1.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private FerramentasMod.ButtonIconMod btnCloser;
        public FerramentasMod.ButtonElipse btnAdicionarEixo;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblNomeColuna;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btnEixoX;
        private System.Windows.Forms.Button btnEixoY;
        private System.Windows.Forms.Label label2;
    }
}