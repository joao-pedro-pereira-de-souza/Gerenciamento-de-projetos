﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;

namespace UI.UIConfigs
{
    public partial class FrmSubConfigGraf : Form
    {


        public int y; public int x;

        public DataTable EditTabela = new DataTable();
       
        public FrmSubConfigGraf()
        {
            InitializeComponent();
        }

        #region System config Colors graf

        public void ColorsGraf()
        {
            #region Sistema para adicionar as configurações de cores na tabela InfoDesignGraf
            /*
            DataRow dados = FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.NewRow(); // Criar uma variável de linha com base na tabela.

            // Adicionar valores na linha
            dados[0] = "Transparent"; // BackGround
            dados[1] = "Transparent"; // BanckGround Gráfico

            dados[2] = "#ecf0f1";//LinerColor Y = Branco
            dados[3] = "#ecf0f1";//LinerColor X = Branco
            dados[4] = "2";// Borda ( o padrão é 2 , mas alguns tipos de gráficos não usam esse campo.

            dados[5] = "#ecf0f1";//endLinerColor Y = Branco
            dados[6] = "Transparent";//endLinerColor X

            dados[7] = "Transparent";//MajorTickMark Y
            dados[8] = "Transparent";//MajorTickMark X

            dados[9] = "#ecf0f1";//Label Y
            dados[10] = "#ecf0f1";//Label X

            dados[11] = "#2ecc71";//Color = flat verde

            // Em obra 
            dados[12] = "none";//Numerio de indentificação das cores do gráfico.
            //


            //

            FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.Rows.InsertAt(dados, 0); // inserir a linha + posição.

            FullDadosCards.Cards[DadosCard.numericCard].InfoDesignGraf.AcceptChanges(); // Salvar as alterações
            */
            #endregion
    
        }
        

        #endregion

        //SemPronto

        private void btnCriarGrafico_Click(object sender, EventArgs e)
        {

            try
            {
                if (lblEixoX.Text != "Vazio" && lblEixoY.Text != "Vazio")
                {
                    #region Adicionar os dados da Tabela na classe de Conjuto de dados

                    //Adicionando colunas na tabela vazia.
                    TableDadosGraf.tabela.Clear();
                    TableDadosGraf.tabela.Columns.Clear();

                    TableDadosGraf.tabela.Columns.Add("eixoY");
                    TableDadosGraf.tabela.Columns.Add("eixoX");

                    //

                    for (int i = 0; i < dgvDados.Rows.Count - 1; i++)
                    {

                        TableDadosGraf.tabela.Rows.Add(dgvDados.Rows[i].Cells[y].Value.ToString(), dgvDados.Rows[i].Cells[x].Value.ToString());

                    }

                    #endregion


                    MessageBox.Show("Eixos Adicionados no gráfico");
                    //  ColorsGraf();

                    ControlFrmsStatOpen.controlGraf.btnAdicionar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Selecione os dos Eixos de forma correta");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :\n"+ ex.Message);
            }
           

        }

        //SemiPronto.
  
        private void dgvDados_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            FrmConfigEixosGraf configEixo = new FrmConfigEixosGraf();

            configEixo.lblNomeColuna.Text = dgvDados.Columns[e.ColumnIndex].HeaderText;

            configEixo.SelectTable = e.ColumnIndex;

            configEixo.subGraf = this;

            configEixo.ShowDialog();

        }

        private void FrmSubConfigGraf_Load(object sender, EventArgs e)
        {
            dgvDados.DataSource = EditTabela;
        }
    }
}
