﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI.UIConfigs
{
    public partial class FrmConfigEixosGraf : Form
    {

        public int SelectTable;

        private int select = 0;

        public FrmSubConfigGraf subGraf = new FrmSubConfigGraf();

        private string SelectOp = "y";

        public FrmConfigEixosGraf()
        {
            InitializeComponent();
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        private void FrmConfigEixosGraf_Load(object sender, EventArgs e)
        {
            decimal deci;
            bool isNum = decimal.TryParse(subGraf.dgvDados.Rows[0].Cells[SelectTable].Value.ToString(), out deci);


            if(isNum == true)
            {
                SelectOp = "y";
                SelectOpEixo();

                select = 0;
            }
            else
            {
         
                SelectOp = "x";
                SelectOpEixo();

                select = 1;
            }
               lblNomeColuna.Text = subGraf.dgvDados.Columns[SelectTable].HeaderText;
        
        }

        private void btnAdicionarEixo_Click(object sender, EventArgs e)
        {
            if(select == 0)
            {
               
                if (subGraf .lblEixoY.Text == "Vazio")
                {
                    subGraf.lblEixoY.Text = lblNomeColuna.Text;

                    subGraf.y = SelectTable;

                    DataGridViewHeaderCell header = subGraf .dgvDados.Columns[SelectTable].HeaderCell;

                    header.Style.BackColor = Color.FromArgb(155, 89, 182);
                }
                else
                {

                    subGraf.lblEixoY.Text = lblNomeColuna.Text;

                    int NumericAnte = subGraf.y;
                    subGraf.y = SelectTable;
                    // Modificar o eixo selecionado antes , para a cor padrão.
                    DataGridViewHeaderCell headerAnterior =
                        subGraf.dgvDados.Columns[NumericAnte].HeaderCell;

                    headerAnterior.Style.BackColor = Color.FromArgb(46, 125, 50);

                    //

                    //Editar a cor de seleção para a coluna nova.

                    DataGridViewHeaderCell header = subGraf.dgvDados.Columns[SelectTable].HeaderCell;

                    header.Style.BackColor = Color.FromArgb(155, 89, 182);

                    //
                }


            }
            else
            {
                //Verificar se já houve edição no eixo selecionado.
                //Para editar o Front-End(Editar a cor selecionada antes para a cor padão , e a nova seleção com a cor do eixo.
                if(subGraf.lblEixoX.Text == "Vazio")
                {
                    subGraf.lblEixoX.Text = lblNomeColuna.Text;

                    subGraf.x = SelectTable;

                    DataGridViewHeaderCell header =subGraf.dgvDados.Columns[SelectTable].HeaderCell;

                    header.Style.BackColor = Color.FromArgb(52, 152, 219);
                }
                else
                {
                    subGraf.lblEixoX.Text = lblNomeColuna.Text;
                    int NumericAnte = subGraf.x;
                    subGraf.x = SelectTable;
                    // Modificar o eixo selecionado antes , para a cor padrão.
                    DataGridViewHeaderCell headerAnterior = 
                        subGraf.dgvDados.Columns[NumericAnte].HeaderCell;

                    headerAnterior.Style.BackColor = Color.FromArgb(46, 125, 50);

                    //

                    //Editar a cor de seleção para a coluna nova.

                    DataGridViewHeaderCell header = subGraf.dgvDados.Columns[SelectTable].HeaderCell;

                    header.Style.BackColor = Color.FromArgb(52, 152, 219);

                    //
                }
            }

            this.Close();
        }
        #region Sistema Select Opções de cores(FrontEnd)

        public void SelectOpEixo()
        {
            if (SelectOp == "y")
            {
                btnEixoY.BackColor = Color.FromArgb(88, 88, 88);
                btnEixoX.BackColor = Color.FromArgb(51, 51, 51);

            }

            else if (SelectOp == "x")
            {
                btnEixoY.BackColor = Color.FromArgb(51, 51, 51);
                btnEixoX.BackColor = Color.FromArgb(88, 88, 88);
            }
        }

        #endregion


        private void btnEixoY_Click(object sender, EventArgs e)
        {
            if(subGraf.dgvDados.Columns[SelectTable].ValueType == typeof(decimal))
            {
                SelectOp = "y";
                SelectOpEixo();

                select = 0;
            }
            else
            {
                MessageBox.Show("O valor Y precisa ser Numério.\n selecione uma coluna numérioa para adicionar o Y do gráfico.");

             
            }
           
        }

        private void btnEixoX_Click(object sender, EventArgs e)
        {
            SelectOp = "x";
            SelectOpEixo();

            select = 1;



        }

        private void btnCloser_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
