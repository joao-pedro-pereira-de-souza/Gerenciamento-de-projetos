﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UI.UIConfigs
{
    public class ControlFrmsStatOpen
    {

        public static FrmConfigGraf controlGraf = new FrmConfigGraf();

        public static UserContainerV1 ContainerGraf = new UserContainerV1();

        public static UserSelectTable UserTable = new UserSelectTable();
    }
}
