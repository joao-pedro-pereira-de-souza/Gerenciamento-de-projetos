﻿namespace UI.UIConfigs
{
    partial class FrmConfigDiretorySystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtDiretory = new System.Windows.Forms.TextBox();
            this.panelMod2 = new FerramentasMod.PanelMod();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.btnEditarDiretory = new FerramentasMod.ButtonElipse();
            this.btnBrowser = new FerramentasMod.ButtonElipse();
            this.panel2.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtDiretory);
            this.panel2.Controls.Add(this.panelMod2);
            this.panel2.Location = new System.Drawing.Point(28, 61);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(316, 38);
            this.panel2.TabIndex = 5;
            // 
            // txtDiretory
            // 
            this.txtDiretory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtDiretory.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDiretory.Enabled = false;
            this.txtDiretory.Location = new System.Drawing.Point(12, 8);
            this.txtDiretory.Name = "txtDiretory";
            this.txtDiretory.Size = new System.Drawing.Size(301, 22);
            this.txtDiretory.TabIndex = 15;
            // 
            // panelMod2
            // 
            this.panelMod2.AnguloColor = 45F;
            this.panelMod2.borderRadius = 10;
            this.panelMod2.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod2.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod2.ForeColor = System.Drawing.Color.White;
            this.panelMod2.Location = new System.Drawing.Point(0, 0);
            this.panelMod2.Name = "panelMod2";
            this.panelMod2.Size = new System.Drawing.Size(316, 38);
            this.panelMod2.TabIndex = 2;
            this.panelMod2.Texto = "";
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.btnCloser);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(434, 37);
            this.pnlTop.TabIndex = 6;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(225, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Edite o diretório dos seus projetos.";
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(401, 3);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 10;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // btnEditarDiretory
            // 
            this.btnEditarDiretory.AnguloColor = 45F;
            this.btnEditarDiretory.borderRadius = 10;
            this.btnEditarDiretory.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnEditarDiretory.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnEditarDiretory.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnEditarDiretory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEditarDiretory.EfeitoTexto = true;
            this.btnEditarDiretory.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarDiretory.ForeColor = System.Drawing.Color.White;
            this.btnEditarDiretory.Location = new System.Drawing.Point(28, 105);
            this.btnEditarDiretory.Name = "btnEditarDiretory";
            this.btnEditarDiretory.Size = new System.Drawing.Size(121, 31);
            this.btnEditarDiretory.TabIndex = 14;
            this.btnEditarDiretory.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarDiretory.Texto = "Editar";
            this.btnEditarDiretory.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarDiretory.Load += new System.EventHandler(this.btnEditarDiretory_Load);
            this.btnEditarDiretory.Click += new System.EventHandler(this.btnEditarDiretory_Click);
            // 
            // btnBrowser
            // 
            this.btnBrowser.AnguloColor = 45F;
            this.btnBrowser.borderRadius = 10;
            this.btnBrowser.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnBrowser.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnBrowser.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnBrowser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowser.EfeitoTexto = true;
            this.btnBrowser.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowser.ForeColor = System.Drawing.Color.White;
            this.btnBrowser.Location = new System.Drawing.Point(350, 63);
            this.btnBrowser.Name = "btnBrowser";
            this.btnBrowser.Size = new System.Drawing.Size(56, 36);
            this.btnBrowser.TabIndex = 19;
            this.btnBrowser.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowser.Texto = "...";
            this.btnBrowser.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowser.Click += new System.EventHandler(this.btnBrowser_Click);
            // 
            // FrmConfigDiretorySystem
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(434, 163);
            this.Controls.Add(this.btnBrowser);
            this.Controls.Add(this.btnEditarDiretory);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmConfigDiretorySystem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmConfigDiretorySystem";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private FerramentasMod.PanelMod panelMod2;
        private System.Windows.Forms.Panel pnlTop;
        private FerramentasMod.ButtonIconMod btnCloser;
        private System.Windows.Forms.Label label1;
        private FerramentasMod.ButtonElipse btnEditarDiretory;
        private System.Windows.Forms.TextBox txtDiretory;
        private FerramentasMod.ButtonElipse btnBrowser;
    }
}