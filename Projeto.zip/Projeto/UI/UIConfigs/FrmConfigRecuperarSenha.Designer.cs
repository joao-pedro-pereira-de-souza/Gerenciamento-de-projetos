﻿namespace UI.UIConfigs
{
    partial class FrmConfigRecuperarSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtSenha = new FerramentasMod.TextBoxMod();
            this.panelMod2 = new FerramentasMod.PanelMod();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblEmailRecuperacao = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.btnProximo = new FerramentasMod.ButtonElipse();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnInfo = new FerramentasMod.ButtonIconMod();
            this.panel2.SuspendLayout();
            this.pnlTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtSenha);
            this.panel2.Controls.Add(this.panelMod2);
            this.panel2.Location = new System.Drawing.Point(12, 114);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(252, 38);
            this.panel2.TabIndex = 5;
            // 
            // txtSenha
            // 
            this.txtSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSenha.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtSenha.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtSenha.Location = new System.Drawing.Point(14, 8);
            this.txtSenha.MarcaText = "Código";
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(216, 22);
            this.txtSenha.TabIndex = 3;
            this.txtSenha.Text = "Código";
            // 
            // panelMod2
            // 
            this.panelMod2.AnguloColor = 45F;
            this.panelMod2.borderRadius = 10;
            this.panelMod2.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod2.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod2.ForeColor = System.Drawing.Color.White;
            this.panelMod2.Location = new System.Drawing.Point(0, 0);
            this.panelMod2.Name = "panelMod2";
            this.panelMod2.Size = new System.Drawing.Size(252, 38);
            this.panelMod2.TabIndex = 2;
            this.panelMod2.Texto = "";
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblTexto.Location = new System.Drawing.Point(18, 50);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(338, 21);
            this.lblTexto.TabIndex = 0;
            this.lblTexto.Text = "Digite o código enviado no email do perfil:";
            // 
            // lblEmailRecuperacao
            // 
            this.lblEmailRecuperacao.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailRecuperacao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.lblEmailRecuperacao.Location = new System.Drawing.Point(22, 74);
            this.lblEmailRecuperacao.Name = "lblEmailRecuperacao";
            this.lblEmailRecuperacao.Size = new System.Drawing.Size(334, 37);
            this.lblEmailRecuperacao.TabIndex = 1;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.pictureBox1);
            this.pnlTop.Controls.Add(this.btnCloser);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(565, 35);
            this.pnlTop.TabIndex = 8;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UI.Properties.Resources.iconSendBox;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(63, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(532, 3);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 5;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // btnProximo
            // 
            this.btnProximo.AnguloColor = 45F;
            this.btnProximo.borderRadius = 10;
            this.btnProximo.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnProximo.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnProximo.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnProximo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProximo.EfeitoTexto = true;
            this.btnProximo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProximo.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnProximo.Location = new System.Drawing.Point(273, 114);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(123, 38);
            this.btnProximo.TabIndex = 4;
            this.btnProximo.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProximo.Texto = "Verificar";
            this.btnProximo.TextShow = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProximo.Click += new System.EventHandler(this.btnProximo_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::UI.Properties.Resources.iconOkEmail;
            this.pictureBox2.Location = new System.Drawing.Point(418, 37);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(147, 194);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // btnInfo
            // 
            this.btnInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInfo.FlatAppearance.BorderSize = 0;
            this.btnInfo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInfo.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnInfo.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.btnInfo.IconColor = System.Drawing.Color.White;
            this.btnInfo.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.btnInfo.IconLeave = System.Drawing.Color.White;
            this.btnInfo.IconSize = 18;
            this.btnInfo.Location = new System.Drawing.Point(12, 199);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Rotation = 0D;
            this.btnInfo.Size = new System.Drawing.Size(21, 21);
            this.btnInfo.TabIndex = 11;
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // FrmConfigRecuperarSenha
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(565, 232);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnInfo);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.lblEmailRecuperacao);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmConfigRecuperarSenha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FrmConfigRecuperarSenha";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private FerramentasMod.TextBoxMod txtSenha;
        private FerramentasMod.PanelMod panelMod2;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Panel pnlTop;
        private FerramentasMod.ButtonIconMod btnCloser;
        private System.Windows.Forms.PictureBox pictureBox1;
        private FerramentasMod.ButtonElipse btnProximo;
        private FerramentasMod.ButtonIconMod btnInfo;
        private System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.Label lblEmailRecuperacao;
    }
}