﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;

namespace UI.UserGraficos
{
    public partial class GraficosPadrao : UserControl
    {

       

        public GraficosPadrao()
        {
            InitializeComponent();
           
                
            SystemSelectGraf select = new SystemSelectGraf(UIConfigs.ControlFrmsStatOpen.controlGraf.SelectChart);

            

            chartDados.Series.Clear();
            chartDados.ChartAreas.Clear();

            // Config Color BackGround


            chartDados.BackColor = Color.Transparent;
            //



            chartDados.Series.Add(select.ShowGraf());
            chartDados.ChartAreas.Add(select.configAria);


        }
    }
}
