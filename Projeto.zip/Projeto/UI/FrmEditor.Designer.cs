﻿namespace UI
{
    partial class FrmEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.btnInfo = new FerramentasMod.ButtonIconMod();
            this.pnlSubAdicionar = new System.Windows.Forms.Panel();
            this.btnDados = new FerramentasMod.ButtonIconMod();
            this.btnSistemaArquivo = new FerramentasMod.ButtonIconMod();
            this.btnGrafico = new FerramentasMod.ButtonIconMod();
            this.btnTabela = new FerramentasMod.ButtonIconMod();
            this.btnAdicionar = new FerramentasMod.ButtonIconMod();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblNomeProject = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlFill = new System.Windows.Forms.Panel();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.pnlContainerVazio = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pnlLinerTop = new System.Windows.Forms.Panel();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.lblSizeProject = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnMenu = new FerramentasMod.ButtonIconMod();
            this.btnMini = new FerramentasMod.ButtonIconMod();
            this.btnWindMax = new FerramentasMod.ButtonIconMod();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.btnWindMini = new FerramentasMod.ButtonIconMod();
            this.pnlLinerleft = new System.Windows.Forms.Panel();
            this.AniMenu = new System.Windows.Forms.Timer(this.components);
            this.pnlLeft.SuspendLayout();
            this.pnlSubAdicionar.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlFill.SuspendLayout();
            this.pnlContainer.SuspendLayout();
            this.pnlContainerVazio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLeft
            // 
            this.pnlLeft.Controls.Add(this.btnInfo);
            this.pnlLeft.Controls.Add(this.pnlSubAdicionar);
            this.pnlLeft.Controls.Add(this.btnAdicionar);
            this.pnlLeft.Controls.Add(this.panel3);
            this.pnlLeft.Controls.Add(this.panel2);
            this.pnlLeft.Controls.Add(this.panel1);
            this.pnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Size = new System.Drawing.Size(200, 622);
            this.pnlLeft.TabIndex = 0;
            // 
            // btnInfo
            // 
            this.btnInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInfo.FlatAppearance.BorderSize = 0;
            this.btnInfo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnInfo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInfo.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnInfo.IconChar = FontAwesome.Sharp.IconChar.InfoCircle;
            this.btnInfo.IconColor = System.Drawing.Color.White;
            this.btnInfo.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.btnInfo.IconLeave = System.Drawing.Color.White;
            this.btnInfo.IconSize = 18;
            this.btnInfo.Location = new System.Drawing.Point(12, 598);
            this.btnInfo.Name = "btnInfo";
            this.btnInfo.Rotation = 0D;
            this.btnInfo.Size = new System.Drawing.Size(21, 21);
            this.btnInfo.TabIndex = 3;
            this.btnInfo.UseVisualStyleBackColor = true;
            this.btnInfo.Click += new System.EventHandler(this.btnInfo_Click);
            // 
            // pnlSubAdicionar
            // 
            this.pnlSubAdicionar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.pnlSubAdicionar.Controls.Add(this.btnDados);
            this.pnlSubAdicionar.Controls.Add(this.btnSistemaArquivo);
            this.pnlSubAdicionar.Controls.Add(this.btnGrafico);
            this.pnlSubAdicionar.Controls.Add(this.btnTabela);
            this.pnlSubAdicionar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSubAdicionar.Location = new System.Drawing.Point(0, 161);
            this.pnlSubAdicionar.Name = "pnlSubAdicionar";
            this.pnlSubAdicionar.Size = new System.Drawing.Size(200, 164);
            this.pnlSubAdicionar.TabIndex = 4;
            // 
            // btnDados
            // 
            this.btnDados.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnDados.FlatAppearance.BorderSize = 0;
            this.btnDados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDados.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnDados.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDados.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnDados.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnDados.IconColor = System.Drawing.Color.Black;
            this.btnDados.IconHover = System.Drawing.Color.Black;
            this.btnDados.IconLeave = System.Drawing.Color.White;
            this.btnDados.IconSize = 16;
            this.btnDados.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDados.Location = new System.Drawing.Point(0, 120);
            this.btnDados.Name = "btnDados";
            this.btnDados.Padding = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.btnDados.Rotation = 0D;
            this.btnDados.Size = new System.Drawing.Size(200, 40);
            this.btnDados.TabIndex = 4;
            this.btnDados.Text = "Dados";
            this.btnDados.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDados.UseVisualStyleBackColor = true;
            this.btnDados.Click += new System.EventHandler(this.btnDados_Click);
            // 
            // btnSistemaArquivo
            // 
            this.btnSistemaArquivo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnSistemaArquivo.FlatAppearance.BorderSize = 0;
            this.btnSistemaArquivo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSistemaArquivo.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnSistemaArquivo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSistemaArquivo.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnSistemaArquivo.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnSistemaArquivo.IconColor = System.Drawing.Color.Black;
            this.btnSistemaArquivo.IconHover = System.Drawing.Color.Black;
            this.btnSistemaArquivo.IconLeave = System.Drawing.Color.White;
            this.btnSistemaArquivo.IconSize = 16;
            this.btnSistemaArquivo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSistemaArquivo.Location = new System.Drawing.Point(0, 80);
            this.btnSistemaArquivo.Name = "btnSistemaArquivo";
            this.btnSistemaArquivo.Padding = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.btnSistemaArquivo.Rotation = 0D;
            this.btnSistemaArquivo.Size = new System.Drawing.Size(200, 40);
            this.btnSistemaArquivo.TabIndex = 2;
            this.btnSistemaArquivo.Text = "Sistema de Arquivos";
            this.btnSistemaArquivo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSistemaArquivo.UseVisualStyleBackColor = true;
            this.btnSistemaArquivo.Click += new System.EventHandler(this.btnSistemaArquivo_Click);
            // 
            // btnGrafico
            // 
            this.btnGrafico.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnGrafico.FlatAppearance.BorderSize = 0;
            this.btnGrafico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGrafico.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnGrafico.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGrafico.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnGrafico.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnGrafico.IconColor = System.Drawing.Color.Black;
            this.btnGrafico.IconHover = System.Drawing.Color.Black;
            this.btnGrafico.IconLeave = System.Drawing.Color.White;
            this.btnGrafico.IconSize = 16;
            this.btnGrafico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGrafico.Location = new System.Drawing.Point(0, 40);
            this.btnGrafico.Name = "btnGrafico";
            this.btnGrafico.Padding = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.btnGrafico.Rotation = 0D;
            this.btnGrafico.Size = new System.Drawing.Size(200, 40);
            this.btnGrafico.TabIndex = 1;
            this.btnGrafico.Text = "Gráfico";
            this.btnGrafico.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGrafico.UseVisualStyleBackColor = true;
            this.btnGrafico.Click += new System.EventHandler(this.btnGrafico_Click);
            // 
            // btnTabela
            // 
            this.btnTabela.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTabela.FlatAppearance.BorderSize = 0;
            this.btnTabela.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTabela.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnTabela.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTabela.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnTabela.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnTabela.IconColor = System.Drawing.Color.Black;
            this.btnTabela.IconHover = System.Drawing.Color.Black;
            this.btnTabela.IconLeave = System.Drawing.Color.White;
            this.btnTabela.IconSize = 16;
            this.btnTabela.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTabela.Location = new System.Drawing.Point(0, 0);
            this.btnTabela.Name = "btnTabela";
            this.btnTabela.Padding = new System.Windows.Forms.Padding(45, 0, 0, 0);
            this.btnTabela.Rotation = 0D;
            this.btnTabela.Size = new System.Drawing.Size(200, 40);
            this.btnTabela.TabIndex = 0;
            this.btnTabela.Text = "Tabela";
            this.btnTabela.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTabela.UseVisualStyleBackColor = true;
            this.btnTabela.Click += new System.EventHandler(this.btnTabela_Click);
            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAdicionar.FlatAppearance.BorderSize = 0;
            this.btnAdicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdicionar.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnAdicionar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar.ForeColor = System.Drawing.Color.DarkGray;
            this.btnAdicionar.IconChar = FontAwesome.Sharp.IconChar.AngleUp;
            this.btnAdicionar.IconColor = System.Drawing.Color.Gray;
            this.btnAdicionar.IconHover = System.Drawing.Color.Gainsboro;
            this.btnAdicionar.IconLeave = System.Drawing.Color.Gray;
            this.btnAdicionar.IconSize = 18;
            this.btnAdicionar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdicionar.Location = new System.Drawing.Point(0, 121);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.btnAdicionar.Rotation = 0D;
            this.btnAdicionar.Size = new System.Drawing.Size(200, 40);
            this.btnAdicionar.TabIndex = 3;
            this.btnAdicionar.Text = "Adicionar   ";
            this.btnAdicionar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAdicionar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnAdicionar.UseVisualStyleBackColor = true;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 116);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 5);
            this.panel3.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 75);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 41);
            this.panel2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label3.Location = new System.Drawing.Point(23, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 21);
            this.label3.TabIndex = 9;
            this.label3.Text = "Menu";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblNomeProject);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 75);
            this.panel1.TabIndex = 0;
            // 
            // lblNomeProject
            // 
            this.lblNomeProject.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeProject.ForeColor = System.Drawing.Color.DarkGray;
            this.lblNomeProject.Location = new System.Drawing.Point(70, 9);
            this.lblNomeProject.Name = "lblNomeProject";
            this.lblNomeProject.Size = new System.Drawing.Size(124, 62);
            this.lblNomeProject.TabIndex = 1;
            this.lblNomeProject.Text = "Nome Project";
            this.lblNomeProject.MouseHover += new System.EventHandler(this.lblNomeProject_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UI.Properties.Resources.iconellogo;
            this.pictureBox1.Location = new System.Drawing.Point(3, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnlFill
            // 
            this.pnlFill.Controls.Add(this.pnlContainer);
            this.pnlFill.Controls.Add(this.pnlLinerTop);
            this.pnlFill.Controls.Add(this.pnlTop);
            this.pnlFill.Controls.Add(this.pnlLinerleft);
            this.pnlFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFill.Location = new System.Drawing.Point(200, 0);
            this.pnlFill.Name = "pnlFill";
            this.pnlFill.Size = new System.Drawing.Size(819, 622);
            this.pnlFill.TabIndex = 1;
            // 
            // pnlContainer
            // 
            this.pnlContainer.AutoScroll = true;
            this.pnlContainer.Controls.Add(this.pnlContainerVazio);
            this.pnlContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContainer.Location = new System.Drawing.Point(1, 75);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(818, 547);
            this.pnlContainer.TabIndex = 3;
            // 
            // pnlContainerVazio
            // 
            this.pnlContainerVazio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlContainerVazio.Controls.Add(this.label5);
            this.pnlContainerVazio.Controls.Add(this.label4);
            this.pnlContainerVazio.Controls.Add(this.pictureBox2);
            this.pnlContainerVazio.Location = new System.Drawing.Point(121, 83);
            this.pnlContainerVazio.Name = "pnlContainerVazio";
            this.pnlContainerVazio.Size = new System.Drawing.Size(576, 381);
            this.pnlContainerVazio.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(82, 350);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(472, 21);
            this.label5.TabIndex = 2;
            this.label5.Text = "Adicione novos itens no seu projeto ...Mais informações no tutorial.\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(68, 320);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 21);
            this.label4.TabIndex = 1;
            this.label4.Text = "Projeto Vazio";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::UI.Properties.Resources.iconeTelaEditor;
            this.pictureBox2.Location = new System.Drawing.Point(54, 17);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(450, 289);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pnlLinerTop
            // 
            this.pnlLinerTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.pnlLinerTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLinerTop.Location = new System.Drawing.Point(1, 74);
            this.pnlLinerTop.Name = "pnlLinerTop";
            this.pnlLinerTop.Size = new System.Drawing.Size(818, 1);
            this.pnlLinerTop.TabIndex = 2;
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.lblSizeProject);
            this.pnlTop.Controls.Add(this.label1);
            this.pnlTop.Controls.Add(this.btnMenu);
            this.pnlTop.Controls.Add(this.btnMini);
            this.pnlTop.Controls.Add(this.btnWindMax);
            this.pnlTop.Controls.Add(this.btnCloser);
            this.pnlTop.Controls.Add(this.btnWindMini);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(1, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(818, 74);
            this.pnlTop.TabIndex = 1;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            // 
            // lblSizeProject
            // 
            this.lblSizeProject.AutoSize = true;
            this.lblSizeProject.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSizeProject.ForeColor = System.Drawing.Color.DarkGray;
            this.lblSizeProject.Location = new System.Drawing.Point(402, 56);
            this.lblSizeProject.Name = "lblSizeProject";
            this.lblSizeProject.Size = new System.Drawing.Size(33, 15);
            this.lblSizeProject.TabIndex = 10;
            this.lblSizeProject.Text = "0MB";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label1.Location = new System.Drawing.Point(323, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tamanho :";
            // 
            // btnMenu
            // 
            this.btnMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMenu.FlatAppearance.BorderSize = 0;
            this.btnMenu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnMenu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnMenu.IconChar = FontAwesome.Sharp.IconChar.EllipsisV;
            this.btnMenu.IconColor = System.Drawing.Color.White;
            this.btnMenu.IconHover = System.Drawing.Color.DarkGray;
            this.btnMenu.IconLeave = System.Drawing.Color.White;
            this.btnMenu.IconSize = 18;
            this.btnMenu.Location = new System.Drawing.Point(14, 22);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Rotation = 0D;
            this.btnMenu.Size = new System.Drawing.Size(33, 31);
            this.btnMenu.TabIndex = 7;
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnMini
            // 
            this.btnMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMini.FlatAppearance.BorderSize = 0;
            this.btnMini.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnMini.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnMini.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMini.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnMini.IconChar = FontAwesome.Sharp.IconChar.Minus;
            this.btnMini.IconColor = System.Drawing.Color.White;
            this.btnMini.IconHover = System.Drawing.Color.DarkGray;
            this.btnMini.IconLeave = System.Drawing.Color.White;
            this.btnMini.IconSize = 18;
            this.btnMini.Location = new System.Drawing.Point(690, 12);
            this.btnMini.Name = "btnMini";
            this.btnMini.Rotation = 0D;
            this.btnMini.Size = new System.Drawing.Size(33, 31);
            this.btnMini.TabIndex = 6;
            this.btnMini.UseVisualStyleBackColor = true;
            this.btnMini.Click += new System.EventHandler(this.btnMini_Click);
            // 
            // btnWindMax
            // 
            this.btnWindMax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWindMax.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWindMax.FlatAppearance.BorderSize = 0;
            this.btnWindMax.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnWindMax.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnWindMax.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWindMax.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnWindMax.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            this.btnWindMax.IconColor = System.Drawing.Color.White;
            this.btnWindMax.IconHover = System.Drawing.Color.DarkGray;
            this.btnWindMax.IconLeave = System.Drawing.Color.White;
            this.btnWindMax.IconSize = 18;
            this.btnWindMax.Location = new System.Drawing.Point(734, 12);
            this.btnWindMax.Name = "btnWindMax";
            this.btnWindMax.Rotation = 0D;
            this.btnWindMax.Size = new System.Drawing.Size(33, 31);
            this.btnWindMax.TabIndex = 5;
            this.btnWindMax.UseVisualStyleBackColor = true;
            this.btnWindMax.Click += new System.EventHandler(this.btnWindMax_Click);
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(778, 12);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 4;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // btnWindMini
            // 
            this.btnWindMini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnWindMini.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWindMini.FlatAppearance.BorderSize = 0;
            this.btnWindMini.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnWindMini.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnWindMini.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWindMini.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnWindMini.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            this.btnWindMini.IconColor = System.Drawing.Color.White;
            this.btnWindMini.IconHover = System.Drawing.Color.DarkGray;
            this.btnWindMini.IconLeave = System.Drawing.Color.White;
            this.btnWindMini.IconSize = 18;
            this.btnWindMini.Location = new System.Drawing.Point(734, 12);
            this.btnWindMini.Name = "btnWindMini";
            this.btnWindMini.Rotation = 0D;
            this.btnWindMini.Size = new System.Drawing.Size(33, 31);
            this.btnWindMini.TabIndex = 9;
            this.btnWindMini.UseVisualStyleBackColor = true;
            this.btnWindMini.Click += new System.EventHandler(this.btnWindMini_Click);
            // 
            // pnlLinerleft
            // 
            this.pnlLinerleft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.pnlLinerleft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlLinerleft.Location = new System.Drawing.Point(0, 0);
            this.pnlLinerleft.Name = "pnlLinerleft";
            this.pnlLinerleft.Size = new System.Drawing.Size(1, 622);
            this.pnlLinerleft.TabIndex = 0;
            // 
            // AniMenu
            // 
            this.AniMenu.Interval = 10;
            this.AniMenu.Tick += new System.EventHandler(this.AniMenu_Tick);
            // 
            // FrmEditor
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(1019, 622);
            this.Controls.Add(this.pnlFill);
            this.Controls.Add(this.pnlLeft);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmEditor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmEditor";
            this.Load += new System.EventHandler(this.FrmEditor_Load);
            this.pnlLeft.ResumeLayout(false);
            this.pnlSubAdicionar.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlFill.ResumeLayout(false);
            this.pnlContainer.ResumeLayout(false);
            this.pnlContainerVazio.ResumeLayout(false);
            this.pnlContainerVazio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Panel pnlFill;
        private System.Windows.Forms.Panel pnlLinerTop;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlLinerleft;
        private FerramentasMod.ButtonIconMod btnCloser;
        private FerramentasMod.ButtonIconMod btnWindMax;
        private FerramentasMod.ButtonIconMod btnMini;
        private FerramentasMod.ButtonIconMod btnMenu;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label lblNomeProject;
        private FerramentasMod.ButtonIconMod btnWindMini;
        private FerramentasMod.ButtonIconMod btnAdicionar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSizeProject;
        private System.Windows.Forms.Panel pnlSubAdicionar;
        private FerramentasMod.ButtonIconMod btnDados;
        private FerramentasMod.ButtonIconMod btnSistemaArquivo;
        private FerramentasMod.ButtonIconMod btnGrafico;
        private FerramentasMod.ButtonIconMod btnTabela;
        private System.Windows.Forms.Timer AniMenu;
        private FerramentasMod.ButtonIconMod btnInfo;
        private System.Windows.Forms.Panel pnlContainer;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel pnlContainerVazio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}