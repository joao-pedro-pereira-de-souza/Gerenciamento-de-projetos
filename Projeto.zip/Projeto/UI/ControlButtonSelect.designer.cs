﻿namespace UI
{
    partial class ControlButtonSelect
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pbxImg = new System.Windows.Forms.PictureBox();
            this.pnlFundo = new System.Windows.Forms.Panel();
            this.pnlPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxImg)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlPrincipal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPrincipal.Controls.Add(this.lblTitulo);
            this.pnlPrincipal.Controls.Add(this.pbxImg);
            this.pnlPrincipal.Location = new System.Drawing.Point(6, 8);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(107, 111);
            this.pnlPrincipal.TabIndex = 8;
            this.pnlPrincipal.Click += new System.EventHandler(this.pnlPrincipal_Click);
            this.pnlPrincipal.MouseLeave += new System.EventHandler(this.pnlPrincipal_MouseLeave);
            this.pnlPrincipal.MouseHover += new System.EventHandler(this.pnlPrincipal_MouseHover);
            // 
            // lblTitulo
            // 
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(105, 21);
            this.lblTitulo.TabIndex = 8;
            this.lblTitulo.Text = "Projeto";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitulo.Click += new System.EventHandler(this.lblTitulo_Click);
            this.lblTitulo.MouseLeave += new System.EventHandler(this.lblTitulo_MouseLeave);
            this.lblTitulo.MouseHover += new System.EventHandler(this.lblTitulo_MouseHover);
            // 
            // pbxImg
            // 
            this.pbxImg.Location = new System.Drawing.Point(22, 24);
            this.pbxImg.Name = "pbxImg";
            this.pbxImg.Size = new System.Drawing.Size(63, 60);
            this.pbxImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxImg.TabIndex = 8;
            this.pbxImg.TabStop = false;
            this.pbxImg.Click += new System.EventHandler(this.pbxImg_Click);
            this.pbxImg.MouseLeave += new System.EventHandler(this.pbxImg_MouseLeave);
            this.pbxImg.MouseHover += new System.EventHandler(this.pbxImg_MouseHover);
            // 
            // pnlFundo
            // 
            this.pnlFundo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlFundo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.pnlFundo.Location = new System.Drawing.Point(18, 20);
            this.pnlFundo.Name = "pnlFundo";
            this.pnlFundo.Size = new System.Drawing.Size(107, 111);
            this.pnlFundo.TabIndex = 9;
            this.pnlFundo.Click += new System.EventHandler(this.pnlFundo_Click);
            this.pnlFundo.MouseLeave += new System.EventHandler(this.pnlFundo_MouseLeave);
            this.pnlFundo.MouseHover += new System.EventHandler(this.pnlFundo_MouseHover);
            // 
            // ControlButtonSelect
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.pnlFundo);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Gainsboro;
            this.Name = "ControlButtonSelect";
            this.Size = new System.Drawing.Size(131, 139);
            this.Click += new System.EventHandler(this.ControlButtonSelect_Click);
            this.MouseLeave += new System.EventHandler(this.ControlButtonSelect_MouseLeave);
            this.MouseHover += new System.EventHandler(this.ControlButtonSelect_MouseHover);
            this.pnlPrincipal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbxImg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.PictureBox pbxImg;
        private System.Windows.Forms.Panel pnlFundo;
    }
}
