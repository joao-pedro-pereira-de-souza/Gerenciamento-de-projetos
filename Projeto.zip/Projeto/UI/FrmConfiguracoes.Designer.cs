﻿namespace UI
{
    partial class FrmConfiguracoes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnlContainer = new System.Windows.Forms.Panel();
            this.btnPerfil = new FerramentasMod.ButtonIconMod();
            this.btnPerguntas = new FerramentasMod.ButtonIconMod();
            this.btnNotificacao = new FerramentasMod.ButtonIconMod();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.panel1.Controls.Add(this.btnPerfil);
            this.panel1.Controls.Add(this.btnPerguntas);
            this.panel1.Controls.Add(this.btnNotificacao);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(225, 480);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(225, 100);
            this.panel2.TabIndex = 0;
            // 
            // pnlContainer
            // 
            this.pnlContainer.AutoScroll = true;
            this.pnlContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContainer.Location = new System.Drawing.Point(225, 0);
            this.pnlContainer.Name = "pnlContainer";
            this.pnlContainer.Size = new System.Drawing.Size(811, 480);
            this.pnlContainer.TabIndex = 1;
            // 
            // btnPerfil
            // 
            this.btnPerfil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerfil.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPerfil.FlatAppearance.BorderSize = 0;
            this.btnPerfil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPerfil.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnPerfil.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnPerfil.IconChar = FontAwesome.Sharp.IconChar.User;
            this.btnPerfil.IconColor = System.Drawing.Color.Gainsboro;
            this.btnPerfil.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnPerfil.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnPerfil.IconSize = 25;
            this.btnPerfil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPerfil.Location = new System.Drawing.Point(0, 220);
            this.btnPerfil.Name = "btnPerfil";
            this.btnPerfil.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnPerfil.Rotation = 0D;
            this.btnPerfil.Size = new System.Drawing.Size(225, 60);
            this.btnPerfil.TabIndex = 3;
            this.btnPerfil.Text = "Perfil";
            this.btnPerfil.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPerfil.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPerfil.UseVisualStyleBackColor = true;
            this.btnPerfil.Click += new System.EventHandler(this.btnPerfil_Click);
            // 
            // btnPerguntas
            // 
            this.btnPerguntas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPerguntas.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPerguntas.FlatAppearance.BorderSize = 0;
            this.btnPerguntas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPerguntas.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnPerguntas.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnPerguntas.IconChar = FontAwesome.Sharp.IconChar.Question;
            this.btnPerguntas.IconColor = System.Drawing.Color.Gainsboro;
            this.btnPerguntas.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnPerguntas.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnPerguntas.IconSize = 25;
            this.btnPerguntas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPerguntas.Location = new System.Drawing.Point(0, 160);
            this.btnPerguntas.Name = "btnPerguntas";
            this.btnPerguntas.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnPerguntas.Rotation = 0D;
            this.btnPerguntas.Size = new System.Drawing.Size(225, 60);
            this.btnPerguntas.TabIndex = 2;
            this.btnPerguntas.Text = "Perguntas";
            this.btnPerguntas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPerguntas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPerguntas.UseVisualStyleBackColor = true;
            this.btnPerguntas.Click += new System.EventHandler(this.btnPrivacidade_Click);
            // 
            // btnNotificacao
            // 
            this.btnNotificacao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNotificacao.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNotificacao.FlatAppearance.BorderSize = 0;
            this.btnNotificacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNotificacao.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnNotificacao.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnNotificacao.IconChar = FontAwesome.Sharp.IconChar.Bell;
            this.btnNotificacao.IconColor = System.Drawing.Color.Gainsboro;
            this.btnNotificacao.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnNotificacao.IconLeave = System.Drawing.Color.Gainsboro;
            this.btnNotificacao.IconSize = 25;
            this.btnNotificacao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNotificacao.Location = new System.Drawing.Point(0, 100);
            this.btnNotificacao.Name = "btnNotificacao";
            this.btnNotificacao.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btnNotificacao.Rotation = 0D;
            this.btnNotificacao.Size = new System.Drawing.Size(225, 60);
            this.btnNotificacao.TabIndex = 1;
            this.btnNotificacao.Text = "Notificações";
            this.btnNotificacao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNotificacao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNotificacao.UseVisualStyleBackColor = true;
            this.btnNotificacao.Click += new System.EventHandler(this.btnNotificacao_Click);
            // 
            // FrmConfiguracoes
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(1036, 480);
            this.Controls.Add(this.pnlContainer);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmConfiguracoes";
            this.Text = "FrmConfiguracoes";
            this.Load += new System.EventHandler(this.FrmConfiguracoes_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private FerramentasMod.ButtonIconMod btnPerfil;
        private FerramentasMod.ButtonIconMod btnPerguntas;
        private FerramentasMod.ButtonIconMod btnNotificacao;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnlContainer;
    }
}