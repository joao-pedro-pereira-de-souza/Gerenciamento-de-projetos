﻿namespace UI
{
    partial class FrmLogin
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtEmail = new FerramentasMod.TextBoxMod();
            this.panelMod1 = new FerramentasMod.PanelMod();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnTwitter = new FerramentasMod.ButtonIconMod();
            this.btnInstagram = new FerramentasMod.ButtonIconMod();
            this.btnFacebook = new FerramentasMod.ButtonIconMod();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRecuperarSenha = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnCloser = new FerramentasMod.ButtonIconMod();
            this.Animat = new System.Windows.Forms.Timer(this.components);
            this.pnlLogin = new System.Windows.Forms.Panel();
            this.lblInfo = new System.Windows.Forms.Label();
            this.btnLogin = new FerramentasMod.ButtonElipse();
            this.btnCadastro = new FerramentasMod.ButtonElipse();
            this.pnlCadastro = new System.Windows.Forms.Panel();
            this.lklVoltar = new System.Windows.Forms.LinkLabel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtCadEmail = new FerramentasMod.TextBoxMod();
            this.panelMod5 = new FerramentasMod.PanelMod();
            this.label4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtCadUsuário = new FerramentasMod.TextBoxMod();
            this.panelMod3 = new FerramentasMod.PanelMod();
            this.btnCadastrar = new FerramentasMod.ButtonElipse();
            this.AnimatNot = new System.Windows.Forms.Timer(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.panelMod7 = new FerramentasMod.PanelMod();
            this.txtCadSenha = new FerramentasMod.TextBoxPasswordMod();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtCadConfSenha = new FerramentasMod.TextBoxPasswordMod();
            this.panelMod4 = new FerramentasMod.PanelMod();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtSenha = new FerramentasMod.TextBoxPasswordMod();
            this.panelMod6 = new FerramentasMod.PanelMod();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlTop.SuspendLayout();
            this.pnlLogin.SuspendLayout();
            this.pnlCadastro.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtEmail);
            this.panel1.Controls.Add(this.panelMod1);
            this.panel1.Location = new System.Drawing.Point(13, 80);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(316, 38);
            this.panel1.TabIndex = 3;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtEmail.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtEmail.Location = new System.Drawing.Point(14, 8);
            this.txtEmail.MarcaText = "Email";
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(299, 22);
            this.txtEmail.TabIndex = 1;
            this.txtEmail.Text = "Email";
            // 
            // panelMod1
            // 
            this.panelMod1.AnguloColor = 45F;
            this.panelMod1.borderRadius = 10;
            this.panelMod1.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod1.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod1.ForeColor = System.Drawing.Color.White;
            this.panelMod1.Location = new System.Drawing.Point(0, 0);
            this.panelMod1.Name = "panelMod1";
            this.panelMod1.Size = new System.Drawing.Size(316, 38);
            this.panelMod1.TabIndex = 2;
            this.panelMod1.Texto = "";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panel3.Controls.Add(this.btnTwitter);
            this.panel3.Controls.Add(this.btnInstagram);
            this.panel3.Controls.Add(this.btnFacebook);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(350, 392);
            this.panel3.TabIndex = 0;
            // 
            // btnTwitter
            // 
            this.btnTwitter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTwitter.FlatAppearance.BorderSize = 0;
            this.btnTwitter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnTwitter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnTwitter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTwitter.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnTwitter.IconChar = FontAwesome.Sharp.IconChar.Twitter;
            this.btnTwitter.IconColor = System.Drawing.Color.Gainsboro;
            this.btnTwitter.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.btnTwitter.IconLeave = System.Drawing.Color.White;
            this.btnTwitter.IconSize = 20;
            this.btnTwitter.Location = new System.Drawing.Point(74, 360);
            this.btnTwitter.Name = "btnTwitter";
            this.btnTwitter.Rotation = 0D;
            this.btnTwitter.Size = new System.Drawing.Size(25, 28);
            this.btnTwitter.TabIndex = 11;
            this.btnTwitter.UseVisualStyleBackColor = true;
            this.btnTwitter.Click += new System.EventHandler(this.btnTwitter_Click);
            // 
            // btnInstagram
            // 
            this.btnInstagram.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInstagram.FlatAppearance.BorderSize = 0;
            this.btnInstagram.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnInstagram.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnInstagram.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInstagram.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnInstagram.IconChar = FontAwesome.Sharp.IconChar.Instagram;
            this.btnInstagram.IconColor = System.Drawing.Color.Gainsboro;
            this.btnInstagram.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(81)))), ((int)(((byte)(67)))));
            this.btnInstagram.IconLeave = System.Drawing.Color.White;
            this.btnInstagram.IconSize = 20;
            this.btnInstagram.Location = new System.Drawing.Point(43, 360);
            this.btnInstagram.Name = "btnInstagram";
            this.btnInstagram.Rotation = 0D;
            this.btnInstagram.Size = new System.Drawing.Size(25, 28);
            this.btnInstagram.TabIndex = 10;
            this.btnInstagram.UseVisualStyleBackColor = true;
            this.btnInstagram.Click += new System.EventHandler(this.btnInstagram_Click);
            // 
            // btnFacebook
            // 
            this.btnFacebook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFacebook.FlatAppearance.BorderSize = 0;
            this.btnFacebook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnFacebook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.btnFacebook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFacebook.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnFacebook.IconChar = FontAwesome.Sharp.IconChar.Facebook;
            this.btnFacebook.IconColor = System.Drawing.Color.Gainsboro;
            this.btnFacebook.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.btnFacebook.IconLeave = System.Drawing.Color.White;
            this.btnFacebook.IconSize = 20;
            this.btnFacebook.Location = new System.Drawing.Point(12, 360);
            this.btnFacebook.Name = "btnFacebook";
            this.btnFacebook.Rotation = 0D;
            this.btnFacebook.Size = new System.Drawing.Size(25, 28);
            this.btnFacebook.TabIndex = 9;
            this.btnFacebook.UseVisualStyleBackColor = true;
            this.btnFacebook.Click += new System.EventHandler(this.btnFacebook_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.label2.Location = new System.Drawing.Point(94, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 30);
            this.label2.TabIndex = 8;
            this.label2.Text = "Project Drawer";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::UI.Properties.Resources.iconellogo;
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(71, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UI.Properties.Resources.iconeGrafliner;
            this.pictureBox1.Location = new System.Drawing.Point(12, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 267);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Login";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRecuperarSenha
            // 
            this.lblRecuperarSenha.AutoSize = true;
            this.lblRecuperarSenha.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblRecuperarSenha.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecuperarSenha.ForeColor = System.Drawing.Color.Gray;
            this.lblRecuperarSenha.Location = new System.Drawing.Point(23, 188);
            this.lblRecuperarSenha.Name = "lblRecuperarSenha";
            this.lblRecuperarSenha.Size = new System.Drawing.Size(119, 21);
            this.lblRecuperarSenha.TabIndex = 10;
            this.lblRecuperarSenha.Text = "Esqueci a senha";
            this.lblRecuperarSenha.Click += new System.EventHandler(this.lblRecuperarSenha_Click);
            this.lblRecuperarSenha.MouseLeave += new System.EventHandler(this.lblRecuperarSenha_MouseLeave);
            this.lblRecuperarSenha.MouseHover += new System.EventHandler(this.lblRecuperarSenha_MouseHover);
            // 
            // pnlTop
            // 
            this.pnlTop.Controls.Add(this.btnCloser);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTop.Location = new System.Drawing.Point(350, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(361, 35);
            this.pnlTop.TabIndex = 11;
            this.pnlTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlTop_MouseDown);
            // 
            // btnCloser
            // 
            this.btnCloser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCloser.FlatAppearance.BorderSize = 0;
            this.btnCloser.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.btnCloser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloser.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.btnCloser.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.btnCloser.IconColor = System.Drawing.Color.White;
            this.btnCloser.IconHover = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.btnCloser.IconLeave = System.Drawing.Color.White;
            this.btnCloser.IconSize = 18;
            this.btnCloser.Location = new System.Drawing.Point(325, 2);
            this.btnCloser.Name = "btnCloser";
            this.btnCloser.Rotation = 0D;
            this.btnCloser.Size = new System.Drawing.Size(33, 31);
            this.btnCloser.TabIndex = 9;
            this.btnCloser.UseVisualStyleBackColor = true;
            this.btnCloser.Click += new System.EventHandler(this.btnCloser_Click);
            // 
            // Animat
            // 
            this.Animat.Interval = 10;
            this.Animat.Tick += new System.EventHandler(this.Animat_Tick);
            // 
            // pnlLogin
            // 
            this.pnlLogin.Controls.Add(this.panel7);
            this.pnlLogin.Controls.Add(this.lblInfo);
            this.pnlLogin.Controls.Add(this.label1);
            this.pnlLogin.Controls.Add(this.btnLogin);
            this.pnlLogin.Controls.Add(this.panel1);
            this.pnlLogin.Controls.Add(this.btnCadastro);
            this.pnlLogin.Controls.Add(this.lblRecuperarSenha);
            this.pnlLogin.Location = new System.Drawing.Point(360, 41);
            this.pnlLogin.Name = "pnlLogin";
            this.pnlLogin.Size = new System.Drawing.Size(340, 347);
            this.pnlLogin.TabIndex = 14;
            // 
            // lblInfo
            // 
            this.lblInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.lblInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblInfo.Location = new System.Drawing.Point(0, 37);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(340, 35);
            this.lblInfo.TabIndex = 14;
            this.lblInfo.Text = "Notificação";
            this.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInfo.Visible = false;
            // 
            // btnLogin
            // 
            this.btnLogin.AnguloColor = 45F;
            this.btnLogin.borderRadius = 10;
            this.btnLogin.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnLogin.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btnLogin.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.EfeitoTexto = true;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(13, 249);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(316, 39);
            this.btnLogin.TabIndex = 13;
            this.btnLogin.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Texto = "Logar";
            this.btnLogin.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnCadastro
            // 
            this.btnCadastro.AnguloColor = 45F;
            this.btnCadastro.borderRadius = 10;
            this.btnCadastro.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnCadastro.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(160)))), ((int)(((byte)(133)))));
            this.btnCadastro.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnCadastro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastro.EfeitoTexto = true;
            this.btnCadastro.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastro.ForeColor = System.Drawing.Color.White;
            this.btnCadastro.Location = new System.Drawing.Point(13, 294);
            this.btnCadastro.Name = "btnCadastro";
            this.btnCadastro.Size = new System.Drawing.Size(316, 39);
            this.btnCadastro.TabIndex = 12;
            this.btnCadastro.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastro.Texto = "Cadastro";
            this.btnCadastro.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastro.Click += new System.EventHandler(this.btnCadastro_Click);
            // 
            // pnlCadastro
            // 
            this.pnlCadastro.Controls.Add(this.panel5);
            this.pnlCadastro.Controls.Add(this.panel4);
            this.pnlCadastro.Controls.Add(this.lklVoltar);
            this.pnlCadastro.Controls.Add(this.panel8);
            this.pnlCadastro.Controls.Add(this.label4);
            this.pnlCadastro.Controls.Add(this.panel6);
            this.pnlCadastro.Controls.Add(this.btnCadastrar);
            this.pnlCadastro.Location = new System.Drawing.Point(720, 41);
            this.pnlCadastro.Name = "pnlCadastro";
            this.pnlCadastro.Size = new System.Drawing.Size(340, 347);
            this.pnlCadastro.TabIndex = 15;
            // 
            // lklVoltar
            // 
            this.lklVoltar.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.lklVoltar.AutoSize = true;
            this.lklVoltar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lklVoltar.LinkColor = System.Drawing.Color.Gray;
            this.lklVoltar.Location = new System.Drawing.Point(19, 267);
            this.lklVoltar.Name = "lklVoltar";
            this.lklVoltar.Size = new System.Drawing.Size(51, 21);
            this.lklVoltar.TabIndex = 16;
            this.lklVoltar.TabStop = true;
            this.lklVoltar.Text = "Voltar";
            this.lklVoltar.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            this.lklVoltar.Click += new System.EventHandler(this.lklVoltar_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txtCadEmail);
            this.panel8.Controls.Add(this.panelMod5);
            this.panel8.Location = new System.Drawing.Point(17, 112);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(316, 38);
            this.panel8.TabIndex = 14;
            // 
            // txtCadEmail
            // 
            this.txtCadEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtCadEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCadEmail.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtCadEmail.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtCadEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtCadEmail.Location = new System.Drawing.Point(14, 8);
            this.txtCadEmail.MarcaText = "Email";
            this.txtCadEmail.Name = "txtCadEmail";
            this.txtCadEmail.Size = new System.Drawing.Size(299, 22);
            this.txtCadEmail.TabIndex = 2;
            this.txtCadEmail.Text = "Email";
            // 
            // panelMod5
            // 
            this.panelMod5.AnguloColor = 45F;
            this.panelMod5.borderRadius = 10;
            this.panelMod5.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod5.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod5.ForeColor = System.Drawing.Color.White;
            this.panelMod5.Location = new System.Drawing.Point(0, 0);
            this.panelMod5.Name = "panelMod5";
            this.panelMod5.Size = new System.Drawing.Size(316, 38);
            this.panelMod5.TabIndex = 2;
            this.panelMod5.Texto = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(105, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 37);
            this.label4.TabIndex = 1;
            this.label4.Text = "Cadastro";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txtCadUsuário);
            this.panel6.Controls.Add(this.panelMod3);
            this.panel6.Location = new System.Drawing.Point(17, 57);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(316, 38);
            this.panel6.TabIndex = 3;
            // 
            // txtCadUsuário
            // 
            this.txtCadUsuário.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtCadUsuário.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCadUsuário.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtCadUsuário.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtCadUsuário.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtCadUsuário.Location = new System.Drawing.Point(14, 8);
            this.txtCadUsuário.MarcaText = "Usuário";
            this.txtCadUsuário.Name = "txtCadUsuário";
            this.txtCadUsuário.Size = new System.Drawing.Size(299, 22);
            this.txtCadUsuário.TabIndex = 1;
            this.txtCadUsuário.Text = "Usuário";
            // 
            // panelMod3
            // 
            this.panelMod3.AnguloColor = 45F;
            this.panelMod3.borderRadius = 10;
            this.panelMod3.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod3.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod3.ForeColor = System.Drawing.Color.White;
            this.panelMod3.Location = new System.Drawing.Point(0, 0);
            this.panelMod3.Name = "panelMod3";
            this.panelMod3.Size = new System.Drawing.Size(316, 38);
            this.panelMod3.TabIndex = 2;
            this.panelMod3.Texto = "";
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.AnguloColor = 45F;
            this.btnCadastrar.borderRadius = 10;
            this.btnCadastrar.ColorButton = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnCadastrar.ColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(160)))), ((int)(((byte)(133)))));
            this.btnCadastrar.ColorLeaver = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.btnCadastrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadastrar.EfeitoTexto = true;
            this.btnCadastrar.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrar.ForeColor = System.Drawing.Color.White;
            this.btnCadastrar.Location = new System.Drawing.Point(17, 297);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(316, 39);
            this.btnCadastrar.TabIndex = 12;
            this.btnCadastrar.TextLeaver = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrar.Texto = "Cadastrar";
            this.btnCadastrar.TextShow = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // AnimatNot
            // 
            this.AnimatNot.Interval = 2500;
            this.AnimatNot.Tick += new System.EventHandler(this.AnimatNot_Tick);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtCadSenha);
            this.panel4.Controls.Add(this.panelMod7);
            this.panel4.Location = new System.Drawing.Point(17, 167);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(316, 38);
            this.panel4.TabIndex = 15;
            // 
            // panelMod7
            // 
            this.panelMod7.AnguloColor = 45F;
            this.panelMod7.borderRadius = 10;
            this.panelMod7.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod7.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod7.ForeColor = System.Drawing.Color.White;
            this.panelMod7.Location = new System.Drawing.Point(0, 0);
            this.panelMod7.Name = "panelMod7";
            this.panelMod7.Size = new System.Drawing.Size(316, 38);
            this.panelMod7.TabIndex = 0;
            this.panelMod7.Texto = "";
            // 
            // txtCadSenha
            // 
            this.txtCadSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtCadSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCadSenha.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtCadSenha.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtCadSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtCadSenha.Location = new System.Drawing.Point(14, 8);
            this.txtCadSenha.MarcaText = "Senha";
            this.txtCadSenha.Name = "txtCadSenha";
            this.txtCadSenha.Size = new System.Drawing.Size(298, 22);
            this.txtCadSenha.TabIndex = 1;
            this.txtCadSenha.Text = "Senha";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtCadConfSenha);
            this.panel5.Controls.Add(this.panelMod4);
            this.panel5.Location = new System.Drawing.Point(17, 222);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(316, 38);
            this.panel5.TabIndex = 17;
            // 
            // txtCadConfSenha
            // 
            this.txtCadConfSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtCadConfSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCadConfSenha.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtCadConfSenha.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtCadConfSenha.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtCadConfSenha.Location = new System.Drawing.Point(14, 8);
            this.txtCadConfSenha.MarcaText = "Confirmar Senha";
            this.txtCadConfSenha.Name = "txtCadConfSenha";
            this.txtCadConfSenha.Size = new System.Drawing.Size(298, 22);
            this.txtCadConfSenha.TabIndex = 1;
            // 
            // panelMod4
            // 
            this.panelMod4.AnguloColor = 45F;
            this.panelMod4.borderRadius = 10;
            this.panelMod4.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod4.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod4.ForeColor = System.Drawing.Color.White;
            this.panelMod4.Location = new System.Drawing.Point(0, 0);
            this.panelMod4.Name = "panelMod4";
            this.panelMod4.Size = new System.Drawing.Size(316, 38);
            this.panelMod4.TabIndex = 0;
            this.panelMod4.Texto = "";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txtSenha);
            this.panel7.Controls.Add(this.panelMod6);
            this.panel7.Location = new System.Drawing.Point(13, 135);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(316, 38);
            this.panel7.TabIndex = 16;
            // 
            // txtSenha
            // 
            this.txtSenha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.txtSenha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSenha.ColorDig = System.Drawing.Color.Gainsboro;
            this.txtSenha.ColorMarca = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtSenha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.txtSenha.Location = new System.Drawing.Point(14, 8);
            this.txtSenha.MarcaText = "Senha";
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.Size = new System.Drawing.Size(298, 22);
            this.txtSenha.TabIndex = 1;
            this.txtSenha.Text = "Senha";
            // 
            // panelMod6
            // 
            this.panelMod6.AnguloColor = 45F;
            this.panelMod6.borderRadius = 10;
            this.panelMod6.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod6.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.panelMod6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMod6.ForeColor = System.Drawing.Color.White;
            this.panelMod6.Location = new System.Drawing.Point(0, 0);
            this.panelMod6.Name = "panelMod6";
            this.panelMod6.Size = new System.Drawing.Size(316, 38);
            this.panelMod6.TabIndex = 0;
            this.panelMod6.Texto = "";
            // 
            // FrmLogin
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(711, 392);
            this.Controls.Add(this.pnlCadastro);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pnlLogin);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlTop.ResumeLayout(false);
            this.pnlLogin.ResumeLayout(false);
            this.pnlLogin.PerformLayout();
            this.pnlCadastro.ResumeLayout(false);
            this.pnlCadastro.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private FerramentasMod.TextBoxMod txtEmail;
        private FerramentasMod.PanelMod panelMod1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private FerramentasMod.ButtonIconMod btnCloser;
        private FerramentasMod.ButtonIconMod btnFacebook;
        private FerramentasMod.ButtonIconMod btnInstagram;
        private FerramentasMod.ButtonIconMod btnTwitter;
        private System.Windows.Forms.Label lblRecuperarSenha;
        private System.Windows.Forms.Panel pnlTop;
        private FerramentasMod.ButtonElipse btnCadastro;
        private FerramentasMod.ButtonElipse btnLogin;
        private System.Windows.Forms.Timer Animat;
        private System.Windows.Forms.Panel pnlLogin;
        private System.Windows.Forms.Panel pnlCadastro;
        private System.Windows.Forms.Panel panel8;
        private FerramentasMod.TextBoxMod txtCadEmail;
        private FerramentasMod.PanelMod panelMod5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel6;
        private FerramentasMod.TextBoxMod txtCadUsuário;
        private FerramentasMod.PanelMod panelMod3;
        private FerramentasMod.ButtonElipse btnCadastrar;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Timer AnimatNot;
        private System.Windows.Forms.LinkLabel lklVoltar;
        private System.Windows.Forms.Panel panel4;
        private FerramentasMod.TextBoxPasswordMod txtCadSenha;
        private FerramentasMod.PanelMod panelMod7;
        private System.Windows.Forms.Panel panel5;
        private FerramentasMod.TextBoxPasswordMod txtCadConfSenha;
        private FerramentasMod.PanelMod panelMod4;
        private System.Windows.Forms.Panel panel7;
        private FerramentasMod.TextBoxPasswordMod txtSenha;
        private FerramentasMod.PanelMod panelMod6;
    }
}

