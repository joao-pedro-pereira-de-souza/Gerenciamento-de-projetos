﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Business;
using System.IO;
using UI.UIConfigs;

namespace UI
{
    public partial class FrmEditor : Form
    {
        bool startMenu = true;

        int topContainer = 20;
        
        int leftContainer = 30;
        int quantGraf = 0;

       

        public FrmEditor()
        {
            InitializeComponent();

           // pnlSubMembros.Visible = false;
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        #region Botões padrão

        private void btnCloser_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void btnWindMax_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnWindMax.Visible = false;
            btnWindMini.Visible = true;
        }

        private void btnWindMini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btnWindMax.Visible = true;
            btnWindMini.Visible = false;
        }

        private void btnMini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        #endregion

        

        #region Design Buttons pnlLeft

        public void VerificarOpenSub()
        {
            if(pnlSubAdicionar.Visible == true)
            {
                pnlSubAdicionar.Visible = false;
                btnAdicionar.IconChar = FontAwesome.Sharp.IconChar.AngleDown;
            }
         /*
            if(pnlSubMembros.Visible == true)
            {
                pnlSubMembros.Visible = false;
                btnMembros.IconChar = FontAwesome.Sharp.IconChar.AngleDown;
            }
            */
         
        }


        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            VerificarOpenSub();
            pnlSubAdicionar.Visible = true;
            btnAdicionar.IconChar = FontAwesome.Sharp.IconChar.AngleUp;

           

        }
        private void btnMembros_Click(object sender, EventArgs e)
        {
            VerificarOpenSub();
            /*
            pnlSubMembros.Visible = true;
            btnMembros.IconChar = FontAwesome.Sharp.IconChar.AngleUp;
            */

        }

        #endregion

        #region Cllck Menu + Animação

        private void AniMenu_Tick(object sender, EventArgs e)
        {
            if (startMenu == true)
            {
                pnlLeft.Width -= 10;

                if (pnlLeft.Width == 0)
                {
                    startMenu = false;
                    pnlLinerleft.Visible = false;
                    AniMenu.Stop();
                }
            }
            else
            {
                pnlLeft.Width += 10;

                if (pnlLeft.Width == 200)
                {
                    startMenu = true;
                    pnlLinerleft.Visible = true;
                    AniMenu.Stop();
                }
            }
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            AniMenu.Start();
        }

        #endregion


        // Fonte DataSet(Comandos de manipulação) : https://www.youtube.com/watch?v=QkoLDfTmIec 

        #region Containers

        public void AdicionarTable()
        {

            UserContainerV2 container2 = new UserContainerV2();


            if (this.WindowState == FormWindowState.Maximized)
            {
                container2.Size = new Size(1100, 366);
            }
            else
            {
                container2.Size = new Size(756, 366);
            }

            pnlContainerVazio.Visible = false;
            // Responsive .
            container2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            container2.MinimumSize = new Size(756, 366);
            container2.MaximumSize = new Size(1300, 366);

            pnlContainer.Controls.Add(container2);

            pnlContainer.Tag = container2;

            //

            // Position
            container2.Top = topContainer;
            container2.Left = leftContainer;
            //

            #region Add Parametros InfoCard DataSet
            /*
            Business.LevantamentoDados.DSDadosCard dados = new Business.LevantamentoDados.DSDadosCard();

            FullDadosCards.Cards.Add(quantGraf, dados);

            FullDadosCards.Cards[quantGraf].InfoCard.selectCardColumn.DefaultValue = "Card :" + quantGraf;
            FullDadosCards.Cards[quantGraf].InfoCard.topCardColumn.DefaultValue = topContainer;
            FullDadosCards.Cards[quantGraf].InfoCard.leftCardColumn.DefaultValue = leftContainer;
            */
            #endregion

            topContainer += (container2.Height + 10);

            container2.Show();


        }


        public void AdicionarSitemasArquivo()
        {

          UIContainers.UserContainerV3 container3 = new UIContainers.UserContainerV3();


            if (this.WindowState == FormWindowState.Maximized)
            {
                container3.Size = new Size(1100, 366);
            }
            else
            {
                container3.Size = new Size(756, 366);
            }

            pnlContainerVazio.Visible = false;
            // Responsive .
            container3.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            container3.MinimumSize = new Size(756, 366);
            container3.MaximumSize = new Size(1300, 366);

            pnlContainer.Controls.Add(container3);

            pnlContainer.Tag = container3;

            //

            // Position
            container3.Top = topContainer;
            container3.Left = leftContainer;
            //

          

            topContainer += (container3.Height + 10);

            container3.Show();


        }

        public void AdicionarContainer()
        {
           // Container 1
            UserContainerV1 container1 = new UserContainerV1();

            if (this.WindowState == FormWindowState.Maximized)
            {
                container1.Size = new Size(1100, 466);
            }
            else
            {
                container1.Size = new Size(756, 366);
            }

            // Responsive .
            container1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
           
            container1.MinimumSize = new Size(756, 366);
            container1.MaximumSize = new Size(1300, 1000);

            pnlContainer.Controls.Add(container1);

            //
            
            pnlContainer.Tag = container1;

            // Position
            container1.Top = topContainer;
            container1.Left = leftContainer;
            //

            #region Add Parametros InfoCard DataSet

            /*

            Business.LevantamentoDados.DSDadosCard dados = new Business.LevantamentoDados.DSDadosCard();
            
            FullDadosCards.Cards.Add(quantGraf, dados);
     
            FullDadosCards.Cards[quantGraf].InfoCard.selectCardColumn.DefaultValue = "Card :" +quantGraf;
            FullDadosCards.Cards[quantGraf].InfoCard.topCardColumn.DefaultValue = topContainer;
            FullDadosCards.Cards[quantGraf].InfoCard.leftCardColumn.DefaultValue = leftContainer;
            */
            #endregion

           // DadosCard.numericCard = quantGraf; // Adicionar o numerio do card criado.

            topContainer += (container1.Height + 30);// calculo de distancia Top para o próximo card.

            container1.Show();

            quantGraf++;

            //
        }

        #endregion

        private void btnGrafico_Click(object sender, EventArgs e)
        {
            try
            {
                pnlContainerVazio.Visible = false;
                AdicionarContainer();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
            
        }

        #region Arrastar Form

        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #endregion

        private void FrmEditor_Load(object sender, EventArgs e)
        {

            #region Adicionando o tamanho da pasta( do Projeto)

            // Fonte :https://www.youtube.com/watch?v=hTv4LyLM_Qs .
            //Para poder adaptar no sistema criado GetSizeFile foi preciso fazer uma pesquisa.
            DirectoryInfo diretory = new DirectoryInfo(DadosUsuario.DiretoryProject);

            var sizeBytes = diretory.EnumerateFiles().Sum(files => files.Length);
            //

            lblSizeProject.Text = ControlFileProject.GetSizeFile(sizeBytes);

            #endregion

        }

        private void btnTabela_Click(object sender, EventArgs e)
        {
            try
            {
                AdicionarTable();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           
        }

        private void btnSistemaArquivo_Click(object sender, EventArgs e)
        {
            try
            {
                AdicionarSitemasArquivo();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro :\n" + ex.Message);
            }
           
        }

        private void btnDados_Click(object sender, EventArgs e)
        {
            FrmConfigDados dados = new FrmConfigDados("Create");
            dados.CriarForaP = false;

            dados.ShowDialog();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            FrmMensagem mensagem = new FrmMensagem();

            mensagem.lblTitulo.Text = "Como funciona ?";

            mensagem.lblConteudo.Text = "Adicione um dos cards , edite eles com tabelas , gráficos , e um sistema de organizar " +
                "arquivos \nvocê pode adicioar tabelas do excel como base de dados para os gráficos e tabelas. Se você não tiver uma base de dados você pode criar uma do zero.";

            mensagem.ptbMensagem.Image = Properties.Resources.iconeTelaEditor;

            mensagem.ShowDialog();


        }

        private void lblNomeProject_MouseHover(object sender, EventArgs e)
        {
            ToolTip Informat = new ToolTip();

            Informat.IsBalloon = true;

            Informat.SetToolTip(this.lblNomeProject, lblNomeProject.Text);
        }
    }
}
