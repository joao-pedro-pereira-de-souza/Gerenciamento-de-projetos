﻿namespace UI
{
    partial class FrmMensagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlLinerTop = new System.Windows.Forms.Panel();
            this.btnOk = new FerramentasMod.PanelMod();
            this.lblConteudo = new System.Windows.Forms.Label();
            this.ptbMensagem = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbMensagem)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(663, 47);
            this.panel1.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblTitulo.Location = new System.Drawing.Point(12, 17);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(639, 17);
            this.lblTitulo.TabIndex = 11;
            this.lblTitulo.Text = "Titulo";
            // 
            // pnlLinerTop
            // 
            this.pnlLinerTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(66)))), ((int)(((byte)(66)))));
            this.pnlLinerTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLinerTop.Location = new System.Drawing.Point(0, 47);
            this.pnlLinerTop.Name = "pnlLinerTop";
            this.pnlLinerTop.Size = new System.Drawing.Size(663, 2);
            this.pnlLinerTop.TabIndex = 2;
            // 
            // btnOk
            // 
            this.btnOk.AnguloColor = 45F;
            this.btnOk.borderRadius = 10;
            this.btnOk.Color0 = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnOk.Color1 = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.btnOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOk.ForeColor = System.Drawing.Color.White;
            this.btnOk.Location = new System.Drawing.Point(293, 339);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(76, 39);
            this.btnOk.TabIndex = 3;
            this.btnOk.Texto = "Ok";
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // lblConteudo
            // 
            this.lblConteudo.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblConteudo.Location = new System.Drawing.Point(18, 268);
            this.lblConteudo.Name = "lblConteudo";
            this.lblConteudo.Size = new System.Drawing.Size(627, 68);
            this.lblConteudo.TabIndex = 4;
            this.lblConteudo.Text = "Caixa de Mensagem";
            // 
            // ptbMensagem
            // 
            this.ptbMensagem.Image = global::UI.Properties.Resources.iconeManutencao;
            this.ptbMensagem.Location = new System.Drawing.Point(103, 55);
            this.ptbMensagem.Name = "ptbMensagem";
            this.ptbMensagem.Size = new System.Drawing.Size(457, 210);
            this.ptbMensagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbMensagem.TabIndex = 1;
            this.ptbMensagem.TabStop = false;
            // 
            // FrmMensagem
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(59)))), ((int)(((byte)(59)))));
            this.ClientSize = new System.Drawing.Size(663, 390);
            this.Controls.Add(this.lblConteudo);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.pnlLinerTop);
            this.Controls.Add(this.ptbMensagem);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmMensagem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmMensagem";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptbMensagem)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel pnlLinerTop;
        private FerramentasMod.PanelMod btnOk;
        public System.Windows.Forms.PictureBox ptbMensagem;
        public System.Windows.Forms.Label lblConteudo;
        public System.Windows.Forms.Label lblTitulo;
    }
}