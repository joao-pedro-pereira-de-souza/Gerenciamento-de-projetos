﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class FrmAdmin : Form
    {
        public FrmAdmin()
        {
            InitializeComponent();
        }

        #region Design Shadow

        private const int CS_DropShadow = 0x00020000;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DropShadow;


                return cp;
            }
        }

        #endregion

        private void FrmAdmin_Load(object sender, EventArgs e)
        {

            try
            {
                Business.ControlDatabase BD = new Business.ControlDatabase();

                dgvDados.DataSource = BD.ShowDataTable("Select * from usuarios");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocorreu um erro no banco : \n" + ex.Message);
            }
           

        }

        private void btnCloser_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMini_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            try
            {

                if(txtTema.Text != txtTema.MarcaText)
                {

                    if(txtMensagem.Text != "")
                    {
                        List<string> Senders = new List<string>();
                        for (int i = 0; i < dgvDados.Rows.Count - 1; i++)
                        {

                            if ((bool)dgvDados.Rows[i].Cells[6].Value == true) // Verificar se a caixa do usuário está selecioada.
                            {
                                //Adicionar no list
                                Senders.Add(dgvDados.Rows[i].Cells[2].Value.ToString());
                            }
                        }

                        if (Senders != null && Senders.Count > 0)
                        {
                            Business.ControlConfigEnviarEmail eviar = new Business.ControlConfigEnviarEmail(

                                   tema: txtTema.Text,
                                   titulo: "Noticia ...",
                                   texto: txtMensagem.Text,
                                   subtxt: "",
                                   subbject: "",
                                   Sender: Senders

                                   );
                        }
                        else
                        {
                            MessageBox.Show("não existe usuários para receber mensagem");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Digite uma mensagem");
                    }

                }
                else
                {
                    MessageBox.Show("digite um Tema");
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro : \n" + ex.Message);
            }
           
           
        }

        #region Arrastar Form

        #region Importar Dll user32

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        #endregion

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        #endregion

      
    }
}
