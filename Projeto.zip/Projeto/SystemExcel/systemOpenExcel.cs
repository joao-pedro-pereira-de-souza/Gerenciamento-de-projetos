﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using ExcelDataReader;
using System.Data;



namespace SystemExcel
{
    public class systemOpenExcel
    {

    
        public DataSet AbrirExcel(string fileExcel)
        {

            using (var strem = File.Open(fileExcel, FileMode.Open, FileAccess.Read))
            {

                using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(strem))
                {


                    DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (_) => new ExcelDataTableConfiguration() { UseHeaderRow = true }
                    });
                  

                    return result;
                }

            }
        }

    }
}
