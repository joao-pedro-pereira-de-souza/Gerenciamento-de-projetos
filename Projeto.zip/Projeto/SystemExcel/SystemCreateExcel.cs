﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using OfficeExcel = Microsoft.Office.Interop.Excel;

namespace SystemExcel
{
   public class SystemCreateExcel
   {

        public void CreateTables(string fileDiretory, DataSet Tabelas, string fileTable)
        {
            //Fonte: https://github.com/CodAffection/How-to-Export-Excel-in-C- .
            //Video: https://www.youtube.com/watch?feature=player_embedded&v=yX-JOqV_ZR0 .

            System.Reflection.Missing Default = System.Reflection.Missing.Value;
            //Create Excel File

            OfficeExcel.Application excelApp = new OfficeExcel.Application();
            OfficeExcel.Workbook excelWorkBook = excelApp.Workbooks.Add(1);


            #region Adicionando tabelas no Excel.

            foreach (DataTable dtbl in Tabelas.Tables)
            {
                //Create Excel WorkSheet
                OfficeExcel.Worksheet excelWorkSheet = excelWorkBook.Sheets.Add(Default, excelWorkBook.Sheets[excelWorkBook.Sheets.Count], 1, Default);
                excelWorkSheet.Name = dtbl.TableName;//Name worksheet

                //Write Column Name

                for (int a = 1; a < dtbl.Columns.Count + 1; a++)
                {
                    excelWorkSheet.Cells[1, a] = dtbl.Columns[a - 1].ColumnName;


                }

                for (int e = 0; e < dtbl.Rows.Count; e++)
                {

                    for (int o = 0; o < dtbl.Columns.Count; o++)
                    {
                        excelWorkSheet.Cells[e + 2, o + 1] = dtbl.Rows[e][o];
                    }
                }


                //Auto fit columns
                excelWorkSheet.Columns.AutoFit();
            }

            #endregion

            #region Configurações finais 

            //Delete First Page
            excelApp.DisplayAlerts = false;
            Microsoft.Office.Interop.Excel.Worksheet lastWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)excelWorkBook.Worksheets[1];
            lastWorkSheet.Delete();
            excelApp.DisplayAlerts = true;

            //Set Defualt Page
            (excelWorkBook.Sheets[1] as OfficeExcel._Worksheet).Activate();

            excelWorkBook.SaveAs(fileDiretory + fileTable + ".xlsx");
            excelWorkBook.Close();
            excelApp.Quit();

            #endregion


        }
    }
}
