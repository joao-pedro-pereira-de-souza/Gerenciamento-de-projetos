﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Security.Cryptography;

namespace DataAcess
{
    public class Database:DadosConection
    {
        MySqlConnection cone;

        public Database()
        {
            cone = new MySqlConnection(conect);
            if(cone.State == System.Data.ConnectionState.Closed)
            {
                cone.Open();
            }
        }

        public DataTable SelectTable(string cmd)
        {

            using(var conect = cone)
            {
                MySqlCommand comand = new MySqlCommand();
                MySqlDataReader reader;
                DataTable table = new DataTable();


                comand.Connection = conect;
                comand.CommandText = cmd;
                comand.CommandType = CommandType.Text;
                reader = comand.ExecuteReader();

                table.Load(reader);

                return table;

            }
        }

        public string ExeculteReader(string cmd)
        {
            using(var conect = cone)
            {
                MySqlCommand comand = new MySqlCommand();
                DataTable table = new DataTable();

                comand.Connection = conect;
                comand.CommandText = cmd;
                comand.CommandType = CommandType.Text;

                comand.ExecuteNonQuery();

                return "Registro Criado com sucesso";

            }


        }

        #region Consulta que retorna 1 campo do Banco.

        public string consultaExpecifica(string cmd, int campo)
        {
            using (var conect = cone)
            {
                MySqlCommand comand = new MySqlCommand();
                MySqlDataReader reader;

                comand.Connection = conect;
                comand.CommandText = cmd;
                comand.CommandType = CommandType.Text;
                reader = comand.ExecuteReader();

                if (reader.Read() == true)
                {
                    return reader.GetString(campo);
                }
                else
                {
                    return "Vazio";
                }

            }

        }

        #endregion




    }
}
