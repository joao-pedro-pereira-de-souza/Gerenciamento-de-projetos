﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcess
{
    public class DadosConection
    {
      protected string conect = "Server=localhost;uid=root;password='';Database=tela_login";

    }
}
