﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace DataAcess
{
    public class MysqlConnect
    {

        MySqlConnection cone;

        public MysqlConnect (string conect)
        {
            cone = new MySqlConnection(conect);

            if(cone.State == System.Data.ConnectionState.Closed)
            {
                cone.Open();

                
            }

            
        }

        public DataTable Show(string cmd)
        {
            using(var co = cone)
            {
                MySqlCommand comand = new MySqlCommand();
                MySqlDataReader reader;
                DataTable tabla = new DataTable();

                comand.Connection = cone;

                comand.CommandText = cmd;

                comand.CommandType = CommandType.Text;

                reader = comand.ExecuteReader();


                tabla.Load(reader);

                return tabla;
                

            }
        }
    }
}
