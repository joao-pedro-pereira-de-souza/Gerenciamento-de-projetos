﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace DataAcess.Connect
{
    public class SqlConnect
    {
        SqlConnection cone;

        public SqlConnect(string conect)
        {
            cone = new SqlConnection(conect);

            if (cone.State == System.Data.ConnectionState.Closed)
            {
                cone.Open();


            }


        }

        public DataTable Show(string cmd)
        {
            using (var co = cone)
            {
                SqlCommand comand = new SqlCommand();
                SqlDataReader reader;
                DataTable tabla = new DataTable();

                comand.Connection = cone;

                comand.CommandText = cmd;

                comand.CommandType = CommandType.Text;

                reader = comand.ExecuteReader();


                tabla.Load(reader);

                return tabla;


            }
        }
    }
}
